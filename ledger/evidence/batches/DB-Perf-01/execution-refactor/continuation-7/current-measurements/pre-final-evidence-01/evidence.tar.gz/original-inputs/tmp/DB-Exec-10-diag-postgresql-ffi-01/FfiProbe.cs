using System.Runtime.InteropServices;
internal sealed record FfiCounters(ulong[] Calls, ulong[] PendingReturns, ulong[] OkReturns,
    ulong ProviderPollCalls, ulong ProviderPollTimeouts, ulong ProviderPollErrors, ulong ProviderPollNanoseconds);
internal static unsafe class FfiProbe
{
    private static readonly nint Module = NativeLibrary.Load(Path.Combine(AppContext.BaseDirectory, "libcursor_probe.so"));
    private static readonly delegate* unmanaged[Cdecl]<uint, uint, ulong> Count =
        (delegate* unmanaged[Cdecl]<uint, uint, ulong>)NativeLibrary.GetExport(Module, "db_perf_ffi_count");
    internal static FfiCounters Read()
    {
        var calls = new ulong[60]; var pending = new ulong[60]; var ok = new ulong[60];
        for (uint i = 0; i < calls.Length; i++)
        { calls[i] = Count(0, i); pending[i] = Count(1, i); ok[i] = Count(3, i); }
        if (calls[8] == 0)
            throw new InvalidOperationException("Launch this diagnostic with its LD_PRELOAD before ABI resolution.");
        return new(calls, pending, ok, Count(2, 0), Count(2, 1), Count(2, 2), Count(2, 3));
    }
}
