#!/usr/bin/env python3
"""Build and run isolated native correctness gates for the commit-proof experiment."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

BASE = Path('/workspace/scratch/4a65d70f0fe1')
parser = argparse.ArgumentParser()
parser.add_argument('--root', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--source', required=True)
parser.add_argument('--product-source', required=True)
parser.add_argument('--mode', choices=['negative', 'count', 'all'], required=True)
args = parser.parse_args()
root, output = args.root.resolve(), args.output.resolve()
output.mkdir(parents=True, exist_ok=False)
pg = BASE / 'tools/postgres/install/bin'
build = root / 'artifacts/cmake/linux-x64-release'

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def git(*command):
    return subprocess.check_output(['git', *command], cwd=root, text=True).strip()

def utc():
    return datetime.now(timezone.utc).isoformat()

assert git('rev-parse', 'HEAD') == args.source and not git('status', '--porcelain')
product_diff = git('diff', '--name-only', args.product_source, args.source, '--',
                   'src', 'native/cpp/src', 'native/cpp/include', 'native/database')
assert not product_diff, product_diff
source_files = [{'path': p, 'sha256': sha(root / p)} for p in
    git('ls-files', 'native', 'CMakeLists.txt', 'CMakePresets.json', 'tests/Data.Postgres/verify.py',
        'tests/Data.NativeHost/run.py', 'eng/check_native.py').splitlines()]
(output / 'source-files.json').write_text(json.dumps(source_files, indent=2) + '\n')
receipt = {'task': 'DB-Exec-08', 'scope': 'Independent PostgreSQL commit proof correctness experiment',
    'selectedForProduct': False, 'performanceCredit': False, 'publicPackageCredit': False,
    'sourceCommit': args.source, 'sourceTree': git('rev-parse', 'HEAD^{tree}'), 'productSource': args.product_source,
    'productDiff': product_diff, 'sourceDirty': False, 'mode': args.mode, 'startedUtc': utc(),
    'script': str(Path(__file__).resolve()), 'scriptSha256': sha(__file__),
    'sourceFilesSha256': sha(output / 'source-files.json'), 'commands': []}

def save():
    (output / 'result.json').write_text(json.dumps(receipt, indent=2) + '\n')

def run(label, argv, expected=0):
    argv = list(map(str, argv))
    path = output / (label + '.log')
    row = {'label': label, 'argv': argv, 'cwd': str(root), 'startedUtc': utc(), 'expectedExitCode': expected}
    receipt['commands'].append(row)
    save()
    with path.open('wb') as log:
        process = subprocess.run(argv, cwd=root, stdout=log, stderr=subprocess.STDOUT)
    row.update(exitCode=process.returncode, finishedUtc=utc(), log=str(path), logSha256=sha(path))
    save()
    print(json.dumps({'label': label, 'exitCode': process.returncode, 'expected': expected}), flush=True)
    if process.returncode != expected:
        raise RuntimeError(label + ' failed; original output retained at ' + str(path))

save()
try:
    run('configure', ['cmake', '--preset', 'linux-x64-release', '-DNW_BUILD_TESTS=ON',
        '-DFETCHCONTENT_SOURCE_DIR_NW_JSON=' + str(BASE / 'tools/native-dependencies/nlohmann-json/json'),
        '-DFETCHCONTENT_SOURCE_DIR_NW_SQLITE=' + str(BASE / 'tools/native-dependencies/sqlite/sqlite-amalgamation-3510300'),
        '-DPostgreSQL_ROOT=' + str(pg.parent)])
    targets = ['nw_postgres_sync_tests']
    if args.mode == 'all':
        targets += ['nw_postgres_fixture_tests', 'korda_postgres_fixture', 'korda_data_postgres', 'nw_transaction_tests']
    run('build', ['cmake', '--build', '--preset', 'linux-x64-release', '--target', *targets, '--parallel', '2'])
    executables = [build / 'tests/nw_postgres_sync_tests']
    if args.mode == 'all':
        executables += [build / 'tests/nw_postgres_fixture_tests', build / 'fixtures/libkorda_postgres_fixture.so',
                        build / 'fixtures/libkorda_data_postgres.so', build / 'tests/nw_transaction_tests']
    receipt['binaries'] = [{'path': str(p), 'sha256': sha(p), 'bytes': p.stat().st_size} for p in executables]
    receipt['compileCommandsSha256'] = sha(build / 'compile_commands.json')
    receipt['compilerProvenance'] = (build / 'compiler-provenance.txt').read_text()
    save()
    selector = [] if args.mode == 'all' else ['--commit-count-only']
    run('postgres-sync', [sys.executable, 'tests/Data.NativeHost/run.py', '--postgres-bin', pg,
        '--output', output / 'postgres-sync', '--', sys.executable, '-c',
        'import os,sys; os.execv(sys.argv[1], [sys.argv[1], os.environ["NW_TEST_POSTGRES"], *sys.argv[2:]])',
        executables[0], *selector], expected=1 if args.mode == 'negative' else 0)
    if args.mode == 'negative':
        log = (output / 'postgres-sync/consumer.log').read_text()
        assert 'COMMIT-DISPATCH route=nonquery sql=2 ' in log
        assert 'FAIL PostgreSQL protocol confirmations: healthy outer commit must dispatch only COMMIT; observed SQL dispatches=2' in log
        receipt['expectedNegativeReproduced'] = True
    if args.mode == 'all':
        run('native-transactions', ['ctest', '--test-dir', build, '--output-on-failure', '--no-tests=error',
                                   '-R', '^native.transactions$'])
        run('provider-fixtures', [sys.executable, 'tests/Data.Postgres/verify.py', '--native-only',
            '--test-only', '--design-root', BASE / 'worktrees/DB-Exec-02-design', '--postgres-bin', pg,
            '--native-build', build, '--output', output / 'provider-fixtures'])
    receipt['sourceUnchanged'] = git('rev-parse', 'HEAD') == args.source and not git('status', '--porcelain')
    receipt['binariesUnchanged'] = all(sha(row['path']) == row['sha256'] for row in receipt['binaries'])
    assert receipt['sourceUnchanged'] and receipt['binariesUnchanged']
    receipt['passed'] = True
except BaseException as error:
    receipt['passed'] = False
    receipt['failure'] = type(error).__name__ + ': ' + str(error)
    raise
finally:
    receipt['finishedUtc'] = utc()
    receipt['records'] = [{'path': str(p.relative_to(output)), 'sha256': sha(p), 'bytes': p.stat().st_size}
        for p in sorted(output.rglob('*')) if p.is_file() and p.suffix in ('.json', '.log', '.txt') and p != output / 'result.json'
        and not any(part.startswith('pg-') for part in p.relative_to(output).parts[:-1])]
    save()
    print(json.dumps({'receipt': str(output / 'result.json'), 'sha256': sha(output / 'result.json'), 'passed': receipt.get('passed')}), flush=True)
