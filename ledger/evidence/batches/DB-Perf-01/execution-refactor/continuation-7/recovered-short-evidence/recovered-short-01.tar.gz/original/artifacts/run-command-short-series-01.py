from pathlib import Path
import subprocess, json, datetime, hashlib, os, sys

root = Path('/workspace/scratch/4a65d70f0fe1')
index = root / 'artifacts/command-short-plans-01.json'
receipt = root / 'artifacts/command-short-series-01.json'
if receipt.exists():
    raise RuntimeError('Existing series is immutable')
for key in ('LD_PRELOAD', 'DB_PERF_ALLOC_PROFILE_LIBRARY', 'DB_PERF_ALLOC_CAPACITY',
            'DOTNET_PROCESSOR_COUNT', 'COMPlus_ThreadPool_ForceMinWorkerThreads'):
    if os.environ.get(key):
        raise RuntimeError('Unintended measurement override: ' + key)
records = []
for entry in json.loads(index.read_text()):
    path = Path(entry['plan'])
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    if digest != entry['planSha256']:
        raise RuntimeError('Frozen plan changed: ' + str(path))
    plan = json.loads(path.read_text())
    command = plan['runnerCommand']
    log = root / 'artifacts' / (entry['name'] + '-run.log')
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    print('START', entry['name'], start, flush=True)
    with log.open('xb') as stream:
        process = subprocess.run(command, cwd=root, stdout=stream, stderr=subprocess.STDOUT)
    records.append({'name': entry['name'], 'command': command, 'planSha256': digest,
                    'log': str(log), 'logSha256': hashlib.sha256(log.read_bytes()).hexdigest(),
                    'exitCode': process.returncode, 'startedUtc': start,
                    'finishedUtc': datetime.datetime.now(datetime.timezone.utc).isoformat()})
    receipt.write_text(json.dumps(records, indent=2) + '\n')
    print('FINISH', entry['name'], 'exit', process.returncode, flush=True)
    if process.returncode:
        sys.exit(process.returncode)
