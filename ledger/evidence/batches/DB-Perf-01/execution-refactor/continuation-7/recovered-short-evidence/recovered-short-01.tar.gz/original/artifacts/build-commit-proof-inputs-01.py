from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import subprocess
import sys

BASE = Path('/workspace/scratch/4a65d70f0fe1')
PROVIDER = 'postgresql'
SOURCE = BASE / 'worktrees/DB-Exec-08-pg-commit-proof'
EXPECTED = 'd2c137bf44eb0b8490c8c4f59f12f34d2df75ac2'
PUBLIC = '8789a45a52cc0cc0a0b62737542d9c120b753c9b'
RECEIPT = BASE / 'artifacts/commit-proof-build-postgresql-01.json'
records = []

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def run(stage, argv, build_dotnet=False):
    log = BASE / ('artifacts/commit-proof-' + PROVIDER + '-' + stage + '-01.log')
    environment = os.environ.copy()
    if build_dotnet:
        environment.update(DOTNET_PROCESSOR_COUNT='1', UseSharedCompilation='false', MSBUILDDISABLENODEREUSE='1')
    row = {'stage': stage, 'argv': list(map(str, argv)), 'cwd': str(SOURCE), 'startedUtc': now(),
           'buildOnlyProcessorCount': 1 if build_dotnet else None}
    with log.open('xb') as stream:
        result = subprocess.run(argv, cwd=SOURCE, env=environment, stdout=stream, stderr=subprocess.STDOUT)
    row.update(exitCode=result.returncode, finishedUtc=now(), log=str(log), logSha256=sha(log))
    records.append(row)
    RECEIPT.write_text(json.dumps({'sourceCommit': EXPECTED, 'sourceTree': tree, 'sourceDirty': False,
        'provider': PROVIDER, 'scriptSha256': sha(__file__), 'records': records,
        'sourceParity': {'path': str(PARITY), 'sha256': sha(PARITY)},
        'selectedForProduct': False, 'performanceCredit': False, 'publicCandidateCredit': False,
        'scope': 'Unselected local commit-proof experiment. Independent ordinary package and AOT build inputs; execution and performance are separate.'}, indent=2) + '\n')
    print(json.dumps({'provider': PROVIDER, 'stage': stage, 'exitCode': result.returncode}), flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)

head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=SOURCE, text=True).strip()
tree = subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=SOURCE, text=True).strip()
if head != EXPECTED or RECEIPT.exists():
    raise RuntimeError('Fresh exact clean experiment input required')
if subprocess.check_output(['git', 'status', '--porcelain'], cwd=SOURCE, text=True):
    raise RuntimeError('Producer checkout must be clean')
PARITY = BASE / 'artifacts/commit-proof-source-parity-01.json'
if not PARITY.is_file():
    raise RuntimeError('Record exact public source parity before building')
parity = json.loads(PARITY.read_text())
if parity['experimentCommit'] != EXPECTED or parity['publicCommit'] != PUBLIC or not parity['matched']:
    raise RuntimeError('Source parity receipt does not bind this experiment')
run('impact', [sys.executable, 'eng/ci/impact.py', 'origin/main', '--output', 'artifacts/plan.json'])
plan = json.loads((SOURCE / 'artifacts/plan.json').read_text())
if set(plan['actions']) != {'interop', 'linux', 'postgresql', 'sqlite'} or plan['run_steps']:
    raise RuntimeError('Unexpected CI selection; stop and explain before building')
native = BASE / ('artifacts/commit-proof-native-' + PROVIDER + '-01')
run('native', [sys.executable, 'eng/task07_native.py', '--provider', PROVIDER, '--output', native])
run('bundle', [sys.executable, 'eng/ci/bundles.py', '--provider', PROVIDER, '--plan', 'artifacts/plan.json',
               '--version', '0.1.0-ci.1', '--native', native / 'manifest.json'], build_dotnet=True)
run('public-validate', [sys.executable, 'eng/ci/validate_public.py', 'artifacts/public',
                       'artifacts/plan.json', '0.1.0-ci.1', '--module', PROVIDER])
package = BASE / 'artifacts/commit-proof-packages-01' / PROVIDER
shutil.copytree(SOURCE / 'artifacts/public', package)
for kind, suffix in (('workload', 'workload'),):
    run('consumer-' + suffix, [sys.executable, 'benchmarks/db-perf/managed/build.py', '--provider', PROVIDER,
        '--feed', package / 'feed', '--version', '0.1.0-ci.1', '--kind', kind,
        '--output', BASE / ('consumers/commit-proof-' + PROVIDER + '-' + suffix + '-01')], build_dotnet=True)
print(json.dumps({'provider': PROVIDER, 'receipt': str(RECEIPT), 'sha256': sha(RECEIPT)}), flush=True)
