from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET
import zipfile

BASE = Path('/workspace/scratch/4a65d70f0fe1')
SOURCE = BASE / 'worktrees/DB-Exec-08-pg-commit-proof'
EXPECTED = 'd2c137bf44eb0b8490c8c4f59f12f34d2df75ac2'
PUBLIC = '8789a45a52cc0cc0a0b62737542d9c120b753c9b'
NATIVE = BASE / 'artifacts/commit-proof-native-postgresql-01'
PACKAGES = BASE / 'artifacts/commit-proof-packages-01/postgresql'
CONSUMER = BASE / 'consumers/commit-proof-postgresql-workload-01'
REFERENCE = BASE / 'consumers/command-postgresql-workload-01'
OUTPUT = BASE / 'artifacts/commit-proof-input-verification-01.json'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def bound(path):
    path = Path(path)
    return {'path': str(path), 'sha256': sha(path), 'bytes': path.stat().st_size}


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


require(not OUTPUT.exists(), 'Use a fresh verification attempt')
require(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=SOURCE, text=True).strip() == EXPECTED,
        'Experiment checkout head changed')
require(not subprocess.check_output(['git', 'status', '--porcelain'], cwd=SOURCE), 'Experiment checkout became dirty')
parity_path = BASE / 'artifacts/commit-proof-source-parity-01.json'
parity = read(parity_path)
require(parity['experimentCommit'] == EXPECTED and parity['publicCommit'] == PUBLIC and parity['matched'],
        'Unexpected source parity')
for row in parity['files']:
    require(sha(SOURCE / row['path']) == row['sha256'], 'Source changed after parity: ' + row['path'])
outer_path = BASE / 'artifacts/commit-proof-build-outer-01.json'
require(read(outer_path)['exitCode'] == 0, 'Outer producer pipeline failed')
pipeline_path = BASE / 'artifacts/commit-proof-build-postgresql-01.json'
pipeline = read(pipeline_path)
require([row['stage'] for row in pipeline['records']] ==
        ['impact', 'native', 'bundle', 'public-validate', 'consumer-workload'], 'Unexpected build stages')
for row in pipeline['records']:
    require(row['exitCode'] == 0 and sha(row['log']) == row['logSha256'], 'Build record failed or changed')
manifest_path = NATIVE / 'manifest.json'
manifest = read(manifest_path)
require(manifest['sourceCommit'] == EXPECTED and not manifest['sourceDirty'] and
        manifest['profile'] == 'release' and manifest['preset'] == 'linux-x64-postgresql',
        'Native producer profile/source mismatch')
require(len(manifest['assets']) == 1 and manifest['assets'][0]['engineId'] == 'database.postgresql',
        'Unexpected provider inventory')
asset = manifest['assets'][0]
require(sha(asset['path']) == asset['sha256'], 'Produced native asset changed')
commands_path = NATIVE / 'compile_commands.json'
commands = read(commands_path)
product_commands = [row for row in commands if any('/CMakeFiles/' + target + '.dir/' in row['output']
                    for target in ('nw_database_common', 'nw_database_postgresql'))]
require(product_commands and any(row['file'].endswith('/host.cpp') for row in product_commands) and
        any(row['file'].endswith('/provider.cpp') for row in product_commands), 'Missing native product compile commands')
require(all('NW_HOST_TEST_HOOKS' not in row['command'] for row in product_commands),
        'Test hooks were compiled into product objects')
require(all('-O3' in row['command'] and '-DNDEBUG' in row['command'] for row in product_commands),
        'Native product does not use ordinary Release compilation')
packages = sorted((PACKAGES / 'feed').glob('*.nupkg'))
require(len(packages) == 1, 'Expected one independently installable provider package')
package_path = packages[0]
with zipfile.ZipFile(package_path) as archive:
    package_manifest = json.loads(archive.read('korda/manifest.json'))
    require(package_manifest['sourceCommit'] == EXPECTED and
            package_manifest['packagingProducerCommit'] == EXPECTED and
            package_manifest['nativeSha256'] == asset['sha256'] and not package_manifest['sourceDirty'],
            'Package producer/native source tuple mismatch')
    require(hashlib.sha256(archive.read(package_manifest['nativePath'])).hexdigest() == asset['sha256'],
            'Package embeds the wrong native image')
    nuspec_names = [name for name in archive.namelist() if name.endswith('.nuspec')]
    require(len(nuspec_names) == 1, 'Missing unique package nuspec')
    root = ET.fromstring(archive.read(nuspec_names[0]))
    repository = next((element.attrib for element in root.iter() if element.tag.rsplit('}', 1)[-1] == 'repository'), None)
consumer_path = CONSUMER / 'build-receipt.json'
consumer = read(consumer_path)
reference_path = REFERENCE / 'build-receipt.json'
reference = read(reference_path)
require(consumer['exit_code'] == 0 and not consumer.get('post_validation_error') and
        not consumer.get('postValidationError'), 'Consumer publish or postvalidation failed')
require(consumer['provider'] == 'postgresql' and consumer['kind'] == 'workload' and
        consumer['package'] == 'Korda.Database.PostgreSql' and consumer['version'] == '0.1.0-ci.1' and
        consumer['project_references'] == 0, 'Not an ordinary external package consumer')
require(consumer['package_sha256'] == sha(package_path), 'Consumer restored a different package')
for key in ('sources', 'project_sha256', 'global_json_sha256', 'builder_sha256', 'workloadManifestSha256'):
    require(consumer[key] == reference[key], 'Ordinary reference input mismatch: ' + key)
for name, digest in consumer['sources'].items():
    require(sha(CONSUMER / name) == digest and sha(REFERENCE / name) == digest, 'Actual consumer source differs: ' + name)
require(sha(CONSUMER / 'DbPerf.Korda.csproj') == consumer['project_sha256'], 'Consumer project changed')
require(sha(CONSUMER / 'global.json') == consumer['global_json_sha256'], 'Consumer SDK selection changed')
require(sha(CONSUMER / 'workload-manifest.json') == consumer['workloadManifestSha256'], 'Consumer workload manifest changed')
executable = CONSUMER / 'out/DbPerf.Korda'
require(executable.read_bytes()[:4] == b'\x7fELF' and not (CONSUMER / 'out/DbPerf.Korda.dll').exists(),
        'Expected a real Native AOT executable')
require(sha(executable) == consumer['executable_sha256'], 'Native AOT executable changed')
require(consumer['native_images'] == {'libnw_database_postgresql.so': asset['sha256']} and
        sha(CONSUMER / 'out/libnw_database_postgresql.so') == asset['sha256'], 'Consumer output native asset mismatch')
require('-p:PublishAot=true' in consumer['command'] and '-p:IlcTreatWarningsAsErrors=true' in consumer['command'] and
        'Release' in consumer['command'] and 'linux-x64' in consumer['command'], 'Unexpected consumer build profile')
result = {
    'schemaVersion': 1, 'observedUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'experimentCommit': EXPECTED, 'experimentTree': manifest['sourceTree'], 'publicReferenceCommit': PUBLIC,
    'allChecksPassed': True, 'selectedForProduct': False, 'performanceExecuted': False,
    'performanceCredit': False, 'publicCandidateCredit': False,
    'sourceParity': bound(parity_path), 'nativeProductPatch': bound(parity['nativeProductPatch']['path']),
    'outerBuild': bound(outer_path), 'pipeline': bound(pipeline_path),
    'nativeManifest': bound(manifest_path), 'nativeAsset': bound(asset['path']),
    'compileCommands': bound(commands_path), 'ordinaryProductObjectsWithoutHooks': len(product_commands),
    'nativeProductCompileFiles': [row['file'] for row in product_commands],
    'package': bound(package_path), 'packageManifest': package_manifest, 'nuspecRepository': repository,
    'consumerReceipt': bound(consumer_path), 'executable': bound(executable),
    'referenceConsumerReceipt': bound(reference_path),
    'matchedConsumerSources': consumer['sources'], 'matchedProjectSha256': consumer['project_sha256'],
    'matchedGlobalJsonSha256': consumer['global_json_sha256'],
    'matchedWorkloadManifestSha256': consumer['workloadManifestSha256'],
    'verifier': bound(__file__),
    'scope': 'Independent ordinary PostgreSQL package and workload Native AOT build for an unselected local experiment. No consumer invocation, no latency or throughput credit. Public 8789 and experiment managed/SQL/DTO input parity is exact; native helper patch is separately bound.'
}
OUTPUT.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'path': str(OUTPUT), 'sha256': sha(OUTPUT), 'nativeAssetSha256': asset['sha256'],
                  'packageSha256': sha(package_path), 'executableSha256': sha(executable),
                  'ordinaryProductObjectsWithoutHooks': len(product_commands)}))
