from pathlib import Path
import datetime
import hashlib
import json
import subprocess

BASE = Path('/workspace/scratch/4a65d70f0fe1')
ROOT = BASE / 'worktrees/DB-Exec-08-pg-commit-proof'
PUBLIC = '8789a45a52cc0cc0a0b62737542d9c120b753c9b'
EXPERIMENT = 'd2c137bf44eb0b8490c8c4f59f12f34d2df75ac2'
OUTPUT = BASE / 'artifacts/commit-proof-source-parity-01.json'
PATCH = BASE / 'artifacts/commit-proof-native-product-01.patch'
SCOPES = ('src', 'benchmarks/db-perf/managed/Korda', 'benchmarks/db-perf/managed/Shared')
BUILD_INPUTS = ('global.json', 'benchmarks/db-perf/managed/build.py',
                'benchmarks/db-perf/workload/queries-v3.json',
                'eng/task07_native.py', 'eng/ci/bundles.py', 'eng/ci/validate_public.py')
PRODUCT_DIFF = ('native/cpp/include/nw/provider.hpp', 'native/cpp/src/host.cpp',
                'native/cpp/src/provider.cpp')


def git(*args, data=None):
    return subprocess.check_output(['git', *args], input=data, cwd=ROOT)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def files(ref, paths):
    result = {}
    for record in git('ls-tree', '-r', '-z', ref, '--', *paths).split(b'\0'):
        if not record:
            continue
        metadata, path = record.split(b'\t', 1)
        mode, kind, oid = metadata.decode().split(' ')
        if kind != 'blob':
            raise RuntimeError('Unexpected non-blob source input')
        result[path.decode()] = {'mode': mode, 'gitBlob': oid}
    return result


if OUTPUT.exists() or PATCH.exists():
    raise RuntimeError('Use a fresh immutable parity attempt')
if git('rev-parse', 'HEAD').decode().strip() != EXPERIMENT or git('status', '--porcelain'):
    raise RuntimeError('Exact clean experiment checkout required')
public = files(PUBLIC, (*SCOPES, *BUILD_INPUTS))
experiment = files(EXPERIMENT, (*SCOPES, *BUILD_INPUTS))
if public != experiment:
    raise RuntimeError('Requested source or ordinary builder inputs differ')
names = sorted(experiment)
if not names or any('\n' in path for path in names):
    raise RuntimeError('Invalid source input inventory')
working = git('hash-object', '--stdin-paths', data=('\n'.join(names) + '\n').encode()).decode().splitlines()
if len(working) != len(names):
    raise RuntimeError('Incomplete working file hash verification')
rows = []
for name, oid in zip(names, working, strict=True):
    if oid != experiment[name]['gitBlob']:
        raise RuntimeError('Working file differs from commit: ' + name)
    payload = (ROOT / name).read_bytes()
    rows.append({'path': name, 'publicGitBlob': public[name]['gitBlob'],
                 'experimentGitBlob': experiment[name]['gitBlob'],
                 'workingGitBlob': oid, 'mode': experiment[name]['mode'],
                 'sha256': sha(payload), 'bytes': len(payload)})
native_diff = git('diff', '--name-only', PUBLIC, EXPERIMENT, '--',
                  'native/cpp/include', 'native/cpp/src').decode().splitlines()
if tuple(native_diff) != PRODUCT_DIFF:
    raise RuntimeError('Unexpected native product delta: ' + repr(native_diff))
patch = git('diff', '--binary', PUBLIC, EXPERIMENT, '--', *PRODUCT_DIFF)
PATCH.write_bytes(patch)
all_diff = git('diff', '--name-only', PUBLIC, EXPERIMENT).decode().splitlines()
others = [name for name in all_diff if name not in PRODUCT_DIFF]
record = {
    'schemaVersion': 1, 'observedUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'experimentCommit': EXPERIMENT, 'experimentTree': git('rev-parse', EXPERIMENT + '^{tree}').decode().strip(),
    'publicCommit': PUBLIC, 'publicTree': git('rev-parse', PUBLIC + '^{tree}').decode().strip(),
    'sourceCheckout': str(ROOT), 'sourceDirty': False, 'matched': True,
    'matchedScopes': list(SCOPES), 'additionalMatchedBuilderInputs': list(BUILD_INPUTS),
    'matchedFileCount': len(rows), 'files': rows,
    'nativeProductChangedFiles': native_diff,
    'nativeProductPatch': {'path': str(PATCH), 'sha256': sha(patch), 'bytes': len(patch)},
    'otherWholeTreeDifferences': others,
    'otherDifferencesScope': 'The experiment branched from 8736d93. Later public Dapper lifecycle tooling and independent test changes are absent; these files are not inputs to the Korda workload build. Full trees are not equal.',
    'builder': {'path': str(BASE / 'artifacts/build-commit-proof-inputs-01.py'),
                'sha256': sha((BASE / 'artifacts/build-commit-proof-inputs-01.py').read_bytes())},
    'recorder': {'path': str(Path(__file__).resolve()), 'sha256': sha(Path(__file__).read_bytes())},
    'selectedForProduct': False, 'performanceCredit': False, 'publicCandidateCredit': False,
    'scope': 'Byte-for-byte ordinary Korda workload/managed product inputs and the exact independent PostgreSQL helper patch. Production manifests, package validation, AOT publish and runtime measurements remain separate.'
}
OUTPUT.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'path': str(OUTPUT), 'sha256': sha(OUTPUT.read_bytes()), 'matchedFileCount': len(rows),
                  'nativeProductChangedFiles': native_diff, 'otherWholeTreeDifferences': others}))
