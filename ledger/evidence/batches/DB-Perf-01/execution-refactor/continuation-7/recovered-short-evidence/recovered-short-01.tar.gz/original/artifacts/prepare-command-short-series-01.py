from pathlib import Path
import hashlib, json, subprocess, sys

root = Path('/workspace/scratch/4a65d70f0fe1')
source = root / 'worktrees/DB-Exec-02-continuation'
evidence = root / 'worktrees/DB-Exec-02-plan/ledger/evidence/batches/DB-Perf-01/execution-refactor'
single = evidence / 'continuation-5/generate_single_case_plan.py'
phase = evidence / 'continuation-4/generate_local_plan.py'
index = root / 'artifacts/command-short-plans-01.json'
if index.exists():
    raise RuntimeError('Fresh plan index required')
specs = []
for provider in ('sqlite', 'postgresql'):
    specs.extend([
        (f'single-row-matched-{provider}-01', provider, 'ordinary', f'row-{provider}-workload'),
        (f'single-command-{provider}-01', provider, 'ordinary', f'command-{provider}-workload-01')])
specs.append(('single-commit-proof-postgresql-01', 'postgresql', 'ordinary', 'commit-proof-postgresql-workload-01'))
specs.extend((f'ffi-single-command-{p}-01', p, 'diagnostic', f'command-{p}-workload-01')
             for p in ('sqlite', 'postgresql'))
specs.extend((f'phases-command-{p}-01', p, 'phases', f'command-{p}-phases-01')
             for p in ('sqlite', 'postgresql'))
records = []
for name, provider, lane, candidate in specs:
    plan = root / 'measurements/plans' / (name + '.json')
    output = root / 'measurements' / name
    native = ['--sqlite-library', str(root / 'consumers/direct-native/libsqlite3.so')] if provider == 'sqlite' else [
        '--postgres-bin', str(root / 'tools/postgres/install/bin')]
    if lane == 'phases':
        args = [sys.executable, str(phase), '--source', str(source), '--provider', provider,
                '--lane', lane, '--before-dir', str(root / 'consumers' / f'row-{provider}-phases/out'),
                '--candidate-dir', str(root / 'consumers' / candidate / 'out'),
                '--dapper-dir', str(root / 'consumers' / f'dapper-{provider}-phases/out')]
    else:
        args = [sys.executable, str(single), '--source', str(source), '--provider', provider,
                '--lane', lane, '--korda-dir', str(root / 'consumers' / candidate / 'out'),
                '--dapper-dir', str(root / 'consumers' / f'dapper-matched-{provider}-01/out')]
        if lane == 'diagnostic':
            args += ['--diagnostic-dir', str(root / 'consumers' / f'ffi-command-{provider}-workload-01/out')]
    args += native + ['--plan', str(plan), '--output', str(output)]
    result = subprocess.run(args, cwd=root, capture_output=True, text=True)
    if result.returncode:
        print(result.stdout, result.stderr)
        raise RuntimeError('Plan generation failed: ' + name)
    records.append({'name': name, 'provider': provider, 'lane': lane, 'generatorCommand': args,
                    'plan': str(plan), 'planSha256': hashlib.sha256(plan.read_bytes()).hexdigest(),
                    'output': str(output)})
with index.open('x') as stream:
    json.dump(records, stream, indent=2)
    stream.write('\n')
print(json.dumps({'plans': len(records), 'index': str(index)}))
