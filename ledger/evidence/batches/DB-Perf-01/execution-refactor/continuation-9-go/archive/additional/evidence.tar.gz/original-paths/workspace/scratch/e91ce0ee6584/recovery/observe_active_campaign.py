#!/usr/bin/env python3
"""Small read-only observer; cannot grant acceptance or launch workloads."""
import datetime
import json
from pathlib import Path
import shutil
import time

root = Path('/workspace/scratch/fd78534029f7/measurements')
record = Path('/workspace/scratch/e91ce0ee6584/recovery/active-campaign-observations-01.jsonl')
supervisor = Path('/workspace/scratch/166b48a091b9/recovery/campaign-supervisor-01.json')

def latest_sample(path):
    with path.open('rb') as stream:
        first = json.loads(stream.readline())
        stream.seek(max(0, path.stat().st_size - 65536))
        lines = stream.read().splitlines()
    for line in reversed(lines):
        try:
            return first, json.loads(line)
        except json.JSONDecodeError:
            continue
    return first, first

with record.open('x') as output:
    for iteration in range(220):
        now = datetime.datetime.now(datetime.timezone.utc)
        observation = {'observedUtc': now.isoformat(), 'scope': 'progress only; no acceptance',
                       'freeBytes': shutil.disk_usage('/workspace').free, 'completed': [], 'active': []}
        if supervisor.exists():
            state = json.loads(supervisor.read_text())
            observation['supervisorStatus'] = state.get('status')
            observation['supervisorRuns'] = [{'provider': r['provider'], 'status': r['status']} for r in state['runs']]
        for provider, concurrency in [('sqlite', 4), ('postgresql', 8)]:
            directory = root / (provider + '-final-01')
            for cohort in ['candidate', 'dapper']:
                name = f'{cohort}-c{concurrency}'
                receipt = directory / (name + '.command.json')
                samples = directory / (name + '.resources.jsonl')
                if receipt.exists():
                    data = json.loads(receipt.read_text())
                    observation['completed'].append({'provider': provider, 'cohort': cohort, 'success': data['success'],
                                                     'exitCode': data['exitCode'], 'finishedUtc': data['finishedUtc']})
                elif samples.exists() and samples.stat().st_size:
                    first, latest = latest_sample(samples)
                    observation['active'].append({'provider': provider, 'cohort': cohort, 'utc': latest['utc'],
                        'observedSeconds': round((latest['monotonicNs'] - first['monotonicNs']) / 1e9, 2),
                        'rssBytes': latest['clientTotals']['sampledRssBytes'],
                        'sampleAgeSeconds': round((now - datetime.datetime.fromisoformat(latest['utc'])).total_seconds(), 2)})
        encoded = json.dumps(observation, separators=(',', ':'))
        output.write(encoded + '\n')
        output.flush()
        print(encoded, flush=True)
        if len(observation['completed']) == 4 or any(not r['success'] for r in observation['completed']):
            break
        time.sleep(50)
