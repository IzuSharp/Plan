"""Read-only verification of downloaded DB-CPP-01 official main archives."""
from pathlib import Path
from functools import lru_cache
import hashlib
import json
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parent
E = ROOT / 'product-main-evidence'
C = ROOT / 'product-main-candidate'
REPO = ROOT.parent / '.worktree/DB-CPP-01-linux/NativeWeave'
COMMIT = '3badc05be503991b5591732629dd7e5b0dbad111'
TREE = '3264de79b73c8a89f1cac1eff57d0c0ff2c841c2'
HASHES = {}

def sha_bytes(data):
    return hashlib.sha256(data).hexdigest()

def sha(path):
    return sha_bytes(path.read_bytes())

def load(rel):
    p = E / rel
    HASHES[rel] = sha(p)
    d = json.loads(p.read_text())
    return d.get('data', d) if d.get('sanitized') else d

@lru_cache(None)
def source(path):
    return subprocess.check_output(['git', 'show', COMMIT + ':' + path], cwd=REPO)

def sources(mapping):
    for path, expected in mapping.items():
        assert sha_bytes(source(path)) == expected, ('source hash', path)
    return len(mapping)

def identity(d, key='source_commit'):
    assert d[key] == COMMIT

assert subprocess.check_output(['git', 'rev-parse', COMMIT + '^{tree}'], cwd=REPO, text=True).strip() == TREE
metadata = json.loads((ROOT/'main-artifact-metadata.json').read_text())['artifacts']
archives = []
for item in metadata:
    name = 'product-main-candidate.zip' if 'database-linux' in item['name'] else 'product-main-evidence.zip'
    p = ROOT/name
    assert sha(p) == item['digest'].removeprefix('sha256:')
    assert p.stat().st_size == item['size_in_bytes']
    assert not item['expired']
    assert item['workflow_run']['id'] == 44977773509
    assert item['workflow_run']['head_sha'] == COMMIT
    assert item['workflow_run']['head_branch'] == 'main'
    archives.append({k:item[k] for k in ('id','name','size_in_bytes','digest') } | {'download_sha256':sha(p),'digest_verified':True})

pipelines = []
native_maps = {}
for pipeline in ('db-scope','cpp-clean'):
    nd = E/pipeline/'native-build'
    n = load(pipeline+'/native-build/manifest.json')
    ppath = C/pipeline/'prepared/manifest.json'
    m = json.loads(ppath.read_text())
    assert (E/pipeline/'prepared/evidence/manifest.json').read_bytes() == ppath.read_bytes()
    if pipeline == 'db-scope':
        assert (E/pipeline/'prepared/manifest.json').read_bytes() == ppath.read_bytes()
    assert n['sourceCommit'] == m['sourceCommit'] == m['nativeSourceCommit'] == COMMIT
    assert n['sourceTree'] == TREE and not n['sourceDirty'] and not m['sourceDirty']
    assert n['language'] == 'C++20' and n['preset'] == 'linux-x64-release'
    assert n['rid'] == m['rid'] == 'linux-x64'
    assert n['target'] == 'x86_64-unknown-linux-gnu'
    assert all('23.1.5' in n['tools'][tool]['version'] for tool in ('clang','clang++','clang-format','clang-tidy'))
    assert m['nativeInputManifestSha256'] == sha(nd/'manifest.json')
    assert n['dependenciesLockSha256'] == sha_bytes(source('native/dependencies.lock.json'))
    input_count = sources(n['inputSha256'])
    assert len(n['commands']) == 3
    for cmd in n['commands']:
        assert cmd['exitCode'] == 0
        assert sha(nd/'logs'/Path(cmd['path']).name) == cmd['sha256']
    inventory = load(pipeline+'/prepared/evidence/source-inventory.json')
    identity(inventory,'sourceCommit')
    inventory_count = sources(inventory['files'])
    native = {Path(x['path']).name:x for x in n['assets']}
    assert set(native) == {'libnw_database_postgresql.so','libnw_database_sqlite.so'}
    packages = []
    seen_payloads = set()
    assert len(m['candidate']['packages']) == 12
    for pkg in m['candidate']['packages']:
        pp = ppath.parent/pkg['path']
        assert sha(pp) == pkg['sha256']
        identity(pkg,'sourceCommit')
        with zipfile.ZipFile(pp) as z:
            nuspecs = [x for x in z.namelist() if x.endswith('.nuspec')]
            assert len(nuspecs) == 1
            spec = ET.fromstring(z.read(nuspecs[0]))
            repo = spec.find('.//{*}repository')
            assert repo is not None and repo.attrib['commit'] == COMMIT
            assert spec.findtext('.//{*}id') == pkg['id']
            assert spec.findtext('.//{*}version') == pkg['version']
            for member in z.namelist():
                if '/native/' in member:
                    name = Path(member).name
                    assert name in native
                    assert sha_bytes(z.read(member)) == native[name]['sha256']
                    assert len(z.read(member)) == native[name]['bytes']
                    seen_payloads.add(name)
        packages.append({k:pkg[k] for k in ('id','version','sha256','sourceCommit')})
    assert seen_payloads == set(native)
    native_maps[pipeline] = native
    pipelines.append({'pipeline':pipeline,'native_manifest_sha256':sha(nd/'manifest.json'),
        'package_manifest_sha256':sha(ppath),'package_count':len(packages),'packages':packages,
        'all_package_hashes_and_nuspec_commits_verified':True,'native_payloads_equal_producer_hashes':True,
        'native_source_inputs_equal_git_files':input_count,'package_source_inputs_equal_git_files':inventory_count,
        'native_producer_commands':3,'native_producer_log_hashes_verified':True,
        'project_compiler':'Clang 23.1.5','target':n['target'],'language':n['language'],
        'rust_tool_visibility_on_producer_path':{k:bool(v) for k,v in n['rustOnPath'].items()},
        'native_assets':[{'engine':v['engineId'],'filename':k,'sha256':v['sha256']} for k,v in native.items()]})

verification = load('verification.json')
assert verification['status'] == 'passed' and verification['source'] == {'commit':COMMIT,'tree':TREE}
assert verification['nativeManifestSha256'] == pipelines[0]['native_manifest_sha256']
assert verification['candidateManifestSha256'] == pipelines[0]['package_manifest_sha256']
assert 'same-source-rust-cpp-business-parity' not in verification['checks']

reg = load('db-scope/regressions/result.json')
assert reg['status'] == 'passed' and reg['source'] == {'commit':COMMIT,'tree':TREE}
assert len(reg['commands']) == 57
for cmd in reg['commands']:
    assert cmd['exitCode'] == 0
    assert sha(E/'db-scope/regressions'/cmd['log']) == cmd['sha256']
ctest_log = E/'db-scope/regressions/logs/native-component-regressions.log'
ctext = ctest_log.read_text()
assert '100% tests passed, 0 tests failed out of 20' in ctext

interop = load('cpp-interop-properties/result.json')
identity(interop)
assert interop['passed'] and not interop['source_dirty'] and interop['source_unchanged']
assert not interop['preparation_only'] and len(interop['commands']) == 45
for cmd in interop['commands']:
    assert cmd['exit'] in cmd['expected_exit'] and not cmd['timed_out']
    for stream in ('stdout','stderr'):
        assert sha(E/'cpp-interop-properties'/(cmd['label']+'.'+stream)) == cmd[stream+'_sha256']
a20_source_count = sources(interop['source_sha256'])
assert all(interop['sanitizer'][x] is True for x in ('address','undefined_behavior','leaks'))
assert any(c['label']=='fuzz-execute' and '-runs=20000' in c['argv'] for c in interop['commands'])

compat = load('cpp-compatibility/result.json')
identity(compat)
assert compat['passed'] and compat['source_stable'] and not compat['source_dirty'] and not compat['prepare_only']
assert compat['matrix_rows'] == 20 and compat['policy_cases'] == 30 and compat['commands'] == 85

asan_rel = 'cmake/linux-x64-asan-ubsan/Testing/Temporary/LastTest.log'
asan_log = (E/asan_rel).read_text()
assert len(re.findall(r'^\d+/19 Testing:',asan_log,re.M)) == 19
assert asan_log.count('Test Passed.') + asan_log.count('Test Pass Reason:') == 19
assert 'Test Failed' not in asan_log
asan_source = source('eng/verify-cpp-sanitizers.sh').decode()
assert 'detect_leaks=1' in asan_source
assert '"status":"passed"' in (E/'cpp-sanitizers/administration/consumer.log').read_text()
assert 'host review: input-postgresql passed' in (E/'cpp-sanitizers/input/consumer.log').read_text()
assert 'PASS PostgreSQL protocol confirmations: 214 checks' in (E/'cpp-sanitizers/sync/consumer.log').read_text()
provider = load('cpp-sanitizers/provider/summary.json')
assert provider['status'] == 'passed' and provider['servers_stopped'] == 3

def consumer(rel, pipeline, pristine=False):
    d=load(rel)
    identity(d)
    assert d['passed'] and d['outside_source_tree'] and not d['rust_invocation_trap_fired']
    assert d['pristine_machine'] is pristine
    assert d['consumer_environment'] == ('pristine' if pristine else 'local')
    assert d['manifestSha256'] == next(x['package_manifest_sha256'] for x in pipelines if x['pipeline']==pipeline)
    assert set(d['graphs']) == {'combined','postgresql','sqlite'}
    sources(d['sourceInputs'])
    cases = 0
    for graph in d['graphs'].values():
        assert set(graph['nativeBefore']) == set(graph['nativeAfter'])
        for engine, before in graph['nativeBefore'].items():
            after = graph['nativeAfter'][engine]
            assert all(before[k] == after[k] for k in ('sha256','facade','facadeVersion','record'))
            assert Path(before['relativePath']).name == Path(after['relativePath']).name
        for record in graph['nativeAfter'].values():
            name = Path(record['relativePath']).name
            assert record['sha256'] == native_maps[pipeline][name]['sha256']
        for mode in ('initialJit','editedJit','aot'):
            for row in graph.get(mode,[]):
                assert row['dynamicCodeSupported'] is (mode!='aot')
                for n in row['nativeLibraries']:
                    assert n['sha256'] == native_maps[pipeline][n['file']]['sha256']
                cases += 1
    assert d['graphs']['combined']['addedEntityDto']
    if pristine: assert all(d['host_rust_absence_before_isolation'].values())
    return {'passed':True,'provider_mode_records':cases,'graphs':3,'outside_source_tree':True,
        'changed_entity_native_hash_unchanged':True,'loaded_native_hashes_equal_producer':True,
        'consumer_environment':d['consumer_environment'],'pristine_machine':d['pristine_machine']}

normal_consumer=consumer('db-scope/local-consumer/evidence/receipt.json','db-scope')
fresh_consumer=consumer('cpp-clean/local-consumer/evidence/receipt.json','cpp-clean')
pristine_consumer=consumer('db-scope/release/evidence/candidate-destination/receipt.json','db-scope',True)
fresh=load('cpp-clean/receipt.json')
identity(fresh,'sourceCommit')
assert fresh['status']=='passed' and all(fresh['rustToolsAbsent'].values())
assert fresh['freshNativeBuildImage'] and fresh['consumerVerifierEnvironment']=='local'
assert fresh['nativeManifestSha256']==pipelines[1]['native_manifest_sha256']
assert fresh['packagesManifestSha256']==pipelines[1]['package_manifest_sha256']
assert fresh['consumerResultSha256']==sha(E/'cpp-clean/local-consumer/evidence/receipt.json')
fresh_native=load('cpp-clean/native-build/manifest.json')
assert not any(fresh_native['rustOnPath'].values())

release=load('db-scope/release/evidence/result.json')
identity(release,'sourceCommit')
assert release['passed'] and release['status']=='completed'
assert len(release['cases'])==14 and all(x['passed'] for x in release['cases'])
assert release['manifestSha256']==pipelines[0]['package_manifest_sha256']
for target in ('previous-destination','candidate-destination','rollback-destination'):
    d=load('db-scope/release/evidence/'+target+'/receipt.json')
    assert d['passed'] and d['pristine_machine'] and d['consumer_environment']=='pristine'
    assert all(d['host_rust_absence_before_isolation'].values())

runtime=load('db-scope/runtime/evidence/receipt.json')
identity(runtime)
assert runtime['passed'] and all(runtime['toolAbsence'].values())
assert runtime['manifestSha256']==sha(E/'db-scope/release/evidence/candidate-destination/runtime-transfer-manifest.json')
assert len(runtime['cases'])==4 and all(x['passed'] and x['processExited'] for x in runtime['cases'])
for row in runtime['cases']:
    for n in row['receipt']['nativeLibraries']:
        assert n['sha256']==native_maps['db-scope'][n['file']]['sha256']

core=load('task04/A14/ci/result.json')
identity(core,'commit')
assert core['passed'] and not core['dirty'] and core['complete_core_closure']
cpu=load('task04/A14/minimum-cpu/result.json')
identity(cpu)
assert cpu['passed']
core_rt=load('task04/runtime/a14.json')
identity(core_rt)
assert core_rt['passed'] and all(core_rt['tool_absence'].values())

business={}
for name in ('database-lifecycle','database-business'):
    d=load('db-scope/'+name+'/progress.json')
    assert d['source']['commit']==COMMIT
    assert set(d['rows'])=={'sqlite-jit','sqlite-aot','postgresql-jit','postgresql-aot'}
    assert all(x['status']=='passed' for x in d['rows'].values())
    business[name]={'rows_passed':4,'providers':['sqlite','postgresql'],'modes':['jit','aot']}

for rel in (asan_rel,'db-scope/regressions/logs/native-component-regressions.log',
    'cpp-sanitizers/administration/consumer.log','cpp-sanitizers/input/consumer.log','cpp-sanitizers/sync/consumer.log',
    'db-scope/release/evidence/candidate-destination/runtime-transfer-manifest.json'):
    HASHES[rel]=sha(E/rel)

summary={
    'schema_version':2,'task':'DB-CPP-01','kind':'official-main-artifact-verification','passed':True,
    'scope':'Read-only re-verification of the official merged-main archives; no new database execution or historical Rust comparison was performed.',
    'sources':{'NativeWeave':{'commit':COMMIT,'tree':TREE}},
    'ci':{'repository':'IzuSharp/NativeWeave','run_id':44977773509,'run_attempt':1,
        'url':'https://github.com/IzuSharp/NativeWeave/actions/runs/44977773509','event':'push','branch':'main',
        'complete_run_jobs_validation':'Recorded separately in the exact merged-main CI receipt.'},
    'official_artifacts':archives,'production_package_hash_chains':pipelines,
    'verification':{'status':'passed','checks':verification['checks'],'manifest_links_verified':True},
    'retained_regressions':{'status':'passed','commands':57,'all_exits_zero':True,'all_command_log_hashes_verified':True,'release_ctest_tests':20,'release_ctest_failed':0},
    'native_sanitizers':{'preset':'linux-x64-asan-ubsan','ctest_tests':19,'ctest_all_accepted':True,'source_enforces_detect_leaks':True,
        'postgres_administration_passed':True,'postgres_parameter_admission_passed':True,'postgres_protocol_confirmation_checks':214,
        'provider_summary_passed':True,'provider_servers_stopped':3},
    'interop_a20':{'passed':True,'commands':45,'all_exit_codes_in_expected_set':True,'all_timeouts_false':True,
        'all_90_stdout_stderr_hashes_verified':True,'source_files_equal_exact_git_commit':a20_source_count,
        'address':True,'undefined_behavior':True,'leaks':True,'fuzz_runs':20000},
    'compatibility_a15':{'passed':True,'source_stable':True,'source_dirty':False,'matrix_rows':20,'policy_cases':30,'commands':85},
    'normal_consumer':normal_consumer,'fresh_consumer':fresh_consumer,'pristine_candidate_consumer':pristine_consumer,
    'fresh_no_rust_build':{k:fresh[k] for k in ('status','image','rustToolsAbsent','freshNativeBuildImage','consumerVerifierEnvironment','separatePristineSdkGate','nativeManifestSha256','packagesManifestSha256','consumerResultSha256')},
    'database_distribution':{'release_recovery_passed':True,'release_cases':14,'all_release_cases_passed':True,'pristine_sdk_receipts_verified':3,
        'runtime_only_transfer_passed':True,'runtime_cases':4,'runtime_tool_absence':runtime['toolAbsence'],'runtime_manifest_link_verified':True},
    'core_distribution':{'closure_passed':True,'minimum_cpu_passed':True,'runtime_only_transfer_passed':True,'runtime_tool_absence':core_rt['tool_absence']},
    'business_evidence':business,'evidence_sha256':HASHES,'blocking_findings':[],
    'limits':[
        'The normal GitHub runner recorded Rust tools visible on PATH; it is not the Rust-free host proof. The separate fresh image records all three Rust tools absent and its own native/package/consumer hash chain.',
        'The fresh image mounts checksum-locked upstream tools, already-built libpq and dependency caches read-only; these upstream inputs are not rebuilt inside the image. This is documented in the exact build script.',
        'The fresh image consumer is local to that image. Separate pristine SDK consumption and runtime-only transfer retain their own receipts.',
        'Normal and fresh native assets are each verified against their own producer. No cross-environment bit-identical-build claim is made.',
        'Main does not repeat the finite historical Rust/C++ comparison. That evidence remains at the tested PR candidate and its original hashes.',
        'Artifact verification reads saved JSON, hashes, package ZIP payloads, logs and exact Git objects. It performs no new runtime tests and does not replace the separate exact run/jobs receipt.',
        'Earlier candidate failures are unchanged. Native negative quarantine/error controls retain their explicit semantics and are not ordinary successful resource-release claims.'
    ],
    'privacy':'Explicit public-source, aggregate-result, tool-absence and integrity-hash allowlist; no raw argv, environment values, machine paths, runner identities, credentials or logs.'
}
dest=ROOT/'main-ci-completion-summary.json'
dest.write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'passed':True,'summary':str(dest),'sha256':sha(dest),'packages':24,'regression_commands':57,'a20_commands':45}))
