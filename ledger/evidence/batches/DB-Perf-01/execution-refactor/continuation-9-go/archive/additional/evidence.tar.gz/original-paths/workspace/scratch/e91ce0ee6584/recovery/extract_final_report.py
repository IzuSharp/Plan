#!/usr/bin/env python3
"""Copy final measurement fields with provenance; no new statistics or acceptance."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
from pathlib import Path


MISSING = object()


def read(path: Path):
    with path.open(encoding="utf-8") as stream:
        return json.load(stream)


def resolve(document, pointer: str):
    value = document
    for token in pointer.split("/")[1:]:
        token = token.replace("~1", "/").replace("~0", "~")
        try:
            value = value[int(token)] if isinstance(value, list) else value[token]
        except (KeyError, IndexError, TypeError, ValueError):
            return MISSING
    return value


def copy_field(document, path: Path, pointer: str):
    value = resolve(document, pointer)
    return {
        "present": value is not MISSING,
        "value": None if value is MISSING else value,
        "source": {"path": str(path), "jsonPointer": pointer},
    }


def fields(document, path, pointers):
    return {name: copy_field(document, path, pointer) for name, pointer in pointers.items()}


ANALYSIS_FIELDS = {
    "state": "/state",
    "timingCredit": "/timingCredit",
    "metricUse": "/metricUse",
    "issues": "/issues",
    "businessValidation": "/businessValidation",
    "successfulThroughputThroughDrain": "/metrics/successfulThroughputThroughDrain",
    "requestedArrivalRate": "/metrics/requestedArrivalRate",
    "actualOfferedProducerSeconds": "/metrics/actualOfferedProducerSeconds",
    "normalizedMeasurement": "/metrics/measurement/normalized",
    "offeredLatency": "/metrics/measurement/histograms/offered",
    "serviceLatency": "/metrics/measurement/histograms/service",
    "allCompletedOfferedLatency": "/metrics/measurement/histograms/all_terminal_offered",
    "latencyPopulationScope": "/metrics/latencyPopulationScope",
    "queueLatencyScope": "/metrics/queueLatencyScope",
    "errorsAndRejections": "/metrics/measurement/errors",
    "clientCpu": "/metrics/client/cpu",
    "clientMemory": "/metrics/client/memory",
    "managedAllocationAndGc": "/metrics/client/managed",
    "clientIdle": "/metrics/client/idle",
    "idleRssBytes": "/metrics/idleRssBytes",
    "ownersAndActivity": "/metrics/owners",
    "observerSampledMemory": "/resources/sampledMemory",
    "observerProcessLifetime": "/resources/processLifetimeWait4",
    "serverCpuScope": "/resources/serverCpuScope",
    "serverCpuGroupPresent": "/resources/serverCpuGroupPresent",
    "host": "/host",
    "boundaryAlignment": "/metrics/client/boundary_alignment",
}

RAW_FIELDS = {
    "route": "/Route", "provider": "/Provider", "nativeAot": "/NativeAot",
    "packageVersion": "/PackageVersion", "executableSha256": "/ExecutableSha256",
    "loadedNativePath": "/LoadedNativePath", "loadedNativeSha256": "/LoadedNativeSha256",
    "startedUtc": "/StartedUtc", "finishedUtc": "/FinishedUtc",
    "steadyStartMonotonicNs": "/SteadyStartMonotonicNs",
    "steadyEndMonotonicNs": "/SteadyEndMonotonicNs", "effectiveSeconds": "/EffectiveSeconds",
    "allocatedBefore": "/AllocatedBefore", "allocatedAfter": "/AllocatedAfter",
    "allocatedBytes": "/AllocatedBytes",
    "bytesPerSuccessfulOperation": "/BytesPerSuccessfulOperation", "bytesPerRow": "/BytesPerRow",
    "allocationAttribution": "/AllocationAttribution",
    "steadyGcGen0": "/Gen0", "steadyGcGen1": "/Gen1", "steadyGcGen2": "/Gen2",
    "offeredEndCumulativeGcGen0": "/OfferedLoad/Gen0AtOfferedEnd",
    "offeredEndCumulativeGcGen1": "/OfferedLoad/Gen1AtOfferedEnd",
    "offeredEndCumulativeGcGen2": "/OfferedLoad/Gen2AtOfferedEnd",
    "offeredEndCumulativeAllocatedBytes": "/OfferedLoad/AllocatedAtOfferedEnd",
    "processBefore": "/ProcessBefore", "processAfter": "/ProcessAfter",
    "userCpuSeconds": "/UserCpuSeconds", "systemCpuSeconds": "/SystemCpuSeconds",
    "cpuSecondsPerSuccessfulOperation": "/CpuSecondsPerSuccessfulOperation",
    "beforeOwners": "/Before", "afterOwners": "/After", "drainedOwners": "/Drained",
    "kordaOwnersReturnedToZero": "/OwnersReturnedToZero",
    "dapperApplicationConnectionsReturnedToZero": "/ApplicationConnectionsReturnedToZero",
    "errors": "/Errors", "offeredErrorClasses": "/OfferedLoad/ErrorClasses",
    "offeredErrors": "/OfferedLoad/Errors",
    "oracleFailures": "/OracleFailures", "firstOracleFailure": "/FirstOracleFailure",
    "offeredPlanned": "/OfferedLoad/Planned", "offeredAttempted": "/OfferedLoad/Attempted",
    "offeredSent": "/OfferedLoad/Sent", "offeredStarted": "/OfferedLoad/Started",
    "offeredCompleted": "/OfferedLoad/Completed", "offeredSucceeded": "/OfferedLoad/Succeeded",
    "offeredFailed": "/OfferedLoad/Failed", "offeredRejected": "/OfferedLoad/Rejected",
    "offeredRetries": "/OfferedLoad/Retries", "offeredRows": "/OfferedLoad/Rows",
    "caseCounts": "/Cases", "idle": "/Idle",
}

COMMAND_FIELDS = {
    "argv": "/argv", "success": "/success", "exitCode": "/exitCode",
    "timedOut": "/timedOut", "observerErrors": "/observerErrors",
    "startedUtc": "/startedUtc", "finishedUtc": "/finishedUtc",
    "startedMonotonicNs": "/startedMonotonicNs", "finishedMonotonicNs": "/finishedMonotonicNs",
    "processLifetimeUserCpuSeconds": "/processLifetimeUserCpuSeconds",
    "processLifetimeSystemCpuSeconds": "/processLifetimeSystemCpuSeconds",
    "processLifetimeMaxRssBytes": "/processLifetimeMaxRssBytes",
    "measurementScope": "/measurementScope",
}


def extract(analysis_path: Path):
    analysis = read(analysis_path)
    result = {
        "schemaVersion": 1,
        "extractedUtc": datetime.now(timezone.utc).isoformat(),
        "scope": "Field extraction only. Existing analyzer statistics and decisions are copied unchanged; no workload, resource-log scan, hash verification, percentile calculation, ratio calculation or acceptance decision occurs.",
        "sourceIntegrityVerification": "Not rerun by this extractor; use the unchanged arithmetic and final identity audit.",
        "taskAcceptance": "Not decided by this extraction.",
        "analysis": fields(analysis, analysis_path, {
            "analyzerSha256": "/analyzerSha256", "helperRepositoryCommit": "/helperRepositoryCommit",
            "inputsChangedDuringAnalysis": "/inputsChangedDuringAnalysis",
            "finalFour": "/finalFour", "allocationAttribution": "/allocationAttribution",
            "loadComparisons": "/loadComparisons",
        }),
        "finalSegments": [], "otherLoadObservations": [],
        "gcScopes": {
            "steadyGc": "Raw Gen0/Gen1/Gen2 are process-wide collection-count deltas over the source-defined steady-through-drain measurement; they are not per-thread counts or absolute process-lifetime totals.",
            "offeredEndGc": "OfferedLoad GenNAtOfferedEnd values are cumulative process counters at actual producer offered-end. They are not steady deltas or guaranteed final process-exit totals. No missing endpoint is inferred or subtracted.",
        },
    }
    for index, observation in enumerate(analysis["observations"]):
        if observation.get("kind") != "load":
            continue
        base = f"/observations/{index}"
        row = {
            "id": observation["id"], "provider": observation["provider"],
            "cohort": observation["cohort"], "final": observation.get("final"),
            "analysis": fields(analysis, analysis_path, {k: base + v for k, v in ANALYSIS_FIELDS.items()}),
        }
        if observation.get("final") is True:
            raw_path = Path(observation["input"]["path"]).resolve(strict=True)
            command_path = Path(observation["invocation"]["input"]["path"]).resolve(strict=True)
            row["reportedRawIdentity"] = copy_field(analysis, analysis_path, base + "/input")
            row["reportedCommandIdentity"] = copy_field(analysis, analysis_path, base + "/invocation/input")
            row["raw"] = fields(read(raw_path), raw_path, RAW_FIELDS)
            row["command"] = fields(read(command_path), command_path, COMMAND_FIELDS)
            result["finalSegments"].append(row)
        else:
            result["otherLoadObservations"].append(row)
    return result


def value(row, section, key, pointer=""):
    item = row[section][key]
    if not item["present"]:
        return None
    answer = resolve(item["value"], pointer) if pointer else item["value"]
    return None if answer is MISSING else answer


def display(item):
    if item is None:
        return "unreported"
    if isinstance(item, float):
        return format(item, ".9g")
    if isinstance(item, (dict, list)):
        return json.dumps(item, ensure_ascii=False, separators=(",", ":"))
    return str(item).replace("|", "\\|").replace("\n", " ")


def markdown(report):
    lines = ["# Final measurement field extraction", "", report["scope"], "",
             "All values in this document are copied from the supplied analysis or original receipts. The JSON sibling preserves an exact source path and JSON pointer for every copied field. Numeric display is rounded for readability; JSON values retain their parsed precision.", "",
             "## Throughput and scheduled-arrival latency", "",
             "Latency values are histogram upper bounds in microseconds for successful completed operations. Rejected arrivals have no invented completion latency.", "",
             "| Provider / cohort | Success/s through drain | Offered p50 µs | Offered p95 µs | Offered p99 µs | Failed | Rejected |",
             "| --- | ---: | ---: | ---: | ---: | ---: | ---: |"]
    for row in report["finalSegments"]:
        cells = [f"{row['provider']} / {row['cohort']}", value(row, "analysis", "successfulThroughputThroughDrain")]
        cells += [value(row, "analysis", "offeredLatency", "/" + k) for k in ["p50_us_upper", "p95_us_upper", "p99_us_upper"]]
        cells += [value(row, "analysis", "normalizedMeasurement", "/counts/" + k) for k in ["failed", "rejected"]]
        lines.append("| " + " | ".join(display(x) for x in cells) + " |")
    lines += ["", "## Client CPU, RSS and managed allocation", "",
              "CPU endpoints bracket the measured steady operations through drain. Peak RSS is the process-lifetime high-water recorded after operations; idle RSS follows disposal without a forced GC. Managed B/success includes business DTO/string/JSON, harness, framework and driver costs; it is not framework-only allocation.", "",
              "| Provider / cohort | Client user CPU s | Client system CPU s | Process peak RSS B | Idle RSS B | Raw managed B/success |",
              "| --- | ---: | ---: | ---: | ---: | ---: |"]
    for row in report["finalSegments"]:
        cells = [f"{row['provider']} / {row['cohort']}"]
        cells += [value(row, "analysis", "clientCpu", "/" + k) for k in ["userCpuSeconds", "systemCpuSeconds"]]
        cells += [value(row, "analysis", "clientMemory", "/process_peak_rss_bytes"), value(row, "analysis", "idleRssBytes"), value(row, "raw", "bytesPerSuccessfulOperation")]
        lines.append("| " + " | ".join(display(x) for x in cells) + " |")
    lines += ["", "## Process-wide GC counters", "", report["gcScopes"]["steadyGc"], "", report["gcScopes"]["offeredEndGc"], "",
              "| Provider / cohort | Steady ΔG0 | Steady ΔG1 | Steady ΔG2 | Cumulative G0 at offered-end | Cumulative G1 at offered-end | Cumulative G2 at offered-end |",
              "| --- | ---: | ---: | ---: | ---: | ---: | ---: |"]
    for row in report["finalSegments"]:
        cells = [f"{row['provider']} / {row['cohort']}"]
        cells += [value(row, "raw", family + str(g)) for family in ["steadyGcGen", "offeredEndCumulativeGcGen"] for g in range(3)]
        lines.append("| " + " | ".join(display(x) for x in cells) + " |")
    lines += ["", "## Time and ownership", ""]
    for row in report["finalSegments"]:
        lines += [f"### {row['provider']} / {row['cohort']}", "",
                  f"Consumer: {display(value(row, 'raw', 'startedUtc'))} to {display(value(row, 'raw', 'finishedUtc'))}; reported effective seconds: {display(value(row, 'raw', 'effectiveSeconds'))}.", "",
                  f"Command: {display(value(row, 'command', 'startedUtc'))} to {display(value(row, 'command', 'finishedUtc'))}; idle ended: {display(value(row, 'raw', 'idle', '/FinishedUtc'))}.", "",
                  "Drained owner record: `" + display(value(row, "raw", "drainedOwners")) + "`.", ""]
    lines += ["## Existing acceptance records", "",
              "The analyzer's final-four record is reproduced below. This extractor does not run the identity auditor or decide product acceptance.", "",
              "```json", json.dumps(report["analysis"]["finalFour"]["value"], indent=2, ensure_ascii=False), "```", "",
              "The JSON also retains analyzer issues, raw errors, raw cumulative allocation endpoints, owner/activity records, source identities and the analyzer's existing comparison ratios without recomputing them.", ""]
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--analysis", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path, help="Fresh JSON path; writes a Markdown sibling")
    args = parser.parse_args()
    output = args.output.resolve()
    md_path = output.with_suffix(".md")
    if output == md_path or output.exists() or md_path.exists():
        parser.error("Use a fresh .json output and Markdown sibling; existing files are not overwritten")
    report = extract(args.analysis.resolve(strict=True))
    text = markdown(report)
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("x", encoding="utf-8") as stream:
        json.dump(report, stream, indent=2, ensure_ascii=False, allow_nan=False)
        stream.write("\n")
    with md_path.open("x", encoding="utf-8") as stream:
        stream.write(text)
    print(json.dumps({"json": str(output), "markdown": str(md_path), "extractedFinalSegments": len(report["finalSegments"]), "scope": "extraction only; no acceptance decision"}))


if __name__ == "__main__":
    main()
