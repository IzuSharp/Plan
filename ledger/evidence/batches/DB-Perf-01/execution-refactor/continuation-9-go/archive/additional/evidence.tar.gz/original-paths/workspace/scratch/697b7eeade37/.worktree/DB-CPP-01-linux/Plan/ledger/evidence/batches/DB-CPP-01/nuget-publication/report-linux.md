# DB-CPP-01 — public NuGet delivery follow-up, Linux x64

**Status: revised database-only publication preparation; public delivery pending.** The C++ database migration is already accepted. This separately authorized follow-up has not yet established a successful public package upload/readback or public four-cell consumer run. The successful earlier preparation checks below do not establish those pending outcomes or acceptance of the revised publication source.

The owner authorized delivery to the existing NuGet account `dekueon` through the existing GitHub trusted publisher: repository `IzuSharp/NativeWeave`, workflow `release.yml`, environment `nuget`. Their latest instruction limits publication to the database packages: existing HelloWorld versions remain as they are, and CI must not publish new HelloWorld versions. No browser sign-in, new account, new long-lived secret, or publisher-permission change belongs to this implementation. The [handoff](handoff-linux.md), [source binding](source-binding.json), [earlier independent technical review](reviews/publication-source-review.json), and [pre-publication registry observation](public-registry-before.json) preserve the preparation history.

## Product and package scope

NativeWeave is one database product with PostgreSQL and SQLite providers. The twelve package IDs below are its previously accepted transitive dependency closure. A normal application installs its selected provider facade; NuGet restores the required shared components and that provider's precompiled native leaf. An application using both databases references both facades. No package consolidation, new database provider, ORM feature, API redesign, or performance work is included.

The native implementation remains C++20, with libpq for PostgreSQL and SQLite for SQLite execution. Public C# APIs, the C ABI, source generators, ordinary entity/DTO builds, database formats and the native payloads remain those accepted in the [migration report](../migration-report-linux.md). Only Linux x64 is accepted here. Application HTTP/gRPC hosting remains the application's choice. The fixed twelve-package publication allowlist excludes `NativeWeave.HelloWorld`; its historical versions are preserved and no new HelloWorld package is produced or pushed.

| Package ID | Frozen version | Role | Verified public ZIP SHA-256 |
| --- | --- | --- | --- |
| NativeWeave.Core | `0.1.0-db-cpp.1.1` | Shared ownership and interop facade | Pending |
| NativeWeave.Interop.Abi | `0.1.0-db-cpp.1.1` | Shared ABI declarations | Pending |
| NativeWeave.Data | `0.1.0-db-cpp.1.1` | Shared database abstractions | Pending |
| NativeWeave.Data.Streaming | `0.1.0-db-cpp.1.1` | Shared streaming surface | Pending |
| NativeWeave.Database.Transactions | `0.1.0-db-cpp.1.1` | Shared transaction surface | Pending |
| NativeWeave.Query.Binding | `0.1.0-db-cpp.1.1` | Shared query binding | Pending |
| NativeWeave.Query.Generator | `0.1.0-db-cpp.1.1` | Shared compile-time convenience | Pending |
| NativeWeave.Database | `0.1.0-db-cpp.1.2` | Shared Database Host facade | Pending |
| NativeWeave.Database.Sqlite | `0.1.0-db-cpp.1.2` | SQLite application entry package | Pending |
| NativeWeave.Database.Sqlite.Native | `0.1.0-db-cpp.1.2` | SQLite precompiled native leaf | Pending |
| NativeWeave.Database.PostgreSql | `0.1.0-db-cpp.1.2` | PostgreSQL application entry package | Pending |
| NativeWeave.Database.PostgreSql.Native | `0.1.0-db-cpp.1.2` | PostgreSQL precompiled native leaf | Pending |

The original archive hashes and exact database dependency edges were fixed in the [initial publication manifest](https://github.com/IzuSharp/NativeWeave/blob/4349b4998bed0724d277bb14857c72756fe3a624/packaging/releases/DB-CPP-01-nuget.json). That preparation source is being superseded to remove the earlier HelloWorld withdrawal scope; its accepted database package identities remain unchanged. NuGet repository signing changes the enclosing ZIP; the public ZIP hash must be recorded separately. Every unsigned entry, package version, dependency edge, repository commit and native payload must still match the accepted original. An existing exact version with different payload bytes is a conflict, not a successful resume.

## Source and artifact identities

The delivered native/package source and the publication automation source have different identities. Promoting the original archives does not rebuild them from the later publication-code commit. The `4349b499…` preparation below is historical and is superseded by the owner's narrower instruction; the revised automation head, tree and checks are pending.

| Input | Exact identity |
| --- | --- |
| Accepted C++ product and package source | `3badc05be503991b5591732629dd7e5b0dbad111`, [product PR21](https://github.com/IzuSharp/NativeWeave/pull/21) |
| Accepted product tree | `3264de79b73c8a89f1cac1eff57d0c0ff2c841c2` |
| Original successful main build | [44977773509](https://github.com/IzuSharp/NativeWeave/actions/runs/44977773509), attempt 1 |
| Original candidate artifact | `14738115742`, `nativeweave-database-linux-44977773509-1` |
| Original artifact size / SHA-256 | 6,169,499 bytes / `bb63f9fe71ea4c2f68dd63b748af3820c8bc0174199ce6fa7e2a92197f31e8b9` |
| Promoted artifact directory | `db-scope/prepared/candidate`; the separate `.clean.*` test packages are excluded |
| SQLite native payload SHA-256 | `35b7a51e844e7cfe936d8fea22dd42fa26fba0eeb0412bc5ba98cb51b2547384` |
| PostgreSQL native payload SHA-256 | `27df06d78b3226d09ca412530abd1013e6a86c299e5d0db028c7ae9e3789fb72` |
| Initial preparation PR/head, superseded | [product PR23](https://github.com/IzuSharp/NativeWeave/pull/23), `4349b4998bed0724d277bb14857c72756fe3a624` |
| Initial reviewed preparation tree | `b43259a919e2e9de789dc851fb32502bc7271d71` |
| Initial local reviewed commit | `762fe8bf6915271244792e9bff69939767e00229`; identical tree, different commit metadata |
| Revised database-only automation identity | Pending new head/tree and their actual review/CI |
| Completed migration evidence | [Plan PR27](https://github.com/IzuSharp/Plan/pull/27), merge `5be447a868be78713ada52f46cee16409f0edc13` |
| Publication evidence PR | [Plan PR28](https://github.com/IzuSharp/Plan/pull/28), draft at this checkpoint |

Original `local_unsigned_only` receipts remain historical producer records. They are not rewritten to claim NuGet publication. Public registry, signature, listing and consumer receipts are separate evidence.

## Observed preparation and remaining execution

The initial independent source review covered all ten preparation changes and their fixed hashes. It independently reran 18 publisher and 9 consumer rejection controls, checked the original artifact and all twelve package digests, and confirmed that the existing migration verifiers, build workflow and business sample remained unchanged at that source. These are same-team non-author technical checks, not another GitHub account's approval, and the synthetic controls did not upload a package or execute a business application. The current database-only revision needs its own scoped review and checks; no earlier review or execution is silently transferred to changed source.

The actual [initial PR publication preflight 44994423577](https://github.com/IzuSharp/NativeWeave/actions/runs/44994423577), job `137122267455`, passed. Its log observed `Existing NuGet publication switch: true`, successful rejection controls, and successful live source/artifact/package checks. The credential-bearing publisher was correctly skipped because this was a pull request. This remains a preparation result for `4349b499…`, not proof of the revised source or public delivery.

| Delivery gate | Observation at this preparation checkpoint | Final receipt / identity to record |
| --- | --- | --- |
| Initial product PR23 source review | Passed for the superseded head `4349b499…`, tree `b43259a9…` | [Historical review and source binding](source-binding.json) |
| Initial PR publication preflight | Passed at that source; existing enable switch observed `true` | [44994423577](https://github.com/IzuSharp/NativeWeave/actions/runs/44994423577) |
| Revised database-only PR review/preflight | Pending | New exact head/tree, review and run: pending |
| Required product PR CI | Current revision pending; initial [44994423565](https://github.com/IzuSharp/NativeWeave/actions/runs/44994423565) was in progress at the earlier checkpoint | Current-source final jobs/steps and tested head: pending |
| Normal product merge | Pending | Actual merge commit/tree: pending |
| Product merged-main CI | Pending | Actual push/main run, attempt, jobs/steps: pending |
| Existing trusted-publisher exchange | Pending | Actual release run and exchange result: pending |
| Twelve package uploads or exact existing-version readbacks | Pending | `publication.json`, registry hashes, signatures, owner/listing results: pending |
| Four public PackageReference consumer cells | Pending | `consumer/receipt.json`, actual runtime and native-load results: pending |
| Publication evidence PR28 | Draft; completion not claimed | Exact PR checks, normal merge and own main CI: pending |

The final successful migration CI does not establish these new public-delivery gates. Completion requires authenticated database publication and actual public consumption; a successful upload alone is insufficient. HelloWorld withdrawal is outside the revised scope and is not a pending gate or blocker.

## Public consumer matrix

The new `eng/verify_nuget_public.py` uses the unchanged accepted `samples/api/packaging-domain/Program.cs`. Each cell creates a fresh project and empty package/HTTP caches outside the checkout. NuGet.org is the only source, fallback folders are disabled, and the selected provider uses an exact PackageReference. Each provider resolves ten accepted NativeWeave packages; their union is the twelve-package closure.

The controller checks actual restore metadata and dependency closure, every restored NativeWeave package's unsigned payload and real repository signature, and the exact signed `dekueon` owner and official certificate. It then performs normal managed build or Native AOT publish and executes typed entity, Fluent DTO and resource-retirement operations. Runtime receipts report the actually mapped native library and its hash. Native AOT additionally requires the real Linux x64 ELF, `dynamicCodeSupported=false` and the execution witness. No product-native compilation is performed.

| Database | Execution | Public restore / signed payload | Business operations / release | Actual mapped native hash | Result |
| --- | --- | --- | --- | --- | --- |
| SQLite | JIT | Pending | Pending | Pending | Pending |
| SQLite | Linux Native AOT | Pending | Pending | Pending | Pending |
| PostgreSQL 18 | JIT | Pending | Pending | Pending | Pending |
| PostgreSQL 18 | Linux Native AOT | Pending | Pending | Pending | Pending |

The accepted local-feed executions remain in the migration history. They are not substituted for this table. This preparation session had no local .NET/Clang execution; public runtime results must come from the actual release run. Public consumer subprocesses do not inherit NuGet/GitHub credentials or the runner's OIDC/runtime token channel.

## Historical HelloWorld versions

The retained [registry observation](public-registry-before.json) records ten existing `NativeWeave.HelloWorld` versions, all listed at that observation. The owner now requires those versions to remain as they are. No delete, unlist, relist or replacement operation is part of this follow-up. The database CI publication path is restricted to the twelve exact database IDs above and excludes HelloWorld, so it adds no HelloWorld version. Historical preparation evidence remains available without turning its old withdrawal target into a current acceptance requirement.

## Application installation after confirmed public delivery

The following commands are intended for the exact published versions once the public gates above pass. They are not evidence that the versions are available at this checkpoint. Choose the provider used by the application:

```sh
dotnet add package NativeWeave.Database.Sqlite --version "[0.1.0-db-cpp.1.2]" --source https://api.nuget.org/v3/index.json
```

For PostgreSQL, select its facade instead:

```sh
dotnet add package NativeWeave.Database.PostgreSql --version "[0.1.0-db-cpp.1.2]" --source https://api.nuget.org/v3/index.json
```

The corresponding exact project reference is one of:

```xml
<PackageReference Include="NativeWeave.Database.Sqlite" Version="[0.1.0-db-cpp.1.2]" />
<PackageReference Include="NativeWeave.Database.PostgreSql" Version="[0.1.0-db-cpp.1.2]" />
```

Use both only when the application needs both providers. Ordinary entity, DTO or query changes rebuild C# and reuse the precompiled native package; consumers do not need a Rust or product C++ build. Native AOT retains its normal platform compiler/linker prerequisites.

## Maintainer reproduction and final receipt collection

Use the revised database-only publication checkout after its own review and checks, with the accepted `3badc05…` object available in Git history. [Product PR23](https://github.com/IzuSharp/NativeWeave/pull/23) carries the revision of `release.yml` using the existing `nuget` environment and `NuGet/login` exchange, not a browser session. Record the final source-bound workflow link when the revision is frozen. Required PR checks must pass before normal merge. An explicit dispatch of the same workflow on main can resume the immutable database release; previously existing versions still require exact verified readback.

Read-only original-source preparation requires GitHub access to the fixed Actions artifact:

```sh
python3 eng/publish_nuget.py preflight \
  --manifest packaging/releases/DB-CPP-01-nuget.json \
  --work-dir artifacts/nuget-publication
```

The database publication runs inside the authorized existing trusted-publisher job. Its temporary credential is supplied through `NUGET_API_KEY`, never as a command argument or recorded receipt field:

```sh
python3 eng/publish_nuget.py publish \
  --manifest packaging/releases/DB-CPP-01-nuget.json \
  --work-dir artifacts/nuget-publication
```

After all twelve versions have authenticated public readbacks, run the actual public consumers with SDK `11.0.100`, ordinary Linux Native AOT prerequisites and a disposable PostgreSQL 18 service selected by `NW_TEST_POSTGRES`. The output directory must be new:

```sh
python3 eng/verify_nuget_public.py \
  --release-record artifacts/nuget-publication/source/db-scope/prepared/candidate/release.json \
  --signature-policy artifacts/nuget-publication/signature-policy.json \
  --expected-source 3badc05be503991b5591732629dd7e5b0dbad111 \
  --owner dekueon \
  --output artifacts/nuget-publication/consumer
```

These commands document the database delivery entry points; this report draft did not execute them. The final evidence update must bind the revised automation's review and exact CI, actual release run/attempt and source, original and public archive identities, signed owner/certificate verification and four completed consumer cells. Record failed or partially completed database operations separately, then complete Plan PR28's own review, CI, normal merge and merged-main CI. Public delivery remains **pending** until those observations are available; the accepted migration remains unchanged, and historical HelloWorld listings are outside the mutation scope.
