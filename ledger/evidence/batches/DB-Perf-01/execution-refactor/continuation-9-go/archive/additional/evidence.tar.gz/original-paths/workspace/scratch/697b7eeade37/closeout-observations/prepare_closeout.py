from pathlib import Path
import hashlib
import json

ROOT = Path('/workspace/scratch/697b7eeade37')
PLAN = ROOT / '.worktree/DB-CPP-01-linux/Plan'
PREFIX = 'ledger/evidence/batches/DB-CPP-01/'
BATCH = PLAN / PREFIX

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def dump(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')

def ref(path):
    return {'path': str(path.relative_to(PLAN)), 'sha256': sha(path.read_bytes())}

def pick(value, keys):
    return {key: value[key] for key in keys if key in value}

acceptance = json.loads((BATCH / 'acceptance.json').read_text())
for prefix, repo, run_id in [('product', 'NativeWeave', 44977773509), ('plan', 'Plan', 44980202529)]:
    raw_run = (ROOT / 'closeout-observations' / (prefix + '-main-run.json')).read_bytes()
    raw_jobs = (ROOT / 'closeout-observations' / (prefix + '-main-jobs.json')).read_bytes()
    run = json.loads(raw_run)
    jobs = json.loads(raw_jobs)
    source = {k: acceptance['prs'][repo]['merged_' + k] for k in ('commit', 'tree')}
    assert run['id'] == run_id and run['head_sha'] == source['commit']
    assert run['head_commit']['tree_id'] == source['tree']
    assert run['event'] == 'push' and run['head_branch'] == 'main'
    assert run['status'] == 'completed' and run['conclusion'] == 'success'
    assert jobs['total_count'] == len(jobs['jobs'])
    run_projection = pick(run, ['id', 'name', 'url', 'html_url', 'path', 'head_branch', 'head_sha', 'event', 'status', 'conclusion', 'run_attempt', 'run_number', 'workflow_id', 'workflow_url', 'jobs_url', 'artifacts_url', 'created_at', 'updated_at', 'run_started_at', 'referenced_workflows'])
    run_projection['head_commit'] = pick(run['head_commit'], ['id', 'tree_id'])
    run_projection['repository'] = pick(run['repository'], ['id', 'full_name', 'html_url'])
    run_projection['pull_requests'] = [dict(pick(p, ['number', 'url']), head=pick(p['head'], ['sha', 'ref']), base=pick(p['base'], ['sha', 'ref'])) for p in run.get('pull_requests', [])]
    job_projection = []
    skipped = ['security / Dependency review'] if repo == 'NativeWeave' else []
    for job in jobs['jobs']:
        assert job['run_id'] == run_id and job['head_sha'] == source['commit'] and job['run_attempt'] == run['run_attempt']
        assert job['status'] == 'completed'
        assert job['conclusion'] == ('skipped' if job['name'] in skipped else 'success')
        assert all(step['status'] == 'completed' and step['conclusion'] == 'success' for step in job.get('steps', []))
        projected = pick(job, ['id', 'run_id', 'run_url', 'run_attempt', 'url', 'html_url', 'head_branch', 'head_sha', 'name', 'status', 'conclusion', 'created_at', 'started_at', 'completed_at'])
        projected['steps'] = [pick(step, ['number', 'name', 'status', 'conclusion', 'started_at', 'completed_at']) for step in job.get('steps', [])]
        job_projection.append(projected)
    target = BATCH / 'ci' / f'{prefix}-merged-main-{run_id}'
    dump(target / 'run.json', {'data': run_projection, 'sanitized': True, 'source_artifact_sha256': sha(raw_run)})
    dump(target / 'jobs.json', {'data': {'jobs': job_projection, 'total_count': jobs['total_count']}, 'sanitized': True, 'source_artifact_sha256': sha(raw_jobs)})
    run_ref, jobs_ref = ref(target / 'run.json'), ref(target / 'jobs.json')
    receipt = {
        'schema_version': 2, 'task': 'DB-CPP-01', 'platform': 'linux-x64',
        'claims': ['merged_main_ci'], 'outcome': 'passed', 'sources': {repo: source},
        'artifacts': [dict(run_ref, kind='github-run'), dict(jobs_ref, kind='github-jobs')],
        'required_checks_complete': True,
        'ci': [{'repository': repo, 'scope': 'merged_main', 'url': run['html_url'], 'workflow_path': run['path'],
                'required_jobs': sorted(j['name'] for j in jobs['jobs'] if j['name'] not in skipped),
                'normally_skipped_jobs': skipped, 'run': run_ref, 'jobs': jobs_ref}],
    }
    receipt_path = BATCH / 'receipts' / f'{prefix}-merged-main-{run_id}.json'
    dump(receipt_path, receipt)
    acceptance['prs'][repo].update({'merged_main_checks': [ref(receipt_path)], 'main_ci_head': source['commit'], 'main_ci_conclusion': 'success', 'main_ci': [run['html_url']]})

acceptance['checks']['merged_main_ci'] = {'status': 'passed', 'evidence': [item for repo in ('NativeWeave', 'NativeWeave-Design', 'Plan') for item in acceptance['prs'][repo]['merged_main_checks']]}
acceptance['state'] = 'accepted'
plan_pr = acceptance['prs']['Plan']
acceptance['delivery_snapshot'] = {
    'plan_pr': plan_pr['url'],
    'plan_tested': {k: plan_pr['tested_' + k] for k in ('commit', 'tree')},
    'plan_merged': {k: plan_pr['merged_' + k] for k in ('commit', 'tree')},
    'record_policy': 'evidence-only-followup', 'self_ci': 'checked-separately',
}
dump(BATCH / 'acceptance.json', acceptance)

graph_path = PLAN / 'delivery-graph.json'
graph = graph_path.read_text()
old = '"id": "review-and-merge",\n        "state": "in_progress"'
assert graph.count(old) == 1
graph_path.write_text(graph.replace(old, '"id": "review-and-merge",\n        "state": "complete"'))

dump(BATCH / 'cleanup-resume-linux.json', {
    'task': 'DB-CPP-01', 'phase': 'final-evidence-resume', 'outcome': 'completed',
    'authorization': 'The owner explicitly requested removal of previous local worktrees and build/tool copies before resuming.',
    'observed_remote_checkpoint': '8c42522513b194007231f09aa6a019ac21f72a43',
    'removed': [
        {'kind': 'old orphan NativeWeave-Design worktree', 'file_bytes': 59087555, 'git_metadata': 'gitfile referred to a missing Git directory'},
        {'kind': 'old dotnet-sdk tool copy', 'file_bytes': 550386921},
    ],
    'db_cpp_handoff_or_report_found_in_removed_tree': False,
    'new_worktrees': 'ROOT/.worktree/DB-CPP-01-linux/{NativeWeave,NativeWeave-Design,Plan}',
    'prior_final_local_commit_recovered': False,
    'continuation': 'Reconstruct the final evidence-only followup from the remote checkpoint and fresh official GitHub observations. No product execution is claimed in this resumed closeout.',
})
print('Prepared two exact merged-main receipts, 21 accepted checks, seven complete phases and the resumed cleanup record.')
