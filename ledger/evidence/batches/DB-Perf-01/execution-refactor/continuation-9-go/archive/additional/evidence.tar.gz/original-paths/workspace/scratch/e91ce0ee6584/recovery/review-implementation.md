# DB execution continuation: independent implementation recheck

Date: 2026-11-26. Reviewer: `/root/implementation_review`.

## Disposition

No new concrete product-correctness defect was found in the targeted source recheck that requires changing or interrupting the frozen candidate before completing its long measurements. This is a read-only review, not a new correctness test run, performance acceptance, or merge approval.

The prior detailed review at `/workspace/scratch/166b48a091b9/recovery/review-implementation-01.md` remains applicable. Its unresolved performance/reporting boundaries must remain visible; this recheck does not replace them with stronger claims.

## Exact code identity

The inspected worktree is `/workspace/scratch/fd78534029f7/worktrees/DB-Exec-10-korda`.

- Local HEAD: `040911c5abdee740c0cd9fbf8295bf511c9cc69d`.
- Local tree: `bc9087d843d8d741d83d44f53d0b2c5af26dcffc`.
- Published candidate present in the local bare repository: [17da07e391ba867bbf195baa2e9fdc0bdc0cc0aa](https://github.com/IzuSharp/Korda/commit/17da07e391ba867bbf195baa2e9fdc0bdc0cc0aa).
- That published commit's actual Git tree: `bc9087d843d8d741d83d44f53d0b2c5af26dcffc`.
- `git status --short` was empty at inspection.

The tree equivalence was checked from Git objects, not inferred solely from an earlier written receipt. No branch, tracked file, test, frozen binary, or benchmark input was modified. No build, test, profiling, or load process was started by this reviewer.

## Targeted confirmations

| Risk | Actual source checked at the frozen tree | Result |
| --- | --- | --- |
| Public Fluent silently retaining the replaced per-node submission path | `src/Query.Fluent/SessionQueries.cs:18–23` | `From` requires `db.query.command.v1` and selects `QueryBinding.CreateBuffered`. |
| Find cache substituting another mapper or retaining a Session/key | `src/Orm.Relations/Crud.cs:18–27`; `src/Orm.Relations/FindPlan.cs:10–56,160–175` | Exact Table reference keys the cache. Each invocation gets independent parameter-frame values and a caller lease. The immutable cached plan does not retain a Session or previous execution values. |
| Eviction/Source shutdown freeing an active Find lease | `FindPlan.cs:25–65,111–116`; `src/Data.NativeHost/DataSource.cs:184` | Cache acquisition, release and eviction share `_registrations`; an active caller retains its own reference until terminal completion. |
| A zero cache-entry limit breaking eviction | `src/Data.NativeHost/DatabaseOptions.cs:53–64` | Prepared-plan count and byte limits must be positive. Oversized individual shapes execute without entering the retained cache. |
| First execution mutating a cached Find timeout for subsequent invocations | `native/cpp/src/query.cpp:3084–3125`; `native/cpp/src/host_abi.cpp:293`; `native/cpp/src/host.cpp:1545–1569,2890–2895` | The immutable NativePlan renders an execution-specific SqlPlan; elapsed admission time is applied to that per-execution instance. |
| Cancellation/close arriving between description and first side effect | `native/cpp/src/host.cpp:2864–2920` | Cursor pull rechecks source/session admission, cancellation and close after opening/description and before provider fetch. |
| Early stop or mapping failure bypassing release | `src/Data.NativeHost/DataSession.cs:92–110`; `HostStreamTransport.cs:31–51`; `src/Data.Streaming/TypedStream.cs:183–300` | Streams converge on typed pull. Cleanup disposes the batch, drains registration and requires actual retirement. Original mapping failure is preserved; cleanup failure is attached. Concurrent Dispose waits for active mapping. |
| Command readiness incorrectly proving callback-tail retirement | `native/cpp/src/host.cpp:1154–1196`; `src/Data.NativeHost/HostCommandController.cs:271–325,430–499` | Execution accessors are released before notification; independent native fences retain the tail. Indeterminate acceptance/take uses a real close proof. A transferred child that fails managed adoption is retained and retired before failure publication. |
| PostgreSQL commit optimization accepting INERROR/live reader/savepoint | `native/cpp/src/provider.cpp:160–166,1419–1431`; `native/cpp/src/host.cpp:3537–3569` | Skip is restricted to a healthy nonblocking nonpipeline physical connection, no live statement, exact INTRANS, and no savepoint. Other states retain the probe/fallback; post-COMMIT confirmation remains. |
| Generated materialization falling back to reflection | `src/Query.Generator/ModelGenerator.cs:192–200` | The generator emits fixed ordinal codec reads directly into constructor/property assignments. |

## Test-source cross-checks, not executions

`tests/Orm.Relations/Program.cs:61` actually invokes `FindShapes`; `FindShapes.cs:96–98` invokes the byte-bound, lifecycle, and DDL subfamilies. The inspected assertions cover equal-metadata/distinct-mapper identity, two Sessions, retained leases across eviction, binary-key snapshots, pre-cancellation, source closure during mapping, mapping exceptions, and schema changes. Thus the retained Find test source is an invoked contract suite, not an uncalled helper.

`native/cpp/tests/command_completion_tests.cpp:240–278` holds the callback tail and distinguishes ready result transfer from actual join. Related tests beginning at 281 and 334 verify accepted queued cancellation precedes side effects; the test beginning at 370 keeps the descendant tail visible after public owner release.

`native/cpp/tests/postgres_sync_tests.cpp:606–635` checks actual PostgreSQL IDLE, INTRANS, live description, active reader, live EOF, reader closure, INERROR, synchronized INERROR, rollback, and physical closure. The following fallback suite checks SELECT 1/ROLLBACK protocol sequence, preserved 25P02 precedence and same-backend safe reuse. Those source assertions agree with the documented narrow optimization. Their previously executed receipts remain attributed to the earlier run.

## Remaining acceptance boundaries

The present review adds no evidence for framework-only 0 B allocation, removal of all dynamic NWQC traversal, or exhaustion of all future optimizations. It adds no final 1,800-second cell and does not make any failed/interrupted cell successful. Use the actual four serial long-run results and retained baseline conditions for performance claims.

The frozen consumers' process cumulative GC at offered-end and steady workload GC deltas have different boundaries. Preserve the prior review's explicit limitation: shutdown/idle-end cumulative GC is not serialized and cannot be inferred from `/proc` data.

No code mutation is recommended solely to replace the frozen candidate before the remaining measurement acceptance. Final evidence validation, normal merges, existing CI and rule-selected publication/readback remain root-owned delivery gates.
