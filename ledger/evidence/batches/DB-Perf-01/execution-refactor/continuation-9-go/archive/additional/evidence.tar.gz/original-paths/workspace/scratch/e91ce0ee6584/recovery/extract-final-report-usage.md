# Final report field extractor

`extract_final_report.py` is an informational presentation helper. It reads the
unchanged `final-analysis` report and, for its final observations, the original
consumer and command receipts named by that report. It does not read resource
JSONL, run an analyzer, calculate percentiles or ratios, scan/hash binaries,
start a workload, or decide acceptance. Other load observations and existing
comparison ratios are copied from the supplied analysis for baseline context.

Run only after all four original measurement segments and their drain/idle have
ended and the existing arithmetic report has been produced. Use the actual
analysis path and a fresh output name:

```bash
taskset -c 8 python3 /workspace/scratch/e91ce0ee6584/recovery/extract_final_report.py \
  --analysis /workspace/scratch/fd78534029f7/measurements/final-analysis-01.json \
  --output /workspace/scratch/e91ce0ee6584/recovery/final-report-extract-01.json
```

The helper writes a JSON report and a Markdown sibling. Every copied JSON field
retains its source path and JSON pointer, together with a `present` flag. A
missing field is not changed to zero. Existing output files are not overwritten.
The generated Markdown formats the supplied numbers for readability; the JSON
retains their parsed precision. Source hashes already in the analysis are
reported as supplied, without claiming they were reverified by this helper.

## Metric scopes

- Throughput and offered p50/p95/p99 come directly from existing analyzer
  metrics. Offered latency is scheduled-arrival-to-completion for successful
  completed requests, in histogram upper-bound microseconds. Refusals remain
  explicit counts without invented completion latency.
- Client CPU and RSS scopes are copied from the analyzer. Process peak RSS is
  the after-operations process-lifetime high-water; the JSON separately retains
  observer samples and wait4 process-lifetime values. Idle RSS comes from the
  existing post-disposal idle observation.
- Managed B/success is copied from the raw `BytesPerSuccessfulOperation`; the
  analyzer's independent value and original allocation endpoints are retained.
  Business, framework, harness and driver costs are not separated by this tool.
- Raw `Gen0`/`Gen1`/`Gen2` are process-wide steady-through-drain collection-count
  deltas. `OfferedLoad/GenNAtOfferedEnd` are cumulative counters at the actual
  offered-end observation. Neither is relabeled as an exact final process-exit
  total. No unavailable GC baseline or phase delta is inferred.
- Korda's complete `Before`/`After`/`Drained` objects are copied, including all
  eight owner fields and SQL/protocol activity counters. Dapper's application
  connection record retains its narrower provider-internal visibility scope.
- The original `finalFour` decision is copied verbatim. A helper exit code 0
  means the fields were extracted, not that arithmetic, identity, business,
  package, performance or delivery acceptance passed.

Preparation used lightweight schema inspection of the existing baseline report,
one completed final Korda receipt and one earlier Dapper offered receipt. The
Python source passed `ast.parse`; extraction has deliberately not been executed
while the original four-segment campaign is still running. An initial schema
inspection attempted the Korda-only owner boolean in a Dapper receipt and raised
`KeyError`; the corrected inspection and helper preserve the distinct provider
fields rather than inventing a shared counter.
