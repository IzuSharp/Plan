# Independent live freeze recovery review

Reviewer: `/root/freeze_audit`; observed 2026-11-26 08:49–08:53 UTC (16:49–16:53 Asia/Shanghai).

## Decision

**The first final measurement is already running. Continue observing the existing campaign; do not start a duplicate, overwrite its output, rebuild, or run a bulk input hash/archive operation during measurement.** No final segment is credited yet.

The active directory is `/workspace/scratch/fd78534029f7/measurements/sqlite-final-01`. Its fixture completed successfully at 08:38:20 UTC. The candidate resource stream begins at 08:38:20.268573 UTC. At 08:50:28 it held 2,880 samples; at 08:51:02.355462 the file had grown to 3,645,862 bytes and its latest sample was 08:51:02.344191. The same client identity (PID 26, start ticks 3008243) retained increasing CPU ticks. This is direct evidence of a live observer and workload in a different tool PID namespace, despite an empty process listing in the current namespace. A missing final consumer JSON while the workload runs is not a failed run.

The supervisor record `/workspace/scratch/166b48a091b9/recovery/campaign-supervisor-01.json` records the existing campaign start at 08:38:19.924162 UTC and the original frozen SQLite invocation. Current hostname `89394ab90f06`, boot ID `3c3f3b1f-818d-4772-85df-bafb4e207403`, kernel 6.18.57 and available CPUs 0–8 match the recorded host. These identities do not prove physical exclusivity or an unseen cgroup quota.

## Frozen inputs and existing preflight

The original freeze is `/workspace/scratch/fd78534029f7/measurements/final-freeze-01.json`, with recorded SHA-256 `fc1dae9be0a76b0de38c4f94c3836e47b398e10b5ff23f3c8f82313a3cb4bc1a`. Product, candidate harness and runner are `17da07e391ba867bbf195baa2e9fdc0bdc0cc0aa`, tree `bc9087d843d8d741d83d44f53d0b2c5af26dcffc`. Reused Dapper harness is `05fdd6b507bbfa9e971caa739784cf42dfb7199c`.

The existing recovery receipt `/workspace/scratch/166b48a091b9/recovery/frozen-input-rehash-before-01.json` records all 373 inputs rehashed without failures at 08:37:37.832926 UTC, before the running campaign. Both standalone candidate source worktrees were clean and on the frozen commit/tree. This review read that receipt; it did not repeat the full hash sweep during the active interval.

Both plans retain their original fixture and exactly two measured consumers. Order is SQLite candidate, SQLite Dapper, PostgreSQL candidate, PostgreSQL Dapper. SQLite is C4/R3000; PostgreSQL is C8/R3600. All use queue 64, 35 cases, requested/batch rows 32, 8 tenants with 1024 orders, persistent sessions, 64 warmup operations per worker, 1800 seconds and 15 seconds post-disposal idle. The final source plans with three cohorts must not execute.

## Completed evidence retained

The four 120-second before/current observations and their original command receipts exist. The existing baseline analyzer retains zero business failures and explicit rejections. Short successful throughput is SQLite 542.872 to 2668.577 op/s and PostgreSQL 1241.453 to 3458.224 op/s. These observations do not include post-drain idle RSS and grant no 1800-second credit.

Pre-final archive receipt at `worktrees/DB-Exec-10-plan/ledger/evidence/batches/DB-Perf-01/execution-refactor/continuation-7/current-measurements/pre-final-evidence-01/receipt.json` records 1391 included original files, 49,734,968 original bytes, full member readback and original rehash, and 66 explicit exclusions. Archive SHA-256 is `544bcb1e77fd48fd04c74f1f6edf800431ca4ffac55c59b78d4b491ecc2eea5d`. This is a pre-final evidence archive, not a complete binary/database bundle or final-result archive. This review did not rerun archive verification during the active interval.

## Remaining acceptance and recovery rules

After all four measured consumers and their drain/idle complete, use the unchanged `continuation-5/prepare_load_index.py` and `continuation-3/analysis/analyze_execution.py`, then `continuation-7/local-load-tools/audit_final_identity.py audit` against the original freeze and exact frozen hash. The supplied index must include both baseline directories and both final directories: eight measured observations, of which exactly four are final.

Require every steady interval to reach 1800 seconds with per-second business progress, all 35 cases, count conservation and successful invocation/observer receipts. Require no overlap through drain and idle, unchanged full source/package/ELF/generated-code/native/plan/argv identities, all eight candidate owner counters integer zero, and Dapper application connection owner integer zero. Require audit `status=passed`, four segments and `inputsUnchanged=true`; the arithmetic tool alone does not decide task acceptance.

Then produce a separate final archive including actual outputs, audits, host/supervisor/recovery observations and the source union. Preserve pre-final evidence and all failures. Update stale current-checkpoint/README/PR text without deleting earlier history. Existing CI and history gates retain their original scope and immutable snapshots.

If logs cease growing and no completed receipt appears, first establish that the old campaign actually stopped; a current-namespace `ps` listing alone is insufficient. Preserve any genuinely interrupted directory. A retry then needs a fresh output destination and an explicitly new derived plan/freeze. This retry rule does not apply to the presently confirmed live first interval.

Keep limitations visible: no independent hardware exclusivity/cgroup admission; `FrameworkOnlyBytes=null`; whole-framework additional managed 0 B is unproven; source/generated SQL equivalence is not a runtime wire trace; rejected 92b9230 stays rejected. No new implementation change or test was performed by this review.

## Runner continuation and exact closeout procedure

The existing product `benchmarks/db-perf/run.py` main function performs a synchronous `for item in plan["commands"]` loop within one database owner, and `execute` raises after retaining any failed receipt. Therefore SQLite candidate and Dapper are automatically serial within the already running SQLite runner. The outer supervisor JSON declares serial execution, but no persisted outer supervisor script was recovered. Its current one-element `runs` list proves only SQLite has started; the coordinator must observe a PostgreSQL entry and live output after SQLite retires before concluding the outer process actually proceeded. Do not launch a competing PostgreSQL process on a promise inferred from JSON alone.

The following commands are prepared for **after both provider runners have ended**, not for the active measurement window. Fresh names below are proposed; preserve any existing output and choose another numbered name if needed.

```bash
DB_EVIDENCE_ROOT=/workspace/scratch/fd78534029f7/measurements
DB_EXEC_PLAN=/workspace/scratch/fd78534029f7/worktrees/DB-Exec-10-plan/ledger/evidence/batches/DB-Perf-01/execution-refactor
DB_FINAL_SOURCE=/tmp/DB-Exec-10-pack-sqlite-02
DB_RECOVERY_HOST=/workspace/scratch/166b48a091b9/recovery/host-before-final-recovery-01.json

taskset -c 8 python3 "$DB_EXEC_PLAN/continuation-5/prepare_load_index.py"   --directory "$DB_EVIDENCE_ROOT/sqlite-baseline-01"   --directory "$DB_EVIDENCE_ROOT/postgresql-baseline-01"   --directory "$DB_EVIDENCE_ROOT/sqlite-final-01"   --directory "$DB_EVIDENCE_ROOT/postgresql-final-01"   --host-record "$DB_RECOVERY_HOST" --group-prefix current-17da   --output "$DB_EVIDENCE_ROOT/final-index-01.json"

taskset -c 8 python3 "$DB_EXEC_PLAN/continuation-3/analysis/analyze_execution.py"   --index "$DB_EVIDENCE_ROOT/final-index-01.json"   --korda-root "$DB_FINAL_SOURCE"   --output "$DB_EVIDENCE_ROOT/final-analysis-01.json"

taskset -c 8 python3 "$DB_EXEC_PLAN/continuation-7/local-load-tools/audit_final_identity.py" audit   --freeze "$DB_EVIDENCE_ROOT/final-freeze-01.json"   --freeze-sha256 fc1dae9be0a76b0de38c4f94c3836e47b398e10b5ff23f3c8f82313a3cb4bc1a   --analysis "$DB_EVIDENCE_ROOT/final-analysis-01.json"   --output "$DB_EVIDENCE_ROOT/final-identity-audit-01.json"
```

The baseline receipts retain their own earlier host observation; using the new common index must not conceal the original host file. The old and recovery observations have matching node/machine/kernel, but final reporting must retain their different observation times and visibility scope.

For final archiving, the existing `archive_measurement_evidence.py` accepts repeated `--inventory JSON POINTER EXPECTED_SHA256`. Reuse the unchanged pre-final input map at `/workspace/scratch/fd78534029f7/measurements/pre-final-evidence-inputs-01.json`, `/inputFiles`, SHA-256 `6d76ab9cd3dc4f0816af6b41259b9aced8166a224b7faa7adf5cf02c327c7284`, plus the successful final identity audit's `/inputFiles` map with its actually observed hash. The audit map includes frozen producer inputs and all arithmetic report input files; do not invent its future hash. The archive tool includes each inventory document itself.

Set `--measurements` to the existing measurement root; retain both `/workspace/scratch/166b48a091b9/recovery` and `/workspace/scratch/e91ce0ee6584/recovery` explicitly, plus any new final review files outside those roots. Select a fresh output beneath the Plan evidence tree, outside every retained root. Add `--exclude-root database` for the stopped `postgresql-final-01/pgdata`, and `--exclude-file database` for each exact actual stopped-database archive under `retained-databases`. The existing nine archive paths are listed in pre-final `command.json`; enumerate the actual final set rather than asserting the old count. SQLite database/sidecars, packages and compiled images have built-in explicit hash/exclusion handling. Every explicit exclusion is hashed, not silently dropped.

Archive only after the PostgreSQL owner receipt proves successful shutdown and all final consumers/observers have ended. Inspect `receipt.json` for complete archive readback and unchanged original identities. The archive's own `finalAcceptanceCredit=false` is intentional: it retains evidence and does not replace arithmetic/identity/product acceptance.
