# DB-Exec-02 recovery review: Design, CI and delivery navigation

Reviewed on 2026-11-26, with remote observations completed at 08:51:53 UTC
(16:51:53 Asia/Shanghai). This is a read-only subordinate technical review.
No build, correctness test, benchmark, profiler, history gate, remote mutation
or shared-branch edit was performed. The only written file is this review.

## Conclusion

No new Design or CI defect was found that prevents observing the already
frozen campaign. Existing exact-head CI succeeds. Current Design distinguishes
implemented paths, rejected experiments, retained contracts and unproven costs.
The remaining delivery work includes the actual four-cell campaign verdict,
current navigation updates, ordinary review/merge and actual main/publication
observations. Passing PR CI is neither final performance acceptance nor release
evidence.

This review inherits the comprehensive prior source correspondence in
`/workspace/scratch/166b48a091b9/recovery/review-design-ci-01.md`, then independently
checks current identities, current CI, relevant workflow diffs, source pins,
the historical-gate invocation and stale navigation. It does not manufacture
another execution count from those source/test correspondences.

## Exact current identities

All three PRs remain open drafts and return `mergeable=true`,
`mergeable_state=clean`. All inspected local worktrees are clean.
The current public Git commit objects were fetched through the GitHub API;
their returned trees exactly match the inspected local HEAD trees.

| Repository | Public HEAD | Local reviewed HEAD | Verified tree |
| --- | --- | --- | --- |
| Korda | `17da07e391ba867bbf195baa2e9fdc0bdc0cc0aa` | `040911c5abdee740c0cd9fbf8295bf511c9cc69d` | `bc9087d843d8d741d83d44f53d0b2c5af26dcffc` |
| Korda-Design | `ca1933e93678039b492f10a8b47045b11827f1a4` | `734e5103c2acd7315532f19a10001f57ddd58bdf` | `4c29c7b0af358dafe7343ffe10c52b445d8c4b93` |
| Plan | `9e4aad4c04c68dd30ab3bcad68a977000b4717e2` | `e66ae1025e098fe487d86b1590cda11d7a166413` | `ea0fa9e359a44d9aefd163d2db976c2784b5ef9f` |

Worktrees are `/workspace/scratch/fd78534029f7/worktrees/DB-Exec-10-korda`,
`DB-Exec-10-design` and `DB-Exec-10-plan`. All three root AGENTS files were read.
The current user authority and current continuation supersede historical stop
sections. No prior stopped task is restarted.

The freshly read PR review and inline-review-comment collections are empty for
all three PRs. This is not proof that protection requires no approval and is not
an approval from another GitHub account. Merge processing must enforce normal
repository rules.

## Existing CI observed at the exact heads

| Repository | Workflow run | Observation |
| --- | --- | --- |
| Korda | [CI 45772470391](https://github.com/IzuSharp/Korda/actions/runs/45772470391) | completed / success |
| Design | [Current database API design 45783451407](https://github.com/IzuSharp/Korda-Design/actions/runs/45783451407) | completed / success |
| Design | [Historical English and contract acceptance 45783451381](https://github.com/IzuSharp/Korda-Design/actions/runs/45783451381) | completed / success |
| Plan | [Design-owned native research assets 45783337420](https://github.com/IzuSharp/Plan/actions/runs/45783337420) | completed / success |

The product job list confirms successful plan, interop, Linux, PostgreSQL and
SQLite actions, Secret scan, Dependency review, C#/Python CodeQL, and Verify.
`modules` and `publish` were skipped, as expected for this PR plan.

The prior recovery already ran the precise requested command:

```sh
python3 eng/ci/impact.py origin/main --output artifacts/plan.json
```

`/workspace/scratch/166b48a091b9/recovery/impact-current-01.receipt.json`
records exit 0 at 08:42:29.776296 UTC, product tree `bc9087d...`, origin/main
`e063f2eb6e2e857e3f19f96bf263cae372651a27`, and output SHA-256
`c29d60281cef458688a223c3923692d594318503d0a649d78430652dd26b5635`.
This review read that receipt and the corresponding actual plan; it did not
rerun the command during the campaign.

| Scope | Selected checks and reason |
| --- | --- |
| interop | `interop.async`, `interop.callbacks`; changed async and callback lifetimes |
| linux | native, managed database, API/dependency/regression, Fluent API, API tool, migration and relation API checks; affected shared implementation and consumers |
| postgresql | provider build/dependencies, pack, packed API, provider correctness, public Native AOT consumption and public validation |
| sqlite | provider build/dependencies, pack, packed API, provider correctness, public Native AOT consumption and public validation |

The two providers remain independent top-level package checks. The plan has
`modules=[]`, `module_packages=[]`, `deferred=[]` and `releases=[]`. PR validation
version `0.1.0-ci.1` does not establish a published preview.

The actual product diff against origin/main has no `ci.yml` change. The two
benchmark registration files own paths only; neither has an execution action.
The planner regression checks benchmark-only paths select no jobs and affected
product paths still select appropriate provider packages. `worker.py` adds
UTF-8 initialization to the existing correctness PostgreSQL fixture.
`build.yml` adds failure-log retention. `release.yml` preserves actual registry
verification and public-consumption receipts in the existing publication flow.
None of these adds a performance workflow, job, manual button, schedule or hidden
benchmark execution.

## Existing publication rule and required final observations

The unchanged product `ci.yml` selects publish only for a successful Verify on
a push to main in IzuSharp/Korda, a nonempty reconciled release list and
`NUGET_PUBLISH_ENABLED == 'true'`. Main reconciliation compares each provider's
current inputs with its last published package. The resulting versions may
differ; do not guess equal preview numbers.

`release.yml` consumes the already verified candidate artifacts, checks the
tested tree/package bytes/allowlist, and rejects superseded package inputs.
After a permitted publication it reads actual signed registry bytes back,
verifies them and runs the public Native AOT consumer. The existing
`public-consumption-<module>-<version>` artifact preserves that evidence.

Final delivery therefore needs actual merged-main identity, main CI outcome,
both providers' selected version/publication outcomes and public-consumption
receipts. Do not change permissions, skip protection or add another publishing
path if the existing rules do not publish.

## Design and fixed-source correspondence

The authoritative current path is
[execution-path-17da.md](https://github.com/IzuSharp/Korda-Design/blob/ca1933e93678039b492f10a8b47045b11827f1a4/docs/database/execution-path-17da.md).
It binds public entry points, actual 17da files, contract tests and current Plan
evidence. It explicitly retains NWQC composition/semantic compilation for
ordinary Fluent, reused compiled shape for Prepare and fixed-key Find, and the
shared pull/typed-row/DTO route. It records removed second parameter encoding,
Host decoding, owning per-cell staging and replaced generic row-fetch paths.
Required typed snapshots, validation, ownership/notification fences, safe
drain/return and queued final close remain explicit responsibilities.

The rejected quiet-close candidate is not silently part of 17da. Per-execution
PostgreSQL preparation/description and SQLite finalize are retained; physical
statement caches and arbitrary Fluent method-body SQL generation are unselected.
These are documented limitations, not completed cache/generator claims.

Direct inspection of current native lock and consumer projects agrees with the
documented PostgreSQL/libpq 18.0, SQLite 3.51.3, Dapper.AOT 1.1.0, Npgsql 11.0.0
and Microsoft.Data.Sqlite.Core 11.0.0. The Design links exact upstream commits,
and separately binds actual generated two-column phase readers and nine-column
mixed-workload readers. They must not be substituted for one another.

The historical retirement and PostgreSQL experiments retain their original
fixed Design identity. Their guarantees are mapped in current `ported-tests.md`
and the maintained transaction/provider/streaming/protocol fixtures. The prior
review read those correspondences in detail; this recovery does not rerun or
relabel historical test results.

## Historical gate scope is already correct

Plan `.github/workflows/native-slices-final-check.yml` explicitly checks out
`38f8ce8a01f88e6e4c4459926f197c5438c2f6fc` into `perf-history/Plan` and runs
the unchanged `tools/verify_db_perf.py` there. It separately checks the frozen
Rename, C++ migration, Scope and original historical acceptance snapshots.
Design retains `verify_db_rename.py` and `verify_db_scope_history.py`.

The recorded failure from applying the old performance gate directly to changed
current evidence is a scope failure. Preserve it and the successful exact-scope
receipt; do not edit historical verifier bytes or thresholds to accept current
continuation data. New campaign acceptance belongs to its current auditor.

## Current navigation updates needed before delivery

These do not justify interrupting the frozen campaign or writing a branch that
another conversation may own. Update them once ownership/handoff is established
and final observations exist, retaining the older checkpoint text as history.

1. Design PR20 and Plan PR34 bodies still lead with continuation-5 and
   `b748d89`, older pending implementation and old Design identities. Product
   PR37 also predates the accepted current 120-second evidence. Refresh all
   three descriptions using current fixed links and actual final status.
2. Plan `execution-refactor/current-checkpoint.md` opens with the old 15:16
   checkpoint, Design `da8c314`, PostgreSQL phases running and analysis pending.
   Prepend a new verified checkpoint rather than overwriting history.
3. Design `docs/generators/query-generation.md` currently says final integrated
   package gates remain pending (lines 21-23). Its current section should link
   the successful exact-17da independent package evidence while keeping final
   performance acceptance separate.
4. `execution-path-17da.md` correctly said 0/4 at its frozen checkpoint. Preserve
   that checkpoint identity, and link a new final acceptance record after the
   actual campaign verdict rather than presenting old prose as current delivery.

## Final reporting limits

Keep framework-only 0 B unproven (`FrameworkOnlyBytes=null`); separately measured
mapper/List allocation cannot be subtracted to manufacture a framework number.
Report GC over its actual process-wide measurement windows and keep rejection,
error, CPU, RSS and latency scopes explicit. The quiet-close rejection does not
prove all conceivable optimizations are exhausted. A justified stop names the
completed path, observed gains, rejected experiment, remaining measured/unproven
costs and practical end of this round. It must not claim universal zero allocation
or that all further measurable improvements have disappeared.
