from pathlib import Path

P = Path('/workspace/scratch/697b7eeade37/.worktree/DB-CPP-01-linux/Plan')
B = P / 'ledger/evidence/batches/DB-CPP-01'

def replace_once(text, before, after):
    assert text.count(before) == 1, before[:100]
    return text.replace(before, after)

report_path = B / 'migration-report-linux.md'
report = report_path.read_text()
start = report.index('**Status:')
end = report.index('\n\n## Scope and frozen reference')
report = report[:start] + '''**Status: the delivered Linux x64 migration is accepted.** The fixed Rust product at `465cd0f90e6af05ec50eb581156240377cf0825b` is replaced by the C++ implementation tested at `39b5b72ff9bf4d8a485b55debf940f4ded83bbe2` and normally merged as `3badc05be503991b5591732629dd7e5b0dbad111` through [product PR21](https://github.com/IzuSharp/NativeWeave/pull/21). Both commits have tree `3264de79b73c8a89f1cac1eff57d0c0ff2c841c2`. C# API, C ABI, all twelve NuGet identities and historical database formats remain compatible. The same versioned business consumer passed PostgreSQL/SQLite × JIT/Native AOT against the fixed Rust packages and the C++ candidate; changing its DTO left the candidate native hashes unchanged.

All **21 acceptance checks and seven execution phases** are complete in [acceptance.json](acceptance.json). Product [PR CI44974091036](https://github.com/IzuSharp/NativeWeave/actions/runs/44974091036) passed all six jobs and 57 steps. Its separately observed [merged-main CI44977773509](https://github.com/IzuSharp/NativeWeave/actions/runs/44977773509) passed all five required jobs and 52 steps; only the normal PR-only dependency-review job was skipped. Design PR15 and Plan PR26 are also normally merged with successful exact-head and merged-main CI. The typed main receipts for [product](receipts/product-merged-main-44977773509.json), [Design](receipts/design-merged_main.json) and [Plan](receipts/plan-merged-main-44980202529.json) bind the actual observations. The normal main workflow does not repeat the fixed-Rust comparison; that comparison remains attached to its actual candidate-7 PR/local executions.

This final evidence-only record accepts the delivered Plan26 snapshot: tested head `66a75ea0e6ace98a861939da05efabc3e7a702c2`, merge `5ee6b41a24803391044715b0ce82f4a394a4dbf8`, shared tree `656e9a62a367de04a25b857716785ead58041dfe`. Its own technical review, PR checks, normal merge and merged-main CI are checked separately and linked in the evidence PR discussion; this file does not predict its containing commit's future CI result. There is no remaining product capability or acceptance blocker within Linux x64. The inherited behavior limits below remain explicit. Public package publication, other platforms, DB-API-01 and DB-Perf-01 remain outside this delivery.

Candidate 7 changed only two exact diagnostic literals after candidate 6's full database regression and LSan stages passed but its later Core negative-oracle matcher failed. The [candidate 6 rejection snapshot](checkpoints/candidate-6/acceptance-at-rejection.json) retains its fifteen actual passes, failed required-CI check and five pending checks. New candidate-7 and merged-main executions do not rewrite earlier failure states. The [normal product merge observation](ci/product-pr21-merged.json) records the distinct tested head and merge commit; both CI results were observed independently.''' + report[end:]
report = replace_once(report,
    'The retained suite subsequently failed an original SQLite physical-input refusal assertion, described below; correction and fresh final gates are required. No final migration acceptance is claimed.',
    'The retained suite subsequently failed an original SQLite physical-input refusal assertion, described below. At that historical checkpoint correction and fresh final gates were still required; candidate 3 was not accepted. Later corrections and source-bound executions establish the final candidate separately.')
report = replace_once(report,
    'Product merged-main and final Plan acceptance are still pending.',
    'The separately observed product merged-main run also passed the complete profile; the three-repository delivered snapshot is now accepted through its own exact identities and receipts.')
report = replace_once(report,
    '[main CI44977773509](https://github.com/IzuSharp/NativeWeave/actions/runs/44977773509) is in progress, not accepted',
    '[main CI44977773509](https://github.com/IzuSharp/NativeWeave/actions/runs/44977773509) passed all five required jobs / 52 steps at the actual merge')
report = replace_once(report,
    '[main CI44980202529](https://github.com/IzuSharp/Plan/actions/runs/44980202529) has started at the actual merge and is not yet accepted',
    '[main CI44980202529](https://github.com/IzuSharp/Plan/actions/runs/44980202529) passed its required job and all fourteen steps at the actual merge')
old_tail = 'Twenty of the twenty-one acceptance checks now pass.'
tail_start = report.index(old_tail)
tail_end = report.index('\n\nThe frozen candidate4', tail_start)
report = report[:tail_start] + '''All twenty-one acceptance checks pass. The final `review-and-merge` phase is complete for the delivered Product21 / Design15 / Plan26 snapshot. Product [main CI44977773509](https://github.com/IzuSharp/NativeWeave/actions/runs/44977773509) and Plan [main CI44980202529](https://github.com/IzuSharp/Plan/actions/runs/44980202529) were retrieved as completed/success at their actual merge commits, with complete successful mandatory job/step inventories. Product's normal PR-only dependency-review skip is explicitly retained, not omitted from the observation.

The evidence-only follow-up preserves `candidate_sources.Plan` at the tested Plan26 head and records a separate `delivery_snapshot`; it does not substitute the evidence-container commit for the delivered source. Run `python3 tools/verify_db_cpp.py --require-complete` to verify all 21 claims, seven phases, exact receipt/hash/source links, untouched historical acceptance and 37 in-memory rejection controls. The verifier and workflow bytes remain unchanged. The follow-up's own technical review, PR CI, merge and main CI must be observed separately in its PR discussion before the final user handoff. Stop after those checks; do not begin another task.

On resume, the remote task branch ended at `8c42522513b194007231f09aa6a019ac21f72a43`; the prior chat's final local 21/21 commit was not present. The old orphan worktree and SDK copy were removed under the owner's explicit cleanup instruction, and the three requested worktrees were restored from GitHub. [The resumed cleanup record](cleanup-resume-linux.json) distinguishes this from the earlier initial cleanup. The final evidence was reconstructed from freshly retrieved official CI observations and archive bytes; the resumed session did not rerun product/database execution or relabel older runs as new ones.''' + report[tail_end:]
report = report.replace('## Review, PRs, CI and remaining work', '## Review, PRs, CI and delivery closeout')
report_path.write_text(report)

handoff_path = B / 'handoff-linux.md'
handoff = handoff_path.read_text()
start = handoff.index('## Current state:')
end = handoff.index('\n## Reference and toolchain')
handoff = handoff[:start] + '''## Current state: delivered migration accepted; final evidence record checks are separate

The owner authorized the database-only Rust-to-C++ migration, tests, documentation, pushes, PRs and normal merges. The delivered Linux x64 snapshot is accepted: **21/21 checks and seven complete phases**. Earlier failures remain evidence at their actual sources. DB-API-01 and DB-Perf-01 remain excluded. This evidence-only follow-up must complete its own technical review, PR CI, normal merge and merged-main CI before the final user handoff; those outcomes are linked in its PR discussion rather than predicted in this commit.

| Repository | Frozen merged starting commit | Delivered source and observed verification |
| --- | --- | --- |
| NativeWeave | `465cd0f90e6af05ec50eb581156240377cf0825b` | [PR21](https://github.com/IzuSharp/NativeWeave/pull/21) merged as `3badc05be503991b5591732629dd7e5b0dbad111`; tested head `39b5b72ff9bf4d8a485b55debf940f4ded83bbe2`; both trees `3264de79b73c8a89f1cac1eff57d0c0ff2c841c2`; [PR CI44974091036](https://github.com/IzuSharp/NativeWeave/actions/runs/44974091036) and [main CI44977773509](https://github.com/IzuSharp/NativeWeave/actions/runs/44977773509) passed |
| NativeWeave-Design | `8298dc4128b745cf1809bad0c3cf02c45eb7f522` | [PR15](https://github.com/IzuSharp/NativeWeave-Design/pull/15) merged as `de1f4796dc199250b405ea99f2129d611f17b1f6`; exact PR and main CI passed |
| Plan | `1fe52a8bd792ccdbb4bbea17ba59b0ad0c24349d` | [PR26](https://github.com/IzuSharp/Plan/pull/26) merged as `5ee6b41a24803391044715b0ce82f4a394a4dbf8`; tested head `66a75ea0e6ace98a861939da05efabc3e7a702c2`; both trees `656e9a62a367de04a25b857716785ead58041dfe`; [PR CI44979726276](https://github.com/IzuSharp/Plan/actions/runs/44979726276) and [main CI44980202529](https://github.com/IzuSharp/Plan/actions/runs/44980202529) passed |

All work branches use `task/DB-CPP-01-linux`. Worktrees are `ROOT/.worktree/DB-CPP-01-linux/{NativeWeave,NativeWeave-Design,Plan}`. The original read-only Rust reference source and package identities remain fixed in the reference evidence. On final resume, the last remote evidence checkpoint was `8c42522513b194007231f09aa6a019ac21f72a43`; the prior final local commit was not available. The owner-requested orphan worktree/SDK cleanup is complete and [recorded separately](cleanup-resume-linux.json); the final record was reconstructed from official CI observations and archives. Preserve current work and existing diagnostic records. The resumed closeout does not claim a new product or database test run.
''' + handoff[end:]
handoff = replace_once(handoff,
    'Twenty ledger checks now pass; only the all-repository merged-main claim remains pending.',
    'All twenty-one ledger checks now pass after the separate all-repository merged-main observations were recorded.')
handoff = handoff.replace('## Candidate 7 correction and next actions', '## Candidate 7 correction and observed acceptance')
handoff = handoff.replace('## Product merge and remaining closeout', '## Product merge and final evidence closeout')
old_last = '[Product main CI44977773509](https://github.com/IzuSharp/NativeWeave/actions/runs/44977773509) and [Plan main CI44980202529](https://github.com/IzuSharp/Plan/actions/runs/44980202529) are executing at their actual merge commits. Their results are not inferred from PR success. The task branch was fast-forwarded to the Plan26 merge for the evidence-only follow-up. Next: observe both complete main runs, finalize [the report](migration-report-linux.md) and record the delivered Plan26 identities through that follow-up, then verify the follow-up\'s own review/PR/main checks separately. DB-CPP-01 remains incomplete until those gates finish; stop after this task.'
handoff = replace_once(handoff, old_last, '''[Product main CI44977773509](https://github.com/IzuSharp/NativeWeave/actions/runs/44977773509) and [Plan main CI44980202529](https://github.com/IzuSharp/Plan/actions/runs/44980202529) both completed successfully at their actual merge commits. Product has five required successful jobs / 52 successful steps, with the normal PR-only dependency-review job skipped; Plan has its required job / fourteen successful steps. These are fresh API observations, not conclusions inferred from PR success. Their typed receipts and the existing Design main receipt close the final aggregate claim.

The final [migration report](migration-report-linux.md), [migration table](migration-table.md), [plan](plan.md) and [acceptance](acceptance.json) now record the delivered source identities and all 21 accepted claims. `python3 tools/verify_db_cpp.py --require-complete` passes, including 37 in-memory rejection controls; verifier and workflow bytes are unchanged. `delivery_snapshot` fixes the delivered Plan26 head/merge and marks this record's own CI as `checked-separately`.

Remaining actions for this evidence-only follow-up: finish its scoped non-author review, open its PR from `task/DB-CPP-01-linux`, observe every required PR check, perform a normal merge at the reviewed head, and observe the actual merged-main CI. Record those observed URLs in the PR discussion and final user response. Do not reopen implementation or repeat accepted product tests merely because this evidence file has a new commit. Stop after final record delivery; DB-API-01 and DB-Perf-01 remain unauthorized here.''')
handoff_path.write_text(handoff)

plan_path = B / 'plan.md'
plan = plan_path.read_text()
plan = plan.replace('Implemented; complete candidate-7 PR CI passed; merged-main/final record pending', 'Accepted; candidate-7 PR and actual merged-main gates passed')
plan = plan.replace('Source7 fresh four-cell and complete PR CI passed; product merged, exact main/final Plan checks pending', 'Accepted; source7 four-cell comparison passed; Product21, Design15 and Plan26 merged with exact main CI')
plan += '\n## Observed delivered snapshot\n\nAll 21 claims and seven phases are complete for Product21 / Design15 / Plan26. The final [report](migration-report-linux.md) and [acceptance record](acceptance.json) bind their exact tested/merged sources and successful PR/main CI. The evidence-only follow-up is reviewed and checked through its own PR/main CI separately, as required by [the receipt schema](receipt-schema.md#plan-delivery-without-a-circular-ci-claim). No product gate or historical acceptance was weakened.\n'
plan_path.write_text(plan)

table_path = B / 'migration-table.md'
table = table_path.read_text()
table_start = table.index('| Existing contract')
table = '''# DB-CPP-01 contract migration table

The fixed Rust reference is NativeWeave `465cd0f90e6af05ec50eb581156240377cf0825b`. The accepted C++ candidate is `39b5b72ff9bf4d8a485b55debf940f4ded83bbe2`, normally merged as `3badc05be503991b5591732629dd7e5b0dbad111`; both trees are `3264de79b73c8a89f1cac1eff57d0c0ff2c841c2`. All 21 source-bound checks and seven phases pass in [acceptance.json](acceptance.json). The actual [PR CI44974091036](https://github.com/IzuSharp/NativeWeave/actions/runs/44974091036) and [main CI44977773509](https://github.com/IzuSharp/NativeWeave/actions/runs/44977773509) passed their full mandatory gates. Earlier candidate failures remain historical; none was relabeled as accepted.

The fixed-Rust four-cell comparison belongs to the candidate's actual PR/local executions. Normal main has its own regression/build/package/no-Rust gates and does not repeat the historical comparison. This final evidence-only follow-up has separate review and PR/main checks; its ledger accepts the delivered Product21 / Design15 / Plan26 identities.

''' + table[table_start:]
table = table.replace('Implemented; candidate `1ccfcb7` complete local regression passed; required full CI pending', 'Accepted; candidate-7 complete PR and merged-main gates passed')
table = table.replace('Candidate6 twelve-package preparation and fresh four-cell comparison passed; complete release/runtime CI pending', 'Accepted; twelve-package preparation and four-cell comparison passed; complete release/pristine/runtime/no-Rust gates passed')
table = table.replace('Design15 merged with green main CI; Product21 and Plan26 remain draft', 'Accepted; Design15, Product21 and Plan26 normally merged with successful exact PR/main CI; final evidence record checks are separate')
table_path.write_text(table)
print('Updated current report, handoff, migration table and plan; historical evidence retained.')
