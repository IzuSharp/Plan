#!/usr/bin/env python3
"""Retain additional historical evidence before separately authorized cleanup.

This script never deletes, rewrites, fetches, or checks out a source repository.
All output is below the explicit current recovery root. Archived paths and bytes
are inventoried; executable/package outputs and credential material are omitted.
"""
from __future__ import annotations

import datetime as dt
import gzip
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import tarfile
import zipfile


ROOT = Path('/workspace/scratch/2dfe9fb1bc53')
DEST = ROOT / 'additional-retention'
INVENTORY = ROOT / 'cleanup-additional-inventory.json'
INVENTORY_SHA = 'ac1bcdcbba1ef5a704b330fd0924861a1f5b680c734a7287001cc7ff3c13f277'
OLD = Path('/workspace/scratch/697b7eeade37')
PRIMARY = Path('/workspace/scratch/4a65d70f0fe1/repos')
ARCHIVE = ROOT / 'additional-retention.tar.gz'
RECEIPT = ROOT / 'additional-retention-readback.json'
REMOTE_VERIFICATION = ROOT / 'additional-git-remote-verification.json'


def digest(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def git(gd: Path, *args: str, input_data: bytes | None = None) -> bytes:
    env = dict(os.environ, GIT_OPTIONAL_LOCKS='0')
    p = subprocess.run(['git', '--git-dir=' + str(gd), *args],
                       input=input_data, stdout=subprocess.PIPE,
                       stderr=subprocess.PIPE, env=env)
    if p.returncode:
        raise RuntimeError(f'Git read/bundle operation failed: {args[0]}, code {p.returncode}')
    return p.stdout


def checked_bytes(p: Path, expected: dict | None = None) -> bytes:
    before = p.lstat()
    assert stat.S_ISREG(before.st_mode) and not p.is_symlink(), str(p)
    b = p.read_bytes()
    after = p.lstat()
    assert (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) == (
        after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns), str(p)
    if expected:
        for key, val in [('device', before.st_dev), ('inode', before.st_ino),
                         ('bytes', len(b)), ('mtimeNs', before.st_mtime_ns)]:
            assert expected[key] == val, (str(p), key)
        assert expected['sha256'] == digest(b), str(p)
    return b


SENSITIVE = [
    ('private-key', re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH |DSA |ENCRYPTED )?PRIVATE KEY-----')),
    ('github-token', re.compile(rb'\bgh[pousr]_[A-Za-z0-9]{36,255}\b')),
    ('github-fine-token', re.compile(rb'\bgithub_pat_[A-Za-z0-9_]{40,255}\b')),
    ('aws-access-key', re.compile(rb'\b(?:AKIA|ASIA)[A-Z0-9]{16}\b')),
    ('bearer-token', re.compile(rb'(?i)Authorization:\s*Bearer\s+[A-Za-z0-9_\-.]{35,}')),
    ('signed-storage-query', re.compile(rb'(?i)(?:[?&]|&amp;)sig=[A-Za-z0-9%/+]{30,}')),
]


def classify(p: str, b: bytes) -> str | None:
    suffix = PurePosixPath(p).suffix.lower()
    if suffix in {'.pem', '.pfx', '.p12', '.key'}:
        return 'credential-or-certificate-material-excluded'
    if suffix in {'.zip', '.nupkg', '.snupkg', '.dll', '.so', '.a', '.o', '.dbg', '.exe', '.pdb'}:
        return 'rebuildable-package-or-compiled-output-excluded'
    if b.startswith((b'\x7fELF', b'MZ', b'!<arch>')):
        return 'rebuildable-compiled-output-excluded'
    if b.startswith(b'SQLite format 3'):
        return 'database-file-excluded'
    for name, pattern in SENSITIVE:
        if pattern.search(b):
            return 'sensitive-pattern-excluded:' + name
    try:
        b.decode('utf-8')
    except UnicodeDecodeError:
        return 'non-text-unclassified-excluded-needs-review'
    if b'\0' in b:
        return 'non-text-unclassified-excluded-needs-review'
    return None


def dump(p: Path, obj: object) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + '\n')


def main() -> None:
    inv_bytes = checked_bytes(INVENTORY)
    assert digest(inv_bytes) == INVENTORY_SHA
    inv = json.loads(inv_bytes)
    remote_verification = json.loads(checked_bytes(REMOTE_VERIFICATION))
    verified_remote = {(x['repo'], x['requestedSha']): x for x in remote_verification['results'] if x['verified']}
    assert not DEST.is_symlink() and not ARCHIVE.exists() and not RECEIPT.exists()
    DEST.mkdir(exist_ok=True)
    retained: list[dict] = []
    omitted: list[dict] = []
    expected_sources: list[dict] = []

    def retain(source: str, b: bytes, category: str, member: str | None = None) -> None:
        reason = classify(member or source, b)
        if reason:
            omitted.append({'sourcePath': source, 'zipMember': member,
                            'bytes': len(b), 'sha256': digest(b), 'reason': reason})
            return
        if member is None:
            rel = 'original-paths/' + source.lstrip('/')
        else:
            part = PurePosixPath(member)
            assert not part.is_absolute() and '..' not in part.parts
            rel = 'zip-members/' + source.lstrip('/') + '/' + str(part)
        p = DEST / rel
        if p.exists():
            assert p.read_bytes() == b
        else:
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_bytes(b)
        retained.append({'sourcePath': source, 'zipMember': member,
                         'archivePath': rel, 'category': category,
                         'bytes': len(b), 'sha256': digest(b)})

    # Every previously fingerprinted unique/dirty file is checked before copying.
    for repo in inv['additionalRepositories']:
        for entry in repo['dirtyFiles']:
            retain(entry['path'], checked_bytes(Path(entry['path']), entry), 'dirty-or-untracked-project-file')
            expected_sources.append(entry)
        if repo['dirtyFiles']:
            diff_run = subprocess.run(['git', '-C', repo['worktree'], 'diff', '--binary', 'HEAD'],
                                      stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                      env=dict(os.environ, GIT_OPTIONAL_LOCKS='0'), check=True)
            diff = diff_run.stdout
            assert digest(diff) == repo['diffSha256'] and len(diff) == repo['diffBytes']
            assert not any(p.search(diff) for _, p in SENSITIVE)
            diffpath = 'derived/git-diffs/' + Path(repo['gitDirectory']).name + '.patch'
            (DEST / diffpath).parent.mkdir(parents=True, exist_ok=True)
            (DEST / diffpath).write_bytes(diff)
            retained.append({'sourcePath': repo['worktree'], 'archivePath': diffpath,
                             'category': 'derived-git-diff', 'bytes': len(diff), 'sha256': digest(diff)})
    for group in inv['retentionBeforeDeletion']:
        for entry in group['files']:
            retain(entry['path'], checked_bytes(Path(entry['path']), entry), 'historical-recovery-or-closeout-record')
            expected_sources.append(entry)
    for group in inv['additionalMsbuildTemporaryDirectories']:
        for entry in group['files']:
            retain(entry['path'], checked_bytes(Path(entry['path']), entry), 'historical-msbuild-failure-or-response')
            expected_sources.append(entry)

    # Retain all unclassified text in both expanded CI artifact trees. Known
    # rebuildable package/ELF outputs and all PEM credential fixtures are omitted.
    artifact_root = OLD / 'closeout-artifacts'
    for p in sorted(artifact_root.rglob('*')):
        if p.is_file() and not p.is_symlink():
            retain(str(p), checked_bytes(p), 'historical-ci-artifact-text')

    # Confirm original ZIPs have no unhandled evidence that was absent from the
    # expanded trees; preserve text-only ZIP members if any were not expanded.
    zip_audits = []
    for p in sorted(artifact_root.glob('*.zip')):
        entry_records = []
        expanded = p.with_suffix('')
        with zipfile.ZipFile(p) as z:
            for item in z.infolist():
                if item.is_dir():
                    continue
                member = PurePosixPath(item.filename)
                assert not member.is_absolute() and '..' not in member.parts
                b = z.read(item)
                q = expanded / Path(str(member))
                expanded_equal = q.is_file() and not q.is_symlink() and checked_bytes(q) == b
                reason = classify(item.filename, b)
                if not expanded_equal:
                    retain(str(p), b, 'historical-ci-artifact-zip-only-text', item.filename)
                entry_records.append({'member': item.filename, 'bytes': len(b),
                                      'sha256': digest(b), 'expandedFile': str(q),
                                      'expandedByteIdentical': expanded_equal,
                                      'omissionClass': reason})
        zip_audits.append({'sourcePath': str(p), 'sha256': digest(checked_bytes(p)),
                           'members': entry_records, 'memberCount': len(entry_records),
                           'allExpandedByteIdentical': all(e['expandedByteIdentical'] for e in entry_records)})
    dump(DEST / 'derived/zip-expanded-audit.json', zip_audits)

    # Record every older ref/object relationship to the corresponding primary
    # repository. Only missing historical refs require a small incremental bundle.
    coverage = []
    for oldname, newname in [('NativeWeave', 'Korda'), ('NativeWeave-Design', 'Korda-Design'), ('Plan', 'Plan')]:
        oldgit, primarygit = OLD / 'repos' / (oldname + '.git'), PRIMARY / (newname + '.git')
        rawrefs = git(oldgit, 'for-each-ref', '--format=%(objectname) %(refname)').decode().splitlines()
        refs = [{'oid': s.split(' ', 1)[0], 'ref': s.split(' ', 1)[1]} for s in rawrefs]
        oldobjects = [s.split(' ', 1)[0] for s in git(oldgit, 'rev-list', '--objects', '--all').decode().splitlines()]
        checks = git(primarygit, 'cat-file', '--batch-check=%(objectname) %(objecttype)',
                     input_data=('\n'.join(oldobjects) + '\n').encode()).decode().splitlines()
        existing = {s.split()[0] for s in checks if not s.endswith(' missing')}
        primary_reachable = {s.split(' ', 1)[0] for s in git(primarygit, 'rev-list', '--objects', '--all').decode().splitlines()}
        remote_repo = 'IzuSharp/' + newname
        missing_refs = [r for r in refs if r['oid'] not in existing and (remote_repo, r['oid']) not in verified_remote]
        common_refs = [r for r in refs if r['oid'] in existing]
        for ref in refs:
            ref['objectExistsInPrimary'] = ref['oid'] in existing
            ref['reachableFromPrimaryRefs'] = ref['oid'] in primary_reachable
            if (remote_repo, ref['oid']) in verified_remote:
                ref['remoteVerification'] = verified_remote[(remote_repo, ref['oid'])]
            ref['tree'] = git(oldgit, 'rev-parse', ref['oid'] + '^{tree}').decode().strip()
            if ref['objectExistsInPrimary']:
                ref['primaryTree'] = git(primarygit, 'rev-parse', ref['oid'] + '^{tree}').decode().strip()
                assert ref['tree'] == ref['primaryTree']
        cov = {'oldRepository': str(oldgit), 'primaryRepository': str(primarygit),
               'refs': refs, 'oldReachableObjectCount': len(oldobjects),
               'missingObjectCountInPrimary': len(set(oldobjects) - existing),
               'missingObjectIdsInPrimary': sorted(set(oldobjects) - existing),
               'missingRefCountInPrimary': sum(r['oid'] not in existing for r in refs),
               'missingRefCountInPrimaryAndNotRemoteVerified': len(missing_refs),
               'interpretation': 'Matching objects/trees are local duplication evidence, not proof of remote publication. Primary project evidence is handled by the main cleanup workflow.'}
        if missing_refs:
            bundle = DEST / 'derived/git-bundles' / (oldname + '-additional-history.bundle')
            bundle.parent.mkdir(parents=True, exist_ok=True)
            args = ['bundle', 'create', str(bundle)] + [x['ref'] for x in missing_refs]
            args += ['--not'] + [x['oid'] for x in common_refs]
            git(oldgit, *args)
            verify = subprocess.run(['git', '--git-dir=' + str(primarygit), 'bundle', 'verify', str(bundle)],
                                    stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=dict(os.environ, GIT_OPTIONAL_LOCKS='0'))
            assert verify.returncode == 0, oldname
            raw = checked_bytes(bundle)
            bundle_header = raw.split(b'\n\n', 1)[0].decode()
            prerequisites = [s[1:].split(' ', 1)[0] for s in bundle_header.splitlines() if s.startswith('-')]
            prerequisite_remote = []
            for oid in prerequisites:
                assert (remote_repo, oid) in verified_remote, ('Unverified remote prerequisite', remote_repo, oid)
                prerequisite_remote.append(verified_remote[(remote_repo, oid)])
            cov['bundle'] = {'archivePath': str(bundle.relative_to(DEST)),
                             'bytes': len(raw), 'sha256': digest(raw),
                             'header': bundle_header.splitlines(),
                             'prerequisites': prerequisites,
                             'remotePrerequisiteVerification': prerequisite_remote,
                             'verifiedAgainstPrimaryRepository': True,
                             'verifyExit': verify.returncode,
                             'heads': git(oldgit, 'bundle', 'list-heads', str(bundle)).decode().splitlines()}
            retained.append({'sourcePath': str(oldgit), 'archivePath': str(bundle.relative_to(DEST)),
                             'category': 'incremental-git-history-with-remote-verified-prerequisites',
                             'bytes': len(raw), 'sha256': digest(raw)})
        else:
            assert not cov['missingObjectCountInPrimary'] or all(
                r['oid'] in existing or (remote_repo, r['oid']) in verified_remote for r in refs)
        coverage.append(cov)
    dump(DEST / 'derived/git-coverage.json', coverage)

    # Original audit/script are retained as inputs to this archival decision.
    retain(str(INVENTORY), inv_bytes, 'cleanup-inventory')
    retain(str(REMOTE_VERIFICATION), checked_bytes(REMOTE_VERIFICATION), 'remote-git-prerequisite-verification')
    retain(str(Path(__file__).resolve()), checked_bytes(Path(__file__).resolve()), 'archival-script')
    # Explicit source checks show that fingerprinted originals were not changed.
    for entry in expected_sources:
        checked_bytes(Path(entry['path']), entry)
    manifest = {
        'schemaVersion': 1, 'task': 'DB-Go-01 additional historical retention',
        'createdAtUtc': dt.datetime.now(dt.timezone.utc).isoformat(),
        'scope': 'Supplemental evidence outside the three original cleanup roots; no performance test was rerun.',
        'sourceInventoryPath': str(INVENTORY), 'sourceInventorySha256': INVENTORY_SHA,
        'retained': retained, 'omitted': omitted,
        'retainedFileCount': len(retained), 'retainedBytes': sum(x['bytes'] for x in retained),
        'omittedFileCount': len(omitted), 'omittedBytes': sum(x['bytes'] for x in omitted),
        'omissionRules': 'Compiled/package outputs, database files and all credential/certificate material excluded. ZIP containers excluded after expanded/member audit. Cache contents excluded; inventory only retained.',
        'sourceChecks': {'fingerprintedOriginalCount': len(expected_sources), 'allUnchanged': True},
        'secretScan': {'highConfidencePatterns': [name for name, _ in SENSITIVE],
                       'method': 'Before any retained text write; matching whole files omitted and recorded with hash only.',
                       'scopeLimitation': 'Not a mathematical proof that arbitrary text contains no secret; repository history is preserved as incremental git objects.'},
        'additionalRecordFiles': ['derived/git-coverage.json', 'derived/zip-expanded-audit.json'],
        'binaryRecoveryClaim': False, 'remoteUploadPerformed': False, 'deletionPerformed': False,
    }
    dump(DEST / 'retention-manifest.json', manifest)
    # Exact deterministic regular-member archive with no symlinks or absolute
    # tar names, and read back every member rather than only hashing the gzip.
    files = [p for p in sorted(DEST.rglob('*')) if p.is_file()]
    expected_members = {str(p.relative_to(DEST)): {'bytes': p.stat().st_size, 'sha256': digest(checked_bytes(p))} for p in files}
    with ARCHIVE.open('wb') as raw:
        with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as gz:
            with tarfile.open(fileobj=gz, mode='w', format=tarfile.PAX_FORMAT) as tar:
                for p in files:
                    b = checked_bytes(p)
                    item = tarfile.TarInfo(str(p.relative_to(DEST)))
                    item.size, item.mode, item.mtime = len(b), 0o644, 0
                    item.uid = item.gid = 0
                    tar.addfile(item, io.BytesIO(b))
    readback = []
    with tarfile.open(ARCHIVE, 'r:gz') as tar:
        for member in tar:
            assert member.isfile() and member.name in expected_members
            b = tar.extractfile(member).read()
            expected = expected_members.pop(member.name)
            assert expected == {'bytes': len(b), 'sha256': digest(b)}, member.name
            readback.append({'member': member.name, **expected, 'verified': True})
    assert not expected_members
    receipt = {
        'schemaVersion': 1, 'archivePath': str(ARCHIVE),
        'archiveBytes': ARCHIVE.stat().st_size, 'archiveSha256': digest(checked_bytes(ARCHIVE)),
        'manifestPath': str(DEST / 'retention-manifest.json'),
        'manifestSha256': digest(checked_bytes(DEST / 'retention-manifest.json')),
        'members': readback, 'memberCount': len(readback), 'allMembersVerified': True,
        'remoteReadbackVerified': False, 'deletionPerformed': False,
    }
    dump(RECEIPT, receipt)
    print(json.dumps({k: v for k, v in receipt.items() if k != 'members'}))
    print(json.dumps({'retainedFiles': len(retained), 'omittedFiles': len(omitted),
                      'sensitiveOmissions': sum('sensitive-pattern' in x['reason'] for x in omitted),
                      'unclassifiedOmissions': sum('unclassified' in x['reason'] for x in omitted),
                      'bundleBytes': {Path(c['oldRepository']).name: c.get('bundle', {}).get('bytes', 0) for c in coverage}}))


if __name__ == '__main__':
    main()
