# Active Go-only continuation — resume without rerunning

Latest owner instruction: Go comparison only; the two already-open PRs are records and MUST NOT BE MERGED. Keep Korda #39 and Plan #35 draft/open; do not enable auto-merge, change product, or rerun old Korda/Dapper timings. Continue the two Go 30-minute cells, report, durable archive/readback, and delete all local task directories/worktrees/caches.

Current running unified exec session: 69957. Serial supervisor start 2026-11-26T13:09:30.746217Z; SQLite Go warmup finished 13:09:31.176096609Z, then its 1800s steady interval begins. Supervisor automatically starts PG only after SQLite+15s idle+runner exit. Expected entire campaign end about14:10Z; use actual receipts, not estimates.

Read campaign-state.json and campaign-events.jsonl, or wait on session69957. Never restart the supervisor or completed cells. It refuses existing state. Frozen inputs immutable. During formal work do not build, run tests/profiles, scan large trees, compress archives, or change frozen/product code. Lightweight status reads on observer CPU8 and remote GitHub metadata only.

Root: /workspace/scratch/166b48a091b9/go-comparison-01
Product worktree: ../worktrees/DB-Go-01-korda
Plan worktree: ../worktrees/DB-Go-01-plan
Freeze SHA256 fc08a113b690b55a38aee9c1f295c65475058c81ed8ee4be0e1ec19d16a63fe8 (38files), final-readiness-review.json ready=true.
Runtime build commit94eb3a7675a44e30c6f9ed6c7a7edda987fe36db; local final product da76bad28df60dbd3ce9023522bfecaa5371cf87; exact source-history.bundle preserves these commits.
Public Korda #39 head d5f4f9d6616bad54a08aebb7d1aca7937b18eb93, treef8744d7735e47552c657d3b18ad5cd9e39946db9 = local finaltree. CI45825411327success; actual plan/PythonCodeQL/Dependencyreview/Secretscan/Verify pass, build/modules/publish skipped, no comments/reviews/threads. Main7ff7b57...unchanged.
Plan #35 checkpoint head a1db7b12a66ae9740f9a49016039ae4dd2e15025, treecc128f9c11b1a79616d85e74f1684ce69245d571 = local9c3aed0e148ad2d53a2e8a5496532be250409593. Base03efe57ffbe3046bd89919ddb2c16c90a377954d. Both PR bodies now explicitly record-only/no merge.

Final bins: SQLite11d6ffcfcc93a1d4459d6da2f92c6e7b7d48ce788ff26ac4ca331cca02defd2a; PG a75f351d2e01c530442a93fc1d7d129bd2b38911b269a95f30ce677dcaec2eaa. Go1.27.4, pgx5.11.0 exec/no statement cache, go-sqlite3v1.14.53/exactSQLite3.51.3 .so. CGO_ENABLED1; driver-specific binaries (PG noSQLite dependency). Formal plans and raw outputs under plans/ and measurements/{sqlite,postgresql}-final-01. SameSQL35case, rows/batch32,8tenantsx1024orders, warmup64afterfull35verify, queue64, SQLiteC4/R3000, PGC8/R3600, GOMAXPROCS4/GOGC100/memorylimitoff, clients0–3/PG4–7/observer8.

Exact final provider preflight-02 accepted: SQLite15000success/0reject; PG17927success/73reject; both business/oracle/errors/retries0 and observed connectionsafterclose all0. All counters/digests/hists/SQLweighted sums verified. Go unit tests final pass0.008s; 45Toolingtests pass/1existing skip. Initialjoint-binpreflight-01 retained as preparation only. build/failed-attempt-01.json retains VCS-stamp cwd failure; final-unit-tests-01.log retains wrong-module-cwd test invocation failure; tests02/03 pass. Direct gitpush failed no CLI credentials; use GitHub GitData APIs via publication_tools/prepare.py (no escalation).

After both cells: verify with product benchmarks/db-perf/go/verify_result.py --result .../go-c4|8.json --command ...command.json --manifest /tmp/DB-Exec-10-pack-sqlite-02/benchmarks/db-perf/workload/queries-v3.json --kind final --output analysis/{provider}-final-01.json; exact input hashes remain available until cleanup. Independently audit both + all38inputrehash. Then preserve source/build/env/plan/rawstdout/resources/command/results/analysis/errors/helper/cleanup inventories. No SDK/cache/binary/database recovery claim; hashes and source bundle retained.

Old four-cell canonicalreport: Plan03efe.../ledger/evidence/batches/DB-Perf-01/execution-refactor/continuation-8/final-report.md. Reuse historicalresults, donotrerun. Critical: SQLiteDapper wholecommandwait4peakRSS=35479552bytes, not endpointVmHWM33923072. GoGCnon-generational vs.NETgens must label. Totalheapalloc includesbusiness+driver+harness, no framework0claim. Throughput fixedofferrate, notmaxcapacity.

Cleanup: final_cleanup.py SHA79088224364dd5b1321e83c30aa462a2e3bd79efc7e1a692b3638257b4cdabb7 and final-cleanup-design.md/template/dryrun ready. MUST freshdryrun after finalpublication; archive+readback BEFORE deletion. Userauthorizedfinalalltaskcleanup includes3roots (/workspace/scratch/{4a65d70f0fe1,fd78534029f7,166b48a091b9}),62worktrees,32tmpitems + Go caches. Read helper requirements; copy samebytes to /tmp/DB-Go-01-final-cleanup.py; acceptance/stateexternal; successfulhelper deletesitsowncontrols andalltaskroots, outputsJSONreceipt stdout. Then useGitHubAPI directly to appendcleanupreceipttoopenPlan35, no merge; allfutureexec cwd=/tmp. Finalresponse only remote links because localfilesgone.

Already reclaimed:3old/tmp toolarchives;12/tmp diagnosticcache dirs;19workspacehistoricalobj dirs (observed+698560512B);17oldPGdata leaves (+~1.09GB), parentrawlogs/results/receipts retained. freebeforeformal2.13GB. Earlycleanupreceipts inroot.
Extra prior text evidence legacy-extra-evidence.tar.gz 10294557bytes SHA51b6fa864fc108c71365d5e356a0672453d1cf0df4def65df209ff362da15787,1538dedupobjects/9643paths/50076719rawbytes; readbackallpass, secretscan0alerts. Mustpublish/readbackthisextraarchive too before allcleanup. Canonicalpriorfinal archivealreadyinPlanmain (a2163d52...).

Agent go_contract_audit prepares historicalcomparison data viaremoteonly, thencanwakeafterlongforindependentGo raw audit. Agent go_environment completedreadiness+remoteCIchecks; no furtherlocalchecks duringtiming. Agent go_cleanup_inventory completedhelperandlegacyarchive. No agent permittedmerge.
