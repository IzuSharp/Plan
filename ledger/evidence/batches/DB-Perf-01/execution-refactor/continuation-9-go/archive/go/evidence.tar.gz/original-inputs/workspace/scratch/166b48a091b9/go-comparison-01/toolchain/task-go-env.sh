#!/usr/bin/env bash
# Task-local Go comparator inputs. Source this file; do not replace system tools.
export GOROOT=/workspace/scratch/166b48a091b9/go-comparison-01/toolchain/go
export GOPATH=/workspace/scratch/166b48a091b9/go-comparison-01/toolchain/gopath
export GOMODCACHE=/workspace/scratch/166b48a091b9/go-comparison-01/toolchain/modcache
export GOCACHE=/workspace/scratch/166b48a091b9/go-comparison-01/toolchain/buildcache
export GOTMPDIR=/workspace/scratch/166b48a091b9/go-comparison-01/toolchain/tmp
export GOTOOLCHAIN=local
export GOPROXY=https://proxy.golang.org
export GOSUMDB=sum.golang.org
export GOOS=linux
export GOARCH=amd64
export CGO_ENABLED=1
export CC=/usr/bin/gcc
export CGO_CFLAGS='-O2 -g -I/workspace/scratch/4a65d70f0fe1/tools/native-dependencies/sqlite/sqlite-amalgamation-3510300'
export CGO_LDFLAGS='-O2 -g -L/workspace/scratch/4a65d70f0fe1/consumers/direct-native -Wl,-rpath,/workspace/scratch/4a65d70f0fe1/consumers/direct-native'
export PATH="$GOROOT/bin:$PATH"

# Use `go build -tags libsqlite3` to select the already frozen SQLite 3.51.3 image.
# GOMAXPROCS and CPU affinity are selected by the frozen workload orchestration.
