#!/usr/bin/env python3
"""Preserve unmatched historical text bytes in a deduplicated local archive."""

import datetime
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import tarfile

ROOT = Path('/workspace/scratch/166b48a091b9/go-comparison-01')
AUDIT = ROOT / 'legacy-retention-audit.json'
ARCHIVE = ROOT / 'legacy-extra-evidence.tar.gz'
MANIFEST = ROOT / 'legacy-extra-evidence.manifest.json'
RECEIPT = ROOT / 'legacy-extra-evidence.receipt.json'
PATTERNS = {
    'github-access-token': re.compile(rb'(?:github_pat_[A-Za-z0-9_]{20,}|gh[pousr]_[A-Za-z0-9]{20,})'),
    'private-key': re.compile(rb'-----BEGIN (?:OPENSSH |RSA |EC |DSA )?PRIVATE KEY-----'),
    'bearer-authorization': re.compile(rb'Authorization\s*[:=]\s*[\"\x27]?Bearer\s+[A-Za-z0-9._-]{20,}', re.I),
}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def add_bytes(tar, name, data):
    info = tarfile.TarInfo(name)
    info.size = len(data)
    info.mode = 0o644
    info.uid = info.gid = info.mtime = 0
    tar.addfile(info, io.BytesIO(data))


def main():
    assert not ARCHIVE.exists() and not MANIFEST.exists() and not RECEIPT.exists(), 'Fresh artifact paths required'
    audit_bytes = AUDIT.read_bytes()
    audit = json.loads(audit_bytes)
    grouped = {}
    for row in audit['unmatched']:
        grouped.setdefault(row['sha256'], []).append(row)
    objects = []
    alerts = []
    for checksum, rows in sorted(grouped.items()):
        selected = Path(rows[0]['path'])
        raw = selected.read_bytes()
        assert len(raw) == rows[0]['bytes'] and sha(raw) == checksum, str(selected)
        for kind, pattern in PATTERNS.items():
            if pattern.search(raw):
                alerts.append({'path': str(selected), 'kind': kind})
        objects.append({'member': 'objects/' + checksum, 'sha256': checksum,
                        'bytes': len(raw), 'sourceSelected': str(selected),
                        'originalPaths': [row['path'] for row in rows]})
    if alerts:
        (ROOT / 'legacy-extra-potential-secret-alerts.json').write_text(json.dumps(alerts, indent=2) + '\n')
        raise RuntimeError('Potential secret patterns require review; no archive was created')
    manifest = {
        'schemaVersion': 1,
        'purpose': 'Supplemental retention before user-authorized final local cleanup; original historical text bytes only, no new performance conclusion',
        'auditObservedAtUtc': audit['observedAtUtc'],
        'auditSha256': sha(audit_bytes),
        'priorPlanMerge': audit['publishedPlanMerge'],
        'priorPlanTree': audit['publishedPlanTree'],
        'method': 'SHA-256 content-addressed objects deduplicate identical unmatched text files; original paths remain mapped. Unmatched means no exact byte match was proved in indexed Plan evidence, not that the content was never published elsewhere.',
        'objects': objects,
        'objectCount': len(objects),
        'originalPathCount': len(audit['unmatched']),
        'uniqueContentBytes': sum(item['bytes'] for item in objects),
        'binaryRecoveryClaim': False,
        'intentionallyOmitted': ['compiled binaries', 'package and compiler caches', 'database data files', 'tool installations'],
        'omissionIdentityNote': 'Existing final-freeze/build/input and cache-dedup receipts retain identities where recorded. This supplemental archive does not promise recovery of excluded binary/cache/database bytes.',
    }
    manifest_bytes = (json.dumps(manifest, indent=2) + '\n').encode()
    MANIFEST.write_bytes(manifest_bytes)
    with ARCHIVE.open('wb') as output:
        with gzip.GzipFile(filename='', fileobj=output, mode='wb', mtime=0, compresslevel=6) as compressed:
            with tarfile.open(fileobj=compressed, mode='w|') as tar:
                add_bytes(tar, 'manifest.json', manifest_bytes)
                for item in objects:
                    raw = Path(item['sourceSelected']).read_bytes()
                    assert sha(raw) == item['sha256'], item['sourceSelected']
                    add_bytes(tar, item['member'], raw)
    expected = {item['member']: item for item in objects}
    verified = 0
    with tarfile.open(ARCHIVE, 'r|gz') as tar:
        for member in tar:
            assert member.isfile()
            raw = tar.extractfile(member).read()
            if member.name == 'manifest.json':
                assert raw == manifest_bytes
            else:
                item = expected.pop(member.name)
                assert len(raw) == item['bytes'] and sha(raw) == item['sha256']
                verified += 1
    assert not expected and verified == len(objects)
    receipt = {
        'schemaVersion': 1,
        'completedAtUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'archive': str(ARCHIVE), 'archiveBytes': ARCHIVE.stat().st_size,
        'archiveSha256': sha(ARCHIVE.read_bytes()),
        'manifest': str(MANIFEST), 'manifestSha256': sha(manifest_bytes),
        'objectReadbackCount': verified, 'allObjectBytesVerified': True,
        'originalPathMappings': len(audit['unmatched']),
        'uniqueContentBytes': sum(item['bytes'] for item in objects),
        'potentialSecretPatternAlerts': 0,
        'binaryRecoveryClaim': False,
        'publicationStatus': 'local-prepared-only; root must publish and verify remote readback before final cleanup',
    }
    RECEIPT.write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt))


if __name__ == '__main__':
    main()
