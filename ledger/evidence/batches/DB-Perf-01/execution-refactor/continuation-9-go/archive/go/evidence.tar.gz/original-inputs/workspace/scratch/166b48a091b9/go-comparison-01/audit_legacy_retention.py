#!/usr/bin/env python3
"""Read-only legacy evidence retention audit; never deletes or extracts files."""

import collections
import datetime
import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tarfile

OUTPUT = Path('/workspace/scratch/166b48a091b9/go-comparison-01')
PLAN = Path('/workspace/scratch/fd78534029f7/worktrees/DB-Exec-10-plan')
OLD = Path('/workspace/scratch/4a65d70f0fe1')
MID = Path('/workspace/scratch/fd78534029f7')
LIMIT = 64 * 1024 * 1024
SKIP_DIRS = {
    '.git', 'bin', 'obj', 'packages', 'offline-feed', 'pgdata',
    'CMakeFiles', '_deps', '__pycache__', 'out', 'native-publish',
}
SUFFIXES = {
    '.log', '.json', '.md', '.txt', '.patch', '.csv', '.tsv',
    '.py', '.sh', '.cs', '.c', '.cpp', '.h', '.sql', '.csproj', '.props',
}


def digest(stream):
    value = hashlib.sha256()
    count = 0
    while chunk := stream.read(1024 * 1024):
        count += len(chunk)
        if count > LIMIT:
            raise ValueError('member exceeds bounded audit limit')
        value.update(chunk)
    return value.hexdigest(), count


def main():
    known = collections.defaultdict(list)
    omissions = []
    tracked = subprocess.check_output([
        'git', '-C', str(PLAN), 'ls-files', '-z',
        'ledger/evidence/batches/DB-Perf-01/',
    ]).split(b'\0')
    files = [PLAN / value.decode() for value in tracked if value]
    for path in files:
        rel = str(path.relative_to(PLAN))
        if not path.is_file() or path.is_symlink():
            continue
        if path.stat().st_size > LIMIT:
            omissions.append({'path': str(path), 'reason': 'stored object exceeds audit size bound'})
            continue
        with path.open('rb') as stream:
            sha, _ = digest(stream)
        known[sha].append(rel)
        if path.name.endswith('.tar.gz'):
            with tarfile.open(path, 'r|gz') as archive:
                for member in archive:
                    if not member.isfile():
                        continue
                    if member.size > LIMIT:
                        omissions.append({'path': rel + '!' + member.name, 'reason': 'archive member exceeds audit size bound'})
                        continue
                    with archive.extractfile(member) as stream:
                        sha, _ = digest(stream)
                    known[sha].append(rel + '!' + member.name)
        elif path.suffix == '.gz':
            try:
                with gzip.open(path, 'rb') as stream:
                    sha, _ = digest(stream)
                known[sha].append(rel + '!gunzipped')
            except (OSError, ValueError) as error:
                omissions.append({'path': rel, 'reason': str(error)})

    candidates = [
        OLD / 'artifacts', OLD / 'measurements', OLD / 'validation-evidence',
        OLD / 'consumers', MID / 'measurements', MID / 'verification',
        MID / 'native-review', MID / 'ci-review-17da-01', MID / 'builds',
        MID / 'selector-controls-01', MID / 'final-auditor-controls-01',
        MID / 'final-auditor-controls-02',
    ]
    for item in sorted(Path('/tmp').iterdir()):
        if item.name.startswith('DB-Exec-10-') and item.is_dir():
            candidates.append(item)

    retained = []
    unmatched = []
    skipped = []
    seen = set()
    for root in candidates:
        if not root.is_dir() or root.is_symlink():
            continue
        for current, dirs, names in os.walk(root, followlinks=False):
            dirs[:] = [name for name in dirs if name not in SKIP_DIRS
                       and not (Path(current) / name).is_symlink()]
            for name in names:
                path = Path(current) / name
                if path.is_symlink() or not path.is_file():
                    continue
                if path.suffix not in SUFFIXES and name not in {'stdout', 'stderr'}:
                    continue
                if path in seen:
                    continue
                seen.add(path)
                size = path.stat().st_size
                if size > LIMIT:
                    skipped.append({'path': str(path), 'bytes': size, 'reason': 'candidate exceeds bounded audit limit'})
                    continue
                with path.open('rb') as stream:
                    sha, count = digest(stream)
                row = {'path': str(path), 'bytes': count, 'sha256': sha}
                if sha in known:
                    row['publishedEvidenceMatch'] = known[sha][0]
                    retained.append(row)
                else:
                    row['disposition'] = 'not-proven-retained-by-byte-match'
                    unmatched.append(row)

    grouped = collections.defaultdict(list)
    for row in unmatched:
        grouped[row['sha256']].append(row)
    data = {
        'schemaVersion': 1,
        'observedAtUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'scope': 'Historical task experiment logs, reports, helper/source snapshots and build receipts; selected exact roots only. No deletion and no archive extraction to disk.',
        'publishedPlanLocalCommit': subprocess.check_output(['git', '-C', str(PLAN), 'rev-parse', 'HEAD'], text=True).strip(),
        'publishedPlanMerge': '03efe57ffbe3046bd89919ddb2c16c90a377954d',
        'publishedPlanTree': subprocess.check_output(['git', '-C', str(PLAN), 'rev-parse', 'HEAD^{tree}'], text=True).strip(),
        'comparisonMethod': 'SHA-256 of actual tracked Plan file bytes, gzip-decoded files and tar regular member bytes, never hashes merely mentioned in an exclusion manifest.',
        'publishedStoredFilesIndexed': len(files),
        'publishedUniqueContentHashesIndexed': len(known),
        'candidateRoots': [str(path) for path in candidates],
        'excludedDirectoryNames': sorted(SKIP_DIRS),
        'excludedClasses': ['database files/data directories', 'binary/package/compiler caches', 'compiled outputs', 'Git object databases'],
        'retainedCount': len(retained),
        'unmatchedCount': len(unmatched),
        'unmatchedBytesWithDuplicates': sum(row['bytes'] for row in unmatched),
        'unmatchedUniqueContentCount': len(grouped),
        'unmatchedUniqueContentBytes': sum(rows[0]['bytes'] for rows in grouped.values()),
        'retained': retained,
        'unmatched': unmatched,
        'auditLimitOmissions': omissions + skipped,
        'interpretation': 'An unmatched file may still be present in a differently normalized archive or a source repository. It is not proven lost or unpublished. Preserve useful unique log/source bytes in a supplemental archive or explicitly record their disposition before final cleanup. Rebuildable binary/cache bytes can be omitted with identity and a clear no-binary-recovery claim.',
    }
    target = OUTPUT / 'legacy-retention-audit.json'
    target.write_text(json.dumps(data, indent=2) + '\n')
    print(json.dumps({key: data[key] for key in [
        'retainedCount', 'unmatchedCount', 'unmatchedBytesWithDuplicates',
        'unmatchedUniqueContentCount', 'unmatchedUniqueContentBytes',
    ]} | {'path': str(target), 'auditLimitOmissions': len(data['auditLimitOmissions'])}))


if __name__ == '__main__':
    main()
