#!/usr/bin/env python3
"""Archive existing text evidence only. Never build, test, benchmark, or write Plan."""
import datetime
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile
import tempfile

ROOT = Path('/workspace/scratch/4a65d70f0fe1')
ARTIFACTS = ROOT / 'artifacts'
VALIDATION = ROOT / 'validation-evidence/close-ready-01'
NATIVE = ROOT / 'worktrees/DB-Exec-03-close-native'
REPO = ROOT / 'worktrees/DB-Exec-03-close-validation'
PUBLIC = 'bc6ba1ae0ece02ecc2c0860776605f3c838f3ff8'
TESTED = '4067d7675430f91d10a38f1b459210413c4e278d'
PRODUCER = 'ecbf00830b656e47f9f818dff6b76816f9e984d9'
NATIVE_DEV = '055ff32bd832065c2aaecd1b2c62b1f2a16d678e'
MANAGED_DEV = '0b5ea9474872649d72d3df9021db922712685864'
NAME = 'close-development-evidence-01'
SCOPE = ('Existing local development correctness/build evidence and later source publication parity. '
         'No archived test or build is relabelled as a public bc6ba1a execution; no public package, '
         'performance or four-segment stress acceptance is conferred.')

sha = lambda data: hashlib.sha256(data).hexdigest()
encoded = lambda value: (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode()
git = lambda *args: subprocess.check_output(['git', *args], cwd=REPO)
text = lambda *args: git(*args).decode().strip()
members = {}
sources = []


def add(path, archive_path, expected=None, kind='original'):
    path = Path(path)
    before = path.stat()
    data = path.read_bytes()
    after = path.stat()
    assert before.st_size == after.st_size == len(data), path
    assert before.st_mtime_ns == after.st_mtime_ns, path
    data.decode('utf-8')  # this archive deliberately contains text only
    if expected is not None:
        assert sha(data) == expected, (str(path), sha(data), expected)
    assert archive_path not in members
    assert not archive_path.startswith('/') and '..' not in Path(archive_path).parts
    members[archive_path] = data
    sources.append({
        'path': archive_path, 'origin': str(path), 'kind': kind,
        'bytes': len(data), 'sha256': sha(data),
        'observedOriginalMtimeNs': after.st_mtime_ns,
        'observedOriginalMtimeUtc': datetime.datetime.fromtimestamp(
            after.st_mtime, datetime.timezone.utc).isoformat(),
    })


def generated(name, data, explanation):
    members[name] = data
    sources.append({'path': name, 'origin': explanation, 'kind': 'derived-at-archive',
                    'bytes': len(data), 'sha256': sha(data)})


# All eighteen text inputs plus the exact original manifest that identifies them.
close_manifest = VALIDATION / 'archive-manifest.json'
assert sha(close_manifest.read_bytes()) == '80e4e0390289841ba8eb9c3ab3efa278611197851a8fec24c4ca7898172010c5'
close = json.loads(close_manifest.read_bytes())
assert len(close['files']) == 18
for item in close['files']:
    add(VALIDATION / item['path'], 'managed-aot/' + item['path'], item['sha256'])
add(close_manifest, 'managed-aot/archive-manifest.json')

# Use the explicitly saved CTest details snapshot, never LastTest.log.
native_receipt_path = NATIVE / 'artifacts/close-ready/development-receipt.json'
add(native_receipt_path, 'native-development/development-receipt.json',
    'e3ce2494ca9f2f57fbe2947b0cce5bfbd7b60e76dbcfffaa2a55ec631c9c8b85')
native_receipt = json.loads(native_receipt_path.read_bytes())
assert native_receipt['candidate'] == NATIVE_DEV
for item in native_receipt['logs']:
    assert 'LastTest.log' not in item['path']
    add(NATIVE / item['path'], 'native-development/' + Path(item['path']).name, item['sha256'])
for item in native_receipt['sourceFiles']:
    assert sha(git('show', NATIVE_DEV + ':' + item['path'])) == item['sha256'], item['path']

add(ARTIFACTS / 'close-managed-build-01.log', 'managed-library/build-01.log',
    'c54fd450b58e90f4716c8f7439ff38cce57c95f54f361e69e5ceb826bfad6838')
add(ARTIFACTS / 'close-managed-format-01.log', 'managed-library/format-01.log',
    'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855')
managed_note = {
    'kind': 'Retrospective provenance note, not an original execution receipt',
    'sourceCommit': MANAGED_DEV,
    'workingDirectory': str(ROOT / 'worktrees/DB-Exec-03-close-managed'),
    'reportedBy': 'ci_build_audit, original managed implementation/build owner',
    'originalOwnerConfirmsNoLaterBuildOrLogOverwrite': True,
    'reportedBuildCommand': ['dotnet', 'build', 'src/Data.NativeHost/Korda.Database.csproj',
                             '-c', 'Release', '-p:UseSharedCompilation=false',
                             '-p:RestoreLockedMode=true', '-m:1', '-nr:false'],
    'reportedEnvironmentCommand': 'source /workspace/scratch/4a65d70f0fe1/tools/task-env.sh',
    'buildLogResult': 'Build succeeded; 0 Warning(s); 0 Error(s); 24.37 seconds',
    'originalBuildExitCodeReceipt': None,
    'reportedOriginalToolBuildSucceeded': True,
    'formatDescription': 'dotnet format whitespace --folder, six changed files, --verify-no-changes',
    'originalFormatExitCodeReceipt': None,
    'reportedOriginalToolFormatExitCode': 0,
    'formatLogLimitation': 'Empty log retained exactly; emptiness alone does not establish an exit code.',
    'changedFiles': text('show', '--format=', '--name-only', MANAGED_DEV).splitlines(),
}
generated('managed-library/provenance-note.json', encoded(managed_note),
          'Archive-time record of original implementation agent message; raw logs unchanged')

for filename in ['close-publication-intent.json', 'close-publication-receipt.json']:
    add(ARTIFACTS / filename, 'publication/' + filename)
publication = json.loads((ARTIFACTS / 'close-publication-receipt.json').read_bytes())
assert publication['publicHead'] == PUBLIC
assert publication['tree'] == text('rev-parse', PUBLIC + '^{tree}') == '78e6c419a7e1ee2134a5c4aac86e5d5e21483eba'

for provider in ['sqlite', 'postgresql']:
    directory = ARTIFACTS / ('close-dev-native-' + provider)
    manifest = json.loads((directory / 'manifest.json').read_bytes())
    assert manifest['sourceCommit'] == PRODUCER and not manifest['sourceDirty']
    add(directory / 'manifest.json', 'dev-provider-' + provider + '/manifest.json')
    assert len(manifest['commands']) == 3
    for item in manifest['commands']:
        assert item['exitCode'] == 0
        add(item['path'], 'dev-provider-' + provider + '/logs/' + Path(item['path']).name, item['sha256'])

# Preserve the already-executed planner's stdout and plan files. Do not execute it here.
for filename in ['close-integrated-impact.log', 'close-ecbf008-plan.log', 'close-ecbf008-plan.json',
                 'close-tests-integrated-impact.log', 'close-final-impact.log', 'close-public-impact.log']:
    add(ARTIFACTS / filename, 'impact/' + filename)
plan_path = ROOT / 'worktrees/DB-Exec-02-continuation/artifacts/plan.json'
assert plan_path.read_bytes() == (ARTIFACTS / 'close-public-impact.log').read_bytes()
add(plan_path, 'impact/public-plan.json')
plan = json.loads(plan_path.read_bytes())

# Independent comparison of fetched public Git objects with the exact tested product.
commits = {}
for role, commit in [('publicCandidate', PUBLIC), ('managedAotTestSource', TESTED), ('nativeProducerSource', PRODUCER)]:
    commits[role] = {'commit': commit, 'tree': text('rev-parse', commit + '^{tree}'),
                     'srcTree': text('rev-parse', commit + ':src'),
                     'nativeTree': text('rev-parse', commit + ':native')}
assert len({v['srcTree'] for v in commits.values()}) == 1
assert len({v['nativeTree'] for v in commits.values()}) == 1
assert not git('diff', '--name-only', TESTED, PUBLIC, '--', 'src', 'native')
assert not git('diff', '--name-only', PRODUCER, PUBLIC, '--', 'src', 'native')
assert not git('diff', '--name-only', MANAGED_DEV, PUBLIC, '--', 'src')
assert not git('diff', '--name-only', NATIVE_DEV, PUBLIC, '--', 'native')
inventory = []
listing = git('ls-tree', '-r', '-l', '-z', PUBLIC, '--', 'src', 'native')
for line in listing.split(b'\0'):
    if not line:
        continue
    info, path = line.split(b'\t', 1)
    mode, kind, blob, size = info.decode().split()
    assert kind == 'blob'
    inventory.append({'path': path.decode(), 'mode': mode, 'gitBlob': blob, 'bytes': int(size)})
parity = {
    'scope': 'Source identity only; not a public candidate build/test/performance execution receipt',
    'method': 'Compare fetched immutable Git src/native tree objects and every tracked path/blob/mode; independent git diff checks',
    'commits': commits,
    'equal': True,
    'nativeDevelopmentCommitAlsoMatchesNativeTree': NATIVE_DEV,
    'managedDevelopmentCommitAlsoMatchesSrcTree': MANAGED_DEV,
    'trackedProductFiles': len(inventory),
    'trackedProductBytes': sum(item['bytes'] for item in inventory),
    'productInventory': inventory,
    'outsideComparedTreesChangedPaths': text('diff', '--name-only', TESTED, PUBLIC, '--',
                                             '.', ':(exclude)src', ':(exclude)native').splitlines(),
    'publicationReceiptSha256': sha((ARTIFACTS / 'close-publication-receipt.json').read_bytes()),
    'plannerSnapshot': {
        'commandReportedByRoot': 'python3 eng/ci/impact.py origin/main --output artifacts/plan.json',
        'publicPlanMatchesSavedStdoutBytes': True,
        'publicPlanSha256': sha(plan_path.read_bytes()),
        'buildScopes': plan['build_scopes'], 'packages': plan['packages'],
        'actions': plan['actions'], 'deep': plan['deep'],
        'note': 'Existing outputs preserved; no planner invocation, CI execution or build performed by this archive task.',
    },
}
generated('product-parity.json', encoded(parity), 'Independent archive-time immutable Git object comparison')
(ARTIFACTS / (NAME + '.product-parity.json')).write_bytes(encoded(parity))

readme = '''# Direct-close development evidence archive

This archive preserves the original local development evidence for native 055ff32,
managed 0b5ea94, the Native AOT test commit 4067d76, and native provider producer
ecbf008. Later source publication is recorded separately as public bc6ba1a.
Existing source identities, embedded timestamps, command receipts and every raw
log byte are unchanged. Source parity does not relabel earlier execution as a
public-candidate run and does not grant public package or performance acceptance.

Contents: all 18 close-ready-01 text inputs plus their original manifest; the
native development receipt and its six hash-bound logs (the saved test-03-details
snapshot, never a later CTest LastTest.log); managed build and empty format logs;
publication intent/receipt; both development native manifests and their three
command logs each; and the saved impact logs/plans. Derived provenance and
product-parity records are explicitly identified as archive-time analysis.

The complete NativeHost run has an original subprocess exitCode=0 receipt. The
preceding narrower close-only run has all expected PASS summaries but no retained
direct tool exit metadata; that limitation remains explicit. The managed-library
format log is empty and has no independent original exit-code receipt; the
original implementation agent reported tool exit0, recorded as attribution only.

SOURCE-MANIFEST.json retains each original absolute path, observed original file
mtime, size and SHA256. Archive metadata uses deterministic uid/gid/mtime0 with
regular mode0644 files and sorted names. MANIFEST.sha256 covers every other tar
member, including the source manifest. The external manifest records tar SHA256,
two-generation byte reproducibility and complete readback/extraction comparison.
Original file mtimes are observations, not inferred execution times.

No executable, shared library, bin/obj, restore cache, PostgreSQL data, credentials,
or private certificates are included. The archiver performs no build, test,
benchmark, planner execution, repository modification, or Plan update.
'''
generated('README.md', readme.encode(), 'Archive scope and recovery instructions')
add(__file__, 'assemble-archive.py', kind='archive-tool')

source_manifest = {'schemaVersion': 1, 'scope': SCOPE, 'sources': sorted(sources, key=lambda item: item['path'])}
members['SOURCE-MANIFEST.json'] = encoded(source_manifest)
members['MANIFEST.sha256'] = ''.join(f'{sha(data)}  {name}\n' for name, data in sorted(members.items())).encode()


def packed():
    output = io.BytesIO()
    with gzip.GzipFile(filename='', fileobj=output, mode='wb', mtime=0, compresslevel=9) as zipped:
        with tarfile.open(fileobj=zipped, mode='w', format=tarfile.USTAR_FORMAT) as tar:
            for name, data in sorted(members.items()):
                info = tarfile.TarInfo(name)
                info.size = len(data)
                info.uid = info.gid = info.mtime = 0
                info.mode = 0o644
                info.uname = info.gname = ''
                tar.addfile(info, io.BytesIO(data))
    return output.getvalue()


first = packed()
second = packed()
assert first == second
archive = ARTIFACTS / (NAME + '.tar.gz')
assert not archive.exists(), 'Refusing to overwrite an existing evidence archive'
archive.write_bytes(first)
assert archive.read_bytes() == first
with tempfile.TemporaryDirectory(prefix='close-evidence-readback-', dir=ARTIFACTS) as temporary:
    destination = Path(temporary)
    with tarfile.open(archive, 'r:gz') as tar:
        listed = tar.getmembers()
        assert len(listed) == len(members)
        assert {item.name for item in listed} == set(members)
        for item in listed:
            assert item.isfile() and item.uid == item.gid == item.mtime == 0 and item.mode == 0o644
            assert not item.uname and not item.gname
            data = tar.extractfile(item).read()
            assert data == members[item.name], item.name
            target = destination / item.name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
            assert target.read_bytes() == members[item.name], item.name
        for line in (destination / 'MANIFEST.sha256').read_text().splitlines():
            digest, name = line.split('  ', 1)
            assert sha((destination / name).read_bytes()) == digest, name
# Verify source files stayed unchanged through the whole snapshot/pack/readback.
for item in sources:
    if item['kind'] in ['original', 'archive-tool']:
        assert Path(item['origin']).read_bytes() == members[item['path']], item['origin']

external = {
    'schemaVersion': 1, 'scope': SCOPE,
    'archive': {'path': str(archive), 'bytes': len(first), 'sha256': sha(first)},
    'members': [{'path': name, 'bytes': len(data), 'sha256': sha(data)} for name, data in sorted(members.items())],
    'sourceManifestSha256': sha(members['SOURCE-MANIFEST.json']),
    'productParitySha256': sha(members['product-parity.json']),
    'originalInputCount': sum(item['kind'] == 'original' for item in sources),
    'archiveTimeDerivedInputCount': sum(item['kind'] != 'original' for item in sources),
    'verification': {
        'twoIndependentEncodingsByteIdentical': True,
        'archiveFileReadBackByteIdentical': True,
        'everyMemberReadBackByteCompared': True,
        'everyExtractedFileByteCompared': True,
        'everyManifestSha256Verified': True,
        'allOriginalsUnchangedAfterReadback': True,
        'temporaryExtractionRemoved': True,
        'memberCount': len(members), 'uncompressedMemberBytes': sum(map(len, members.values())),
    },
}
external_path = ARTIFACTS / (NAME + '.manifest.json')
external_path.write_bytes(encoded(external))
(ARTIFACTS / (NAME + '.README.md')).write_text(readme)
print(json.dumps({'archive': str(archive), 'sha256': sha(first), 'bytes': len(first),
                  'manifest': str(external_path), 'manifestSha256': sha(external_path.read_bytes()),
                  'productParitySha256': sha(members['product-parity.json']),
                  'originalInputCount': external['originalInputCount'],
                  'members': len(members), 'productFilesCompared': len(inventory)}))
