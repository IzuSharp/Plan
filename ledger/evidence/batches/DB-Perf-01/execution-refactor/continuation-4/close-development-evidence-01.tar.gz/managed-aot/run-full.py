#!/usr/bin/env python3
"""Run the existing full host consumer once; preserve command, exit and exact artifacts."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess

evidence = Path(__file__).resolve().parent
worktree = Path('/workspace/scratch/4a65d70f0fe1/worktrees/DB-Exec-03-close-validation')
executable = evidence / 'aot/Korda.Data.NativeHost.Tests'
command = ['python3', 'tests/Data.NativeHost/run.py', '--postgres-bin', os.environ['NW_POSTGRES_BIN'], '--output', str(evidence / 'full/providers'), '--', str(executable)]
output = evidence / 'full'
output.mkdir(exist_ok=True)
log = output / 'run.log'
if log.exists():
    raise SystemExit('Refusing to overwrite an existing full-suite attempt')
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
receipt = {
    'scope': 'development full NativeHost, same Native AOT ELF and independent provider assets as close-only',
    'command': command,
    'workingDirectory': str(worktree),
    'startedUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'scriptSha256': sha(__file__),
    'runnerSha256': sha(worktree / 'tests/Data.NativeHost/run.py'),
    'executableSha256Before': sha(executable),
    'buildReceiptSha256': sha(evidence / 'build-receipt.json'),
    'sourceHead': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=worktree, text=True).strip(),
    'sourceDirty': bool(subprocess.check_output(['git', 'status', '--porcelain'], cwd=worktree, text=True).strip()),
}
with log.open('w') as stream:
    result = subprocess.run(command, cwd=worktree, stdout=stream, stderr=subprocess.STDOUT)
receipt.update({
    'exitCode': result.returncode,
    'finishedUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'executableSha256After': sha(executable),
    'files': {str(p.relative_to(output)): sha(p) for p in sorted(output.rglob('*')) if p.is_file()},
})
(output / 'run-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'exitCode': result.returncode, 'receipt': str(output / 'run-receipt.json')}))
raise SystemExit(result.returncode)
