# Direct cursor close: development correctness

The Native AOT publish and full two-provider NativeHost run succeeded. This evidence belongs to test commit `4067d7675430f91d10a38f1b459210413c4e278d`, using independent provider assets built from `ecbf00830b656e47f9f818dff6b76816f9e984d9`. The validation checkout was clean. Its `src/` and `native/` trees match the producer source byte for byte. It is development correctness evidence, not frozen public package validation or performance evidence.

`input-receipt.json` records the exact publish command, source hashes and native producer identities. `build-receipt.json` records the successful publish and executable/native hashes. `full/run-receipt.json` records the actual subprocess exit code 0, start/end timestamps, command and raw log hashes. The executable SHA remained unchanged before and after that run.

The earlier close-only run has every expected PASS summary and normal PostgreSQL shutdown in its retained logs. Its direct tool exit metadata was not preserved; no exit code is inferred from those logs. The full run repeats the complete close-only matrix and additionally has the saved subprocess exit code 0.

## Observed coverage

| Scope | Observed result |
| --- | --- |
| Snapshot parser oracle | 5,942 inputs |
| Pull ABI/result ownership fixtures | 44 assertions |
| Close result/error ownership fixtures | 17 assertions |
| Normal fetch and EOF matrix | Rows 0, 1, 32, 64, 100 and 1,000 for each provider; 1,319 assertions per provider |
| Direct final close on the normal matrix | Exactly one request, ready, take and publication per query; zero generic operation retirements; one business SQL execution |
| Close lifecycle | 20 cases and 276 assertions per provider |
| Existing held mapper matrix | 32 cases; 246 assertions per provider |
| Existing permanently rejected fetch scheduler races | Eight cases across the two providers |
| Existing parent transaction controls | 12 cases; 34 assertions per provider |
| Existing B04 suite | 546 assertions, 90 separately observed generic retirements for its broader operations, final native counters 0 through 5 and 8 all zero |

The close lifecycle cases cover all 11 close fault boundaries; three local failures with a permanently refusing scheduler before a retry slot exists; held actual generation-zero ready and held request/setup; unknown native acceptance with a held late ready plus parent source close; temporary scheduler refusal after reservation; an explicitly rejected close request; and child cleanup after the parent source actually completed its close.

The explicit close rejection fixture replaces only the close-request function pointer with a definite rejection; its fallback runs against the real provider/channel. It does not claim to prove native source admission rejection. That native condition and native queue-failure paths belong to the separate native test evidence. The closed-parent managed case proves real coordinator/admission refusal can retain the successful cleanup contract. The temporarily refusing scheduler is explicitly allowed to resume; the test does not promise completion while a reserved scheduler refuses forever.

Owned success, malformed output, unexpected output on Pending/error, rich provider error, generation-zero error consumption, separate positive-generation fetch errors and failure after error transfer all retain their release/identity assertions. Every real close case joins source/session cleanup and immediately checks the seven native owner counters; those checks use no deferred wait or weakened zero predicate.

## Reproduction

From the exact test source checkout, use the publish command in `input-receipt.json` with the matching independent native assets. The successful full test used:

```sh
source /workspace/scratch/4a65d70f0fe1/tools/task-env.sh
python3 tests/Data.NativeHost/run.py \
  --postgres-bin "$NW_POSTGRES_BIN" \
  --output /workspace/scratch/4a65d70f0fe1/validation-evidence/close-ready-01/full/providers \
  -- /workspace/scratch/4a65d70f0fe1/validation-evidence/close-ready-01/aot/Korda.Data.NativeHost.Tests
```

For the narrower matrix, append `--cursor-close-only`. `run-full.py` is the exact wrapper used to save the full run receipt; it refuses to overwrite its first attempt. Use a new evidence directory for another attempt. The runner creates and removes its own isolated PostgreSQL cluster. No benchmark or CI configuration was changed.

`validation-summary.json` contains machine-readable matrix observations and scope boundaries. `archive-manifest.json` lists the text evidence to archive. The AOT executable and provider binaries remain available locally by their exact paths and hashes but are deliberately excluded from the evidence archive. PostgreSQL data directories, build output/cache trees, credentials and private certificates are excluded.

There were no product or test failures in this development attempt. Historical public0f assertions allowing final generic-close count 0 or 1, and its measured EOF timer delay, remain separate retained evidence. The stricter zero-generic assertion applies to the new direct-close source only.
