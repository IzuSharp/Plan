#!/usr/bin/env python3
"""Build once, then run the real-provider deferred-ready races and full NativeHost suite."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument('--source-commit', required=True)
args = parser.parse_args()
root = Path('/workspace/scratch/4a65d70f0fe1')
output = Path(__file__).resolve().parent
worktree = root / 'worktrees/DB-Exec-04-ready-defer-validation'
native = root / 'worktrees/DB-Exec-04-cancel-native'
native_commit = '7960d381f5c8c0c62c2fb12394e494d73df37c62'
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
stamp = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
git = lambda *arguments: subprocess.check_output(['git', *arguments], cwd=worktree, text=True).strip()
assert not (output / 'publish.log').exists(), 'Refusing to overwrite an earlier validation attempt'
assert git('rev-parse', 'HEAD') == args.source_commit
assert not git('status', '--porcelain')
assert git('rev-parse', 'HEAD^{tree}') == git('rev-parse', 'b53996819ac4c650dbd2c4bc36c991ca95c4a399^{tree}')
assert git('rev-parse', 'HEAD:native') == git('rev-parse', native_commit + ':native')
changed = git('diff', '--name-only', native_commit, 'HEAD').splitlines()
assert set(changed) == {'src/Data.NativeHost/HostPullController.cs', 'tests/Data.NativeHost/Program.cs', 'tests/Data.NativeHost/ReadySchedulingTests.cs'}, changed
expected_hashes = {
    'sqlite': '2102973012af4905a049225c35069e2192c5a214c83b6b44fc2582fbfbb1da8d',
    'postgresql': 'aaa0e3c10914034d23aec0a6faeed9b4de853637dc57e37a822d78cf0b44c66c',
}
assets = {}
for provider, expected in expected_hashes.items():
    library = native / 'artifacts/cmake/linux-x64-release' / ('libnw_database_' + provider + '.so')
    assert sha(library) == expected
    assets[provider] = {'path': str(library), 'sourceCommit': native_commit, 'sha256': expected, 'bytes': library.stat().st_size}
native_receipt = native / 'artifacts/cancel-queued/development-receipt.json'
assert sha(native_receipt) == 'b59670cc7aa27d625aea78e2867f37700465ede3ac6e424d5bfcaf66e15ca954'
shutil.copy2(native_receipt, output / 'native-development-receipt.json')
source_paths = git('ls-files', 'src', 'tests/Data.NativeHost').splitlines()
source_hashes = {name: sha(worktree / name) for name in source_paths if (worktree / name).is_file()}
(output / 'source-files.json').write_text(json.dumps(source_hashes, indent=2, sort_keys=True) + '\n')
(output / 'candidate.diff').write_bytes(subprocess.check_output(['git', 'diff', native_commit, 'HEAD'], cwd=worktree))
publish = ['dotnet', 'publish', 'tests/Data.NativeHost/Korda.Data.NativeHost.Tests.csproj',
           '-c', 'Release', '-r', 'linux-x64', '-p:PublishAot=true', '-p:RestoreLockedMode=true',
           '-p:IlcTreatWarningsAsErrors=true', '-p:UseSharedCompilation=false', '-m:1', '-nr:false',
           '-p:KordaSqliteAssetPath=' + assets['sqlite']['path'],
           '-p:KordaPostgresAssetPath=' + assets['postgresql']['path'], '-o', str(output / 'aot')]
receipt = {
    'scope': 'Development correctness for Request.finally deferred scheduling only. Not the abandoned ready-inline experiment and not a frozen public package or performance gate.',
    'sourceCommit': args.source_commit, 'sourceTree': git('rev-parse', 'HEAD^{tree}'), 'sourceDirty': False,
    'originalProductCommit': '0625004fd750fec2d6a2b3514a44826da9e98e3a',
    'originalTestCommit': 'b53996819ac4c650dbd2c4bc36c991ca95c4a399', 'sourceTreeEqualOriginalTestCommit': True,
    'nativeSourceCommit': native_commit, 'nativeTreeEqualProducer': True,
    'changedPathsAgainstNativeFix': changed, 'candidateDiffSha256': sha(output / 'candidate.diff'),
    'sourceFilesSha256': sha(output / 'source-files.json'), 'nativeAssets': assets,
    'nativeDevelopmentReceiptSha256': sha(native_receipt),
    'scriptSha256': sha(__file__), 'runnerSha256': sha(worktree / 'tests/Data.NativeHost/run.py'),
    'environmentScriptSha256': sha(root / 'tools/task-env.sh'),
    'startedUtc': stamp(), 'publishCommand': publish, 'workingDirectory': str(worktree),
    'publishOnlyEnvironment': {'DOTNET_PROCESSOR_COUNT': '1'},
}
(output / 'input-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
environment = os.environ.copy()
environment['DOTNET_PROCESSOR_COUNT'] = '1'
with (output / 'publish.log').open('w') as stream:
    built = subprocess.run(publish, cwd=worktree, env=environment, stdout=stream, stderr=subprocess.STDOUT)
receipt['publishExitCode'] = built.returncode
receipt['publishFinishedUtc'] = stamp()
receipt['publishLogSha256'] = sha(output / 'publish.log')
if built.returncode:
    (output / 'result.json').write_text(json.dumps(receipt, indent=2) + '\n')
    raise SystemExit(built.returncode)
executable = output / 'aot/Korda.Data.NativeHost.Tests'
assert executable.read_bytes()[:4] == b'\x7fELF'
receipt['executableSha256'] = sha(executable)
for provider, expected in expected_hashes.items():
    assert sha(output / 'aot/runtimes/linux-x64/native' / ('libnw_database_' + provider + '.so')) == expected
(output / 'build-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'publishExitCode': built.returncode, 'executableSha256': receipt['executableSha256']}), flush=True)
receipt['runs'] = []
for name, switches in [('targeted', ['--pull-ready-scheduling-only']), ('full', [])]:
    folder = output / name
    folder.mkdir()
    run = ['python3', 'tests/Data.NativeHost/run.py', '--postgres-bin', os.environ['NW_POSTGRES_BIN'],
           '--output', str(folder / 'providers'), '--', str(executable), *switches]
    run_receipt = {'scope': name, 'sourceCommit': args.source_commit, 'nativeSourceCommit': native_commit,
                   'command': run, 'workingDirectory': str(worktree), 'startedUtc': stamp(),
                   'executableSha256Before': sha(executable), 'nativeAssets': assets}
    with (folder / 'run.log').open('w') as stream:
        result = subprocess.run(run, cwd=worktree, stdout=stream, stderr=subprocess.STDOUT)
    run_receipt['runnerExitCode'] = result.returncode
    run_receipt['finishedUtc'] = stamp()
    run_receipt['executableSha256After'] = sha(executable)
    assert run_receipt['executableSha256After'] == receipt['executableSha256']
    assert all(sha(output / 'aot/runtimes/linux-x64/native' / ('libnw_database_' + p + '.so')) == h for p, h in expected_hashes.items())
    run_receipt['logs'] = {str(path.relative_to(folder)): sha(path) for path in sorted(folder.rglob('*.log'))}
    (folder / 'run-receipt.json').write_text(json.dumps(run_receipt, indent=2) + '\n')
    receipt['runs'].append(run_receipt)
    receipt['finishedUtc'] = stamp()
    receipt['allSourceFilesUnchangedDuringBuildAndRuns'] = all(sha(worktree / p) == value for p, value in source_hashes.items())
    assert receipt['allSourceFilesUnchangedDuringBuildAndRuns']
    (output / 'result.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({'scope': name, 'runnerExitCode': result.returncode, 'receipt': str(folder / 'run-receipt.json')}), flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
