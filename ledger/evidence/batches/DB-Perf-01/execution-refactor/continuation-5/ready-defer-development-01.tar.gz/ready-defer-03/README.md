# Request-only deferred-ready development validation

This validates the narrow change that omits the request-side scheduling offer while a healthy accepted pull is still waiting for native readiness. `OnReady` still signals the existing coordinator; processing and completion remain on its work item. It does not validate or reuse the abandoned inline-ready implementation (`bf97437`) or its unexecuted tests (`535fb00`). No benchmark or performance comparison was run here.

## Exact inputs

- Product change: `0625004fd750fec2d6a2b3514a44826da9e98e3a`, one file, eight additions and one deletion in `HostPullController.Request`.
- Final test source: `b53996819ac4c650dbd2c4bc36c991ca95c4a399` (after `27eccea` and the test-only layout access corrections `8158cc1` and `b539968`).
- Validation worktree head: `73abb4e856a9d312d5ad3c8418509a55b08de843`, whole tree `1b30d5ab5282cc09ae047bdd2eed03cc555dd4e5`, byte-identical to the original final test commit's tree.
- Native producer source: `7960d381f5c8c0c62c2fb12394e494d73df37c62`. The validation source has the same native tree. The native cancellation fix's original development receipt is copied unchanged.
- SQLite `.so` SHA-256: `2102973012af4905a049225c35069e2192c5a214c83b6b44fc2582fbfbb1da8d`.
- PostgreSQL `.so` SHA-256: `aaa0e3c10914034d23aec0a6faeed9b4de853637dc57e37a822d78cf0b44c66c`.
- Native AOT executable SHA-256 before and after both runs: `7ee7151a24d6144dfd76dd36fcc0627d5771f5e3ad9cb7ac5a07b94d537e2845`.
- All 281 tracked files under `src/` and `tests/Data.NativeHost/` remained unchanged during publishing and execution. `candidate.diff` preserves the complete three-file change against the native fix commit.

These are development assets and development test executions, not a frozen public package producer or published-candidate acceptance gate.

## Preserved failures and successful run

| Attempt | Actual exit | Observed result |
| --- | --- | --- |
| `ready-defer-01` | Publish 1; no test execution | Five fixture compile errors from directly referring to Data.Abstractions internal projection and wire types. Product libraries compiled. |
| `ready-defer-02` | Publish 1; no test execution | One remaining fixture compile error from `ResultField.Descriptor`. The existing typed layout factory and passing its expectation compiled successfully. |
| `ready-defer-03` | Publish 0; targeted runner 0; full runner 0 | Both real providers passed the new deterministic scheduling scenarios and the full existing NativeHost suite. |

The fixture now creates its real row layout through `TypedStream<Item>.CreateProjectionLayout` and materializes through `RowBatchLease`. It uses public `Codecs.Int64.Id` only for this fixed, unconfigured Int64 projection. Native `Source::register_codec` validates unconfigured codecs and returns their logical ID; configured codecs have a separate source-bound identity. No friend access, public product API, loader bypass or weakened test assertion was introduced by the fixture corrections.

## Targeted scenarios

Each provider passed four scenarios and 71 assertions in the targeted run. The same scenarios also passed as part of the full run.

1. Actual ready overlaps request setup. A scheduled work item cannot take or publish while setup still owns its control. Returning setup restores progress after the early work item has already returned.
2. Three deliberately late real ready notifications perform exactly three scheduler offers, executions, takes and publications. While each callback is held before forwarding, a healthy accepted request has zero additional scheduler offers. The next generation can consume its real row while the previous native callback-return tail remains held; business order and the stable batch owner are checked.
3. A cancelable request retains its root, slot and undrained registration while ready scheduling is rejected. At least two rejected offers are observed, then the existing coordinator retry progresses after scheduling becomes available.
4. A test synchronization context queues the actual continuation and holds the original completion setter's `Post` return. This keeps the real old `CoordinatedCallback.Execute` stack active while the consumer releases its batch and requests the next generation. New readiness remains dirty, then is rescheduled exactly once when the old tail returns. The user continuation is checked to be outside the unmanaged ready callback stack.

The proxy forwards the actual provider request and ready callback; it does not generate rows or choose a different product drain path. Every scenario ends with native counters 0–5 and 8 at zero.

## Existing full-suite coverage retained

- Snapshot parser: 5,942 oracle inputs; pull result record: 44 assertions; close record: 17 assertions.
- Stable owner reuse, one-shot ValueTasks, stale generation rejection and held-reader admission for both providers.
- Held mapper: 16 scenarios and 246 assertions per provider, including dispose, cancellation, source/session close and mapper failures with unknown/known EOF.
- Original rejected pre-reservation scheduling: all eight two-provider cases passed, including successful stop and injected stop failure; original exception identity and zero native owners remain asserted.
- Public fetch matrix: rows 0, 1, 32, 64, 100 and 1,000, with 1,319 assertions per provider. Each query executes SQL once, performs one direct final close request/ready/take/publication, and uses zero generic retired operations on the normal fetch/close path.
- Parent transaction controls: 34 assertions per provider.
- Existing cursor close lifecycle: 276 assertions per provider, including setup/callback drains, rejected scheduling, cold fallback and zero native owners.
- Original main B04 suite: 546 assertions, 90 separately observed managed retirements for its broader operations, and final source/session/operation/cursor/buffer/handle/pull counters all zero.

These groups have separate counters; the main B04 count is not presented as the total of all fixtures.

## Reproduction and evidence

`run-validation.py` contains the executed AOT publish and both real-provider runner commands. It checks the clean source identity, exact native tree and binary hashes, and records every subprocess exit. `targeted/run-receipt.json` and `full/run-receipt.json` bind the original commands, timestamps, executable hashes and raw logs. Each runner creates and removes its own isolated PostgreSQL cluster. The original two compilation failures remain in their separate attempt directories.
