#!/usr/bin/env python3
"""Archive the isolated buffered row-scope correctness evidence without binaries."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile
import tempfile

root = Path('/workspace/scratch/4a65d70f0fe1')
target = root / 'artifacts/row-scope-development-01.tar.gz'
manifest_path = root / 'artifacts/row-scope-development-01.manifest.json'
assert not target.exists(), 'Refusing to overwrite an existing archive'
sha = lambda data: hashlib.sha256(data).hexdigest()
payloads = {}
entries = []
for attempt in ['row-scope-01']:
    folder = root / 'validation-evidence' / attempt
    for file in sorted(folder.rglob('*')):
        relative = file.relative_to(folder)
        if not file.is_file() or {'aot', 'streaming-aot', 'nativehost-aot'}.intersection(relative.parts):
            continue
        assert not file.is_symlink()
        name = attempt + '/' + str(relative)
        data = file.read_bytes()
        payloads[name] = data
        entries.append({'path': name, 'sourcePath': str(file), 'bytes': len(data),
                        'sha256': sha(data), 'sourceMtimeNs': file.stat().st_mtime_ns})
script_data = Path(__file__).read_bytes()
payloads['assemble-row-scope-development-01.py'] = script_data
entries.append({'path': 'assemble-row-scope-development-01.py', 'sourcePath': str(Path(__file__).resolve()),
                'bytes': len(script_data), 'sha256': sha(script_data), 'sourceMtimeNs': Path(__file__).stat().st_mtime_ns})
entries.sort(key=lambda entry: entry['path'])
internal = {'scope': 'Isolated buffered row-scope candidate: preserved source diff, native fixture receipt, Streaming and NativeHost AOT correctness, metadata and impact-plan evidence. No performance or public package credit. No binary, build output, restore cache or PostgreSQL data included.',
            'managedSourceCommit': 'f09631bcd3dbd8985a217e8b9b67532e798cfac3',
            'baseCommit': '69b398273eebc5f77b13b9a0ba7d6746b56aa878',
            'productCommit': 'ce9e349217684eb83d8a38cca27021cd6224087b',
            'sourceTree': '2bbc7213a3f5ccce0c48f5ec71157b88498d5568',
            'nativeFixCommit': '7960d381f5c8c0c62c2fb12394e494d73df37c62',
            'files': entries}
payloads['manifest.json'] = (json.dumps(internal, indent=2, sort_keys=True) + '\n').encode()
payloads['SHA256SUMS'] = ''.join(entry['sha256'] + '  ' + entry['path'] + '\n' for entry in entries).encode()

def encode():
    raw = io.BytesIO()
    with tarfile.open(fileobj=raw, mode='w', format=tarfile.USTAR_FORMAT) as archive:
        for name, data in sorted(payloads.items()):
            info = tarfile.TarInfo(name)
            info.size = len(data)
            info.mode = 0o644
            info.mtime = info.uid = info.gid = 0
            info.uname = info.gname = ''
            archive.addfile(info, io.BytesIO(data))
    return gzip.compress(raw.getvalue(), compresslevel=9, mtime=0)

encoded = encode()
assert encoded == encode(), 'Archive is not byte reproducible'
target.write_bytes(encoded)
with tempfile.TemporaryDirectory(prefix='row-scope-evidence-readback-') as temporary:
    extracted = Path(temporary)
    with tarfile.open(target, 'r:gz') as archive:
        assert set(archive.getnames()) == set(payloads)
        for member in archive.getmembers():
            assert member.isfile()
            readback = archive.extractfile(member).read()
            assert readback == payloads[member.name]
            out = extracted / member.name
            out.parent.mkdir(parents=True, exist_ok=True)
            out.write_bytes(readback)
    for name, data in payloads.items():
        assert (extracted / name).read_bytes() == data
    for entry in entries:
        assert sha((extracted / entry['path']).read_bytes()) == entry['sha256']
        assert Path(entry['sourcePath']).read_bytes() == payloads[entry['path']]
result = dict(internal)
result.update({'archivePath': str(target), 'archiveBytes': len(encoded), 'archiveSha256': sha(encoded),
               'originalFileCount': len(entries) - 1, 'memberCount': len(payloads),
               'deterministicSecondEncodingByteEqual': True, 'everyMemberAndExtractedByteCompared': True,
               'allOriginalFilesStillUnchanged': True})
manifest_path.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps({'archive': str(target), 'bytes': len(encoded), 'sha256': sha(encoded),
                  'manifest': str(manifest_path), 'manifestSha256': sha(manifest_path.read_bytes()),
                  'originalFileCount': result['originalFileCount'], 'memberCount': len(payloads), 'readback': True}))
