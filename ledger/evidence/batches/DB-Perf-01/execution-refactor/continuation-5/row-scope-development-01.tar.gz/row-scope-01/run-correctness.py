#!/usr/bin/env python3
"""Build and run the existing Native AOT Streaming and NativeHost correctness programs."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path('/workspace/scratch/4a65d70f0fe1')
output = Path(__file__).resolve().parent
worktree = root / 'worktrees/DB-Exec-05-row-scope'
native = root / 'worktrees/DB-Exec-04-cancel-native'
expected_source = 'f09631bcd3dbd8985a217e8b9b67532e798cfac3'
base_source = '69b398273eebc5f77b13b9a0ba7d6746b56aa878'
native_source = '7960d381f5c8c0c62c2fb12394e494d73df37c62'
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
stamp = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
git = lambda *args: subprocess.check_output(['git', *args], cwd=worktree, text=True).strip()
assert not (output / 'result.json').exists(), 'Refusing to overwrite a prior correctness attempt'
assert git('rev-parse', 'HEAD') == expected_source
assert not git('status', '--porcelain')
assert git('rev-parse', 'HEAD:native') == git('rev-parse', native_source + ':native')
changed = git('diff', '--name-only', base_source, 'HEAD').splitlines()
assert set(changed) == {'src/Data.Streaming/StreamTransport.cs', 'src/Data.Streaming/TypedStream.cs',
                        'tests/Data.Streaming/BorrowedBatchFixture.cs', 'tests/Data.Streaming/RowLeaseReuseChecks.cs',
                        'tests/Data.NativeHost/BorrowedBatchHostTests.cs'}
source_files = {name: sha(worktree / name) for name in git('ls-files', 'src', 'tests/Data.Streaming', 'tests/Data.NativeHost').splitlines()
                if (worktree / name).is_file()}
(output / 'source-files.json').write_text(json.dumps(source_files, indent=2, sort_keys=True) + '\n')
(output / 'candidate.diff').write_bytes(subprocess.check_output(['git', 'diff', base_source, 'HEAD'], cwd=worktree))
fixture_receipt = json.loads((output / 'native-fixture-receipt.json').read_text())
assert fixture_receipt['exitCode'] == 0 and fixture_receipt['sourceCommit'] == native_source
fixture = fixture_receipt['fixture']
assert sha(fixture['path']) == fixture['sha256']
expected_assets = {'sqlite': '2102973012af4905a049225c35069e2192c5a214c83b6b44fc2582fbfbb1da8d',
                   'postgresql': 'aaa0e3c10914034d23aec0a6faeed9b4de853637dc57e37a822d78cf0b44c66c'}
assets = {}
for provider, expected in expected_assets.items():
    path = native / 'artifacts/cmake/linux-x64-release' / ('libnw_database_' + provider + '.so')
    assert sha(path) == expected
    assets[provider] = {'path': str(path), 'sha256': expected, 'bytes': path.stat().st_size, 'sourceCommit': native_source}
receipt = {'scope': 'Isolated buffered row-scope correctness candidate, not selected for performance or frozen public package acceptance.',
           'sourceCommit': expected_source, 'sourceTree': git('rev-parse', 'HEAD^{tree}'), 'sourceDirty': False,
           'baseCommit': base_source, 'nativeSourceCommit': native_source, 'nativeTreeEqualProducer': True,
           'changedPaths': changed, 'sourceFilesSha256': sha(output / 'source-files.json'),
           'candidateDiffSha256': sha(output / 'candidate.diff'), 'scriptSha256': sha(__file__),
           'streamingEntrySha256': sha(output / 'streaming-entry.py'),
           'runnerSha256': sha(worktree / 'tests/Data.NativeHost/run.py'),
           'environmentScriptSha256': sha(root / 'tools/task-env.sh'), 'startedUtc': stamp(),
           'nativeAssets': assets, 'streamingFixture': fixture,
           'nativeFixtureReceiptSha256': sha(output / 'native-fixture-receipt.json'),
           'publishOnlyEnvironment': {'DOTNET_PROCESSOR_COUNT': '1'}, 'commands': []}
(output / 'input-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')

def run(label, command, environment=None):
    log = output / (label + '.log')
    assert not log.exists()
    record = {'label': label, 'command': command, 'workingDirectory': str(worktree), 'startedUtc': stamp()}
    with log.open('w') as stream:
        result = subprocess.run(command, cwd=worktree, env=environment, stdout=stream, stderr=subprocess.STDOUT)
    record.update({'exitCode': result.returncode, 'finishedUtc': stamp(), 'log': log.name, 'logSha256': sha(log)})
    receipt['commands'].append(record)
    receipt['finishedUtc'] = stamp()
    (output / 'result.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(record), flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)

build_environment = os.environ.copy()
build_environment['DOTNET_PROCESSOR_COUNT'] = '1'
for scope, project, assembly in [('streaming', 'tests/Data.Streaming/Korda.Data.Streaming.Tests.csproj', 'Korda.Data.Streaming.Tests'),
                                  ('nativehost', 'tests/Data.NativeHost/Korda.Data.NativeHost.Tests.csproj', 'Korda.Data.NativeHost.Tests')]:
    published = output / (scope + '-aot')
    publish = ['dotnet', 'publish', project, '-c', 'Release', '-r', 'linux-x64',
               '-p:PublishAot=true', '-p:RestoreLockedMode=true', '-p:IlcTreatWarningsAsErrors=true',
               '-p:UseSharedCompilation=false', '-m:1', '-nr:false', '-o', str(published)]
    if scope == 'nativehost':
        publish.extend(['-p:KordaSqliteAssetPath=' + assets['sqlite']['path'],
                        '-p:KordaPostgresAssetPath=' + assets['postgresql']['path']])
    run(scope + '-publish', publish, build_environment)
    executable = published / assembly
    assert executable.read_bytes()[:4] == b'\x7fELF'
    binary_hash = sha(executable)
    receipt[scope + 'ExecutableSha256Before'] = binary_hash
    arguments = [str(executable)]
    environment = os.environ.copy()
    if scope == 'streaming':
        environment['LD_LIBRARY_PATH'] = str(Path(fixture['path']).parent) + (':' + environment['LD_LIBRARY_PATH'] if environment.get('LD_LIBRARY_PATH') else '')
        arguments = ['python3', str(output / 'streaming-entry.py'), str(executable), str(output / 'streaming-results'), '--require-aot', '--correctness-only']
        receipt['streamingRunEnvironment'] = {'LD_LIBRARY_PATH': environment['LD_LIBRARY_PATH'],
                                               'KORDA_TEST_POSTGRES_URL': 'inherited from the existing runner NW_TEST_POSTGRES URL by the archived entry adapter'}
    else:
        for provider, expected in expected_assets.items():
            assert sha(published / 'runtimes/linux-x64/native' / ('libnw_database_' + provider + '.so')) == expected
    command = ['python3', 'tests/Data.NativeHost/run.py', '--postgres-bin', os.environ['NW_POSTGRES_BIN'],
               '--output', str(output / (scope + '-providers')), '--', *arguments]
    run(scope + '-correctness', command, environment)
    receipt[scope + 'ExecutableSha256After'] = sha(executable)
    assert receipt[scope + 'ExecutableSha256After'] == binary_hash
    assert sha(fixture['path']) == fixture['sha256']
    assert all(sha(asset['path']) == asset['sha256'] for asset in assets.values())
    receipt['allSourceFilesUnchangedDuringBuildAndRun'] = all(sha(worktree / name) == value for name, value in source_files.items())
    assert receipt['allSourceFilesUnchangedDuringBuildAndRun']
    (output / 'result.json').write_text(json.dumps(receipt, indent=2) + '\n')
receipt['allLogs'] = {str(path.relative_to(output)): sha(path) for path in sorted(output.rglob('*.log'))}
(output / 'result.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'allCommandsExitZero': True, 'receipt': str(output / 'result.json')}), flush=True)
