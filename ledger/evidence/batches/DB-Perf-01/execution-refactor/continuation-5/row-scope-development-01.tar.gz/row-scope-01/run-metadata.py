#!/usr/bin/env python3
"""Run the existing compiled-metadata API tool and verify the changed-file whitespace."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path('/workspace/scratch/4a65d70f0fe1')
worktree = root / 'worktrees/DB-Exec-05-row-scope'
output = Path(__file__).resolve().parent
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
stamp = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=worktree, text=True).strip() == 'f09631bcd3dbd8985a217e8b9b67532e798cfac3'
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=worktree, text=True).strip()
environment = os.environ.copy()
environment['DOTNET_PROCESSOR_COUNT'] = '1'
commands = [
    ('api-tool-build', ['dotnet', 'build', 'tests/Data.Streaming/ApiCheck/ApiCheck.csproj', '-c', 'Release', '-p:RestoreLockedMode=true', '-p:UseSharedCompilation=false', '-m:1', '-nr:false']),
    ('compiled-api', ['dotnet', 'tests/Data.Streaming/ApiCheck/bin/Release/net11.0/Korda.Data.Streaming.ApiCheck.dll', 'src/Data.Streaming/bin/Release/net11.0/Korda.Data.Streaming.dll', 'src/Data.Streaming/bin/Release/net11.0/Korda.Data.Streaming.xml', 'src/Data.Streaming/api-reference.md']),
    ('format-verify', ['dotnet', 'format', 'whitespace', '.', '--folder', '--include', 'src/Data.Streaming/StreamTransport.cs', 'src/Data.Streaming/TypedStream.cs', 'tests/Data.Streaming/BorrowedBatchFixture.cs', 'tests/Data.Streaming/RowLeaseReuseChecks.cs', 'tests/Data.NativeHost/BorrowedBatchHostTests.cs', '--verify-no-changes', '--verbosity', 'quiet']),
    ('diff-check', ['git', 'diff', '--check', '69b398273eebc5f77b13b9a0ba7d6746b56aa878', 'HEAD']),
]
receipt = {'scope': 'Existing PE-metadata inspection tool and source formatting; no managed JIT business consumer, benchmark or performance gate.',
           'sourceCommit': 'f09631bcd3dbd8985a217e8b9b67532e798cfac3', 'scriptSha256': sha(__file__),
           'apiToolSourceSha256': sha(worktree / 'tests/Data.Streaming/ApiCheck/Program.cs'), 'commands': []}
for label, command in commands:
    log = output / (label + '.log')
    assert not log.exists()
    started = stamp()
    with log.open('w') as stream:
        result = subprocess.run(command, cwd=worktree, env=environment, stdout=stream, stderr=subprocess.STDOUT)
    receipt['commands'].append({'label': label, 'command': command, 'workingDirectory': str(worktree), 'startedUtc': started,
                                'finishedUtc': stamp(), 'exitCode': result.returncode, 'log': log.name, 'logSha256': sha(log)})
    (output / 'metadata-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt['commands'][-1]), flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
receipt['artifacts'] = {path: sha(worktree / path) for path in ['tests/Data.Streaming/ApiCheck/bin/Release/net11.0/Korda.Data.Streaming.ApiCheck.dll',
    'src/Data.Streaming/bin/Release/net11.0/Korda.Data.Streaming.dll', 'src/Data.Streaming/bin/Release/net11.0/Korda.Data.Streaming.xml']}
(output / 'metadata-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
