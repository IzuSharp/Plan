#!/usr/bin/env python3
"""Adapt only the retained streaming fixture's PostgreSQL environment name."""
import os
import sys

os.environ['KORDA_TEST_POSTGRES_URL'] = os.environ['NW_TEST_POSTGRES']
os.execv(sys.argv[1], sys.argv[1:])
