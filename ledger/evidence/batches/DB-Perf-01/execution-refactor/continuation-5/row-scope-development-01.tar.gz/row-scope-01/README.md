# Buffered row admission and mapping: isolated scope candidate

The candidate is correctness-verified and ready for a separate A/B measurement. No timing, CPU, throughput or allocation window was run here. Reducing two read scopes to one is a source-level fact, not a measured performance benefit.

## Identity and scope

- Baseline: `69b398273eebc5f77b13b9a0ba7d6746b56aa878`.
- Product commit: `ce9e349217684eb83d8a38cca27021cd6224087b`.
- Test commit and tested head: `f09631bcd3dbd8985a217e8b9b67532e798cfac3`.
- Tested tree: `2bbc7213a3f5ccce0c48f5ec71157b88498d5568`.
- Product changes: only `src/Data.Streaming/StreamTransport.cs` and `src/Data.Streaming/TypedStream.cs`, 27 additions and 19 deletions.
- Test changes: reuse existing fixtures in `tests/Data.Streaming/BorrowedBatchFixture.cs`, `tests/Data.Streaming/RowLeaseReuseChecks.cs` and `tests/Data.NativeHost/BorrowedBatchHostTests.cs`.

No public API, friend assembly, native ABI, provider implementation, ready controller, close controller or CI rule changed. The separate unused-RetiredValueTask cleanup being developed concurrently is not part of this tested tree and receives no credit from this evidence.

## Actual path and preservation argument

Before the change, the buffered `TypedStream.Enumerator.MoveAsync` called `RowBatchLease.RowBytes(row)` and then `Materialize(row)`. Each method called `BeginRead`, acquired its own generation-specific `ScopedBatchRead`, and finally disposed that scope and called `EndRead`.

The buffered path now calls the internal synchronous `MaterializeBuffered` once. Its sequence is:

1. `BeginRead` acquires the current validated layout and the exact native generation, and increments the existing row-lease reader count.
2. The private byte helper performs the original checked sum: one `WireSchema.CellBytes` charge per field, plus each cell's actual payload length. NULL contributes no payload bytes.
3. The original row and charged-byte limits are checked, with the original error kind and message. Rejection happens before the mapper and before any row or byte counters advance.
4. The existing buffered-row and buffered-byte counters advance, followed by the row index. They are passed by reference, preserving the previous order even if later projection validation or the mapper throws.
5. The shared private materialization body performs the same row bounds check, exact projection/layout cache check, and `Projection.ReadBatch` call over the already-held span.
6. The existing `finally` disposes the native read scope and calls `EndRead` on success and failure.

The per-batch header and descriptor charge remains at its original position after successful batch attachment, including the existing empty-EOF handling. Complete wire and scalar validation still occurs during `RowBatchLease.Attach`. No token check, close check, fetch, read-admission check, mapper invocation or cleanup block moved across an asynchronous boundary. The native span remains synchronous and never crosses an `await`.

`Projection.ReadBatch` still checks `IRowLifetime.AssertAlive` before invoking the mapper. Each subsequent `RowReader` access still checks that lifetime. If the mapper calls `RowBatchLease.Dispose`, new logical reads fail immediately, while the active `ScopedBatchRead` keeps native storage alive until the mapper returns or throws. Attachment still rejects `_readers != 0`; public enumerator disposal still waits for its active move before disposing the row lease. Source/session shutdown remains independent of an already-held result buffer.

The unbuffered `Materialize` path retains its own single scope and uses the same private materialization body. The separate `RowBytes(uint)` product entry was deleted after its only production caller was replaced. Its two existing test usages were migrated to assert the real buffered method's charges and retired-lease rejection. The byte summation helper remains private and is called by the new production path. Historical reproduction snapshots were preserved.

The hot success path introduces no new object construction, per-row delegate, boxing or intermediate serialized representation. This statement follows the source; it does not substitute for the requested allocation measurement.

## Validation actually performed

All four publish/run commands in `result.json` exited 0:

| Gate | Result |
| --- | --- |
| Streaming Release Native AOT publish | Exit 0, warnings treated as errors |
| Original Streaming real-provider correctness program | Exit 0, SQLite and isolated PostgreSQL; B06 615 assertions and 60 cases; `jit=False`; native fixture bytes and wrappers zero |
| NativeHost Release Native AOT publish | Exit 0, warnings treated as errors |
| Original NativeHost program with the reused buffered matrix | Exit 0, both actual providers; all source/session/operation/cursor/buffer/handle/pull counters zero |

Streaming also reported borrowed lifetime/validation 19 assertions, lazy join races 118, scoped batch correctness 276, stable owner 30, and row-lease reuse 364. These are separate fixture counters, not additional rows in the B06 main count. The original per-provider budget tests still observe five mapper calls before the row cap, one before the byte cap, and zero for an oversized row rejected before its constructor.

The row-lease validated-layout tests now exercise both buffered and unbuffered materialization. They preserve wrong-codec, out-of-range ordinal, foreign token, foreign projection, nullable/equivalent codec and mapper self-disposal assertions. The self-disposal case additionally observes that the native release count remains zero inside the mapper after logical disposal, then reaches one when its full read scope exits.

The existing real-provider held-mapper fixture remains unchanged in meaning for its original 16 streaming cases and 246 assertions per provider. The same fixture also calls the public `DataSession.QueryAsync` buffered entrance for cancellation, source close and session close, each with mapper success/failure and unknown/known EOF: 12 additional cases and 170 assertions per provider. It checks real native buffer retention while controls finish, exact cancellation-token identity, source-closed versus session-invalid-state classification, preservation of the original mapper exception, and owned string/byte/typed-JSON values after all native owners retire.

The full NativeHost run also preserves the original normal public fetch matrix (1,319 assertions/provider, one SQL execution and zero generic retired operations per normal query), cursor-close lifecycle (276/provider), deferred-ready scenarios (4 cases and 71 assertions/provider), and original main B04 checks (546 assertions and 90 separately observed retirements).

The existing compiled PE-metadata API tool reported zero public symbols and matching XML/reference. Its build, API inspection, changed-file whitespace verification and `git diff --check` all have actual exit 0 recorded in `metadata-receipt.json`. It is a metadata inspection tool; no JIT business consumer was executed.

Both independent peer reviews found no lifetime blocker in this fixed product diff. Their reviews focused on counter ordering, synchronous span retention, `AssertAlive`, attachment exclusion and the active-move disposal boundary; they did not run additional builds or measurements.

## Native and executable provenance

The C++ source tree equals native fix `7960d381f5c8c0c62c2fb12394e494d73df37c62`.

- SQLite production `.so`: `2102973012af4905a049225c35069e2192c5a214c83b6b44fc2582fbfbb1da8d`.
- PostgreSQL production `.so`: `aaa0e3c10914034d23aec0a6faeed9b4de853637dc57e37a822d78cf0b44c66c`.
- Retained Streaming maintainer fixture: `6341142d286ae53533e320504d6e08134cf9c5feff574a6ebccc8d872c1d13d3`, built as the single additional `korda_streaming_fixture` target from the existing 7960 tree. Both production `.so` hashes remained unchanged across this build.
- Streaming AOT executable before/after: `7ea87a5e6651f3f171fb281b03e99ae6aca4842d4ee3d6483e58c912c3886bbc`.
- NativeHost AOT executable before/after: `6a0634e2923be97a8a5ce7d4d4e097a6820876936f4f13843bd60bdb527a0ecc`.

These are development assets, not new frozen public-package producer evidence. All recorded source files and native assets remained unchanged throughout the correctness runs. Each program used its own temporary PostgreSQL cluster, which the existing runner stopped and removed.

## CI plan and reproduction

The exact requested command `python3 eng/ci/impact.py origin/main --output artifacts/plan.json` completed with exit 0. `impact-plan.json` is its full output. The local changes map to `database`, `streaming-tests` and `data-nativehost-tests`. The complete PR diff still selects the existing interop, Linux, PostgreSQL and SQLite scopes. `database.regressions` explicitly includes the same Streaming and NativeHost correctness programs, so `database_plan.py` removes their redundant standalone actions. Each provider retains its independent package/build/test actions. No benchmark or performance action is selected.

`run-correctness.py`, `streaming-entry.py` and `run-metadata.py` preserve the actual commands. The small streaming entry adapter only maps the existing runner's `NW_TEST_POSTGRES` URL to the retained fixture's `KORDA_TEST_POSTGRES_URL` name. `candidate.diff` contains all five changed files against the stated baseline. The scripts refuse to overwrite earlier attempt logs. No failed build or test occurred in this candidate attempt.

Selection remains pending the root agent's isolated A/B window. No additional optimization or measurement is implied by these passes.
