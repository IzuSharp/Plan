#!/usr/bin/env python3
"""Deterministic archive of original command-cleanup failures and corrected native gates."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile
import tempfile

ROOT = Path('/workspace/scratch/4a65d70f0fe1')
SOURCE = ROOT / 'worktrees/DB-Exec-06-primary-error/artifacts/primary-error'
TARGET = ROOT / 'artifacts/primary-error-development-01.tar.gz'
MANIFEST = ROOT / 'artifacts/primary-error-development-01.manifest.json'
assert not TARGET.exists() and not MANIFEST.exists(), 'Earlier archives are immutable'
sha = lambda data: hashlib.sha256(data).hexdigest()
payloads, entries = {}, []

for file in sorted(SOURCE.rglob('*')):
    if not file.is_file() or file.name == 'nw_host_review_tests.original':
        continue
    assert not file.is_symlink()
    data = file.read_bytes()
    assert not data.startswith(b'\x7fELF')
    name = 'primary-error/' + str(file.relative_to(SOURCE))
    payloads[name] = data
    entries.append({'path': name, 'sourcePath': str(file), 'bytes': len(data), 'sha256': sha(data),
                    'sourceMtimeNs': file.stat().st_mtime_ns})
script = Path(__file__).resolve()
payloads[script.name] = script.read_bytes()
entries.append({'path': script.name, 'sourcePath': str(script), 'bytes': script.stat().st_size,
                'sha256': sha(script.read_bytes()), 'sourceMtimeNs': script.stat().st_mtime_ns})
entries.sort(key=lambda item: item['path'])

# Recheck every original per-command digest before packaging. Binary receipts
# remain complete, but native executables are deliberately absent from the tar.
for attempt in ['repro-01', 'fixed-01']:
    record = json.loads((SOURCE / attempt / 'result.json').read_text())
    assert record['passed'] and record['source_unchanged'] and record['binary_unchanged']
    for item in record['commands']:
        assert sha((SOURCE / attempt / item['log']).read_bytes()) == item['log_sha256']
    for path, item in record['files'].items():
        file = SOURCE / attempt / path
        assert file.stat().st_size == item['bytes'] and sha(file.read_bytes()) == item['sha256']

meta = {'scope': 'Native-only correctness: five actual original-code failures, same tests corrected, existing three native gates. No performance or external package credit.',
        'baseCommit': '31693e3883f1192a34fcb9e9c49acdcca4ad321c',
        'testOnlyCommit': '6bb6bb93471acb34fbd237b4e2d1f5f43249a223',
        'fixCommit': 'b072be249f57f9304fabfc82652d7a739cf9ed04',
        'fixTree': '169544b480aba0fcdff1cfcbd5668ed17dfddf19',
        'exclusions': ['original ELF', 'native build and object files', 'restore caches', 'PostgreSQL data'],
        'files': entries}
payloads['manifest.json'] = (json.dumps(meta, indent=2, sort_keys=True) + '\n').encode()
payloads['SHA256SUMS'] = ''.join(item['sha256'] + '  ' + item['path'] + '\n' for item in entries).encode()


def encode():
    raw = io.BytesIO()
    with tarfile.open(fileobj=raw, mode='w', format=tarfile.USTAR_FORMAT) as archive:
        for name, data in sorted(payloads.items()):
            item = tarfile.TarInfo(name)
            item.size = len(data)
            item.mode = 0o644
            item.mtime = item.uid = item.gid = 0
            item.uname = item.gname = ''
            archive.addfile(item, io.BytesIO(data))
    return gzip.compress(raw.getvalue(), compresslevel=9, mtime=0)


encoded = encode()
assert encoded == encode(), 'Archive is not deterministic'
TARGET.write_bytes(encoded)
with tempfile.TemporaryDirectory(prefix='primary-error-readback-') as folder:
    extracted = Path(folder)
    with tarfile.open(TARGET, 'r:gz') as archive:
        assert set(archive.getnames()) == set(payloads)
        for item in archive.getmembers():
            assert item.isfile()
            data = archive.extractfile(item).read()
            assert data == payloads[item.name]
            destination = extracted / item.name
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(data)
    for name, data in payloads.items():
        assert (extracted / name).read_bytes() == data
    for item in entries:
        assert sha((extracted / item['path']).read_bytes()) == item['sha256']
        assert Path(item['sourcePath']).read_bytes() == payloads[item['path']]

result = dict(meta)
result.update({'archivePath': str(TARGET), 'archiveBytes': len(encoded), 'archiveSha256': sha(encoded),
               'evidenceFiles': len(entries) - 1, 'members': len(payloads), 'twoEncodingsByteEqual': True,
               'everyArchivedAndExtractedByteCompared': True, 'originalCommandLogHashesVerified': True,
               'allSourceFilesStillUnchanged': True})
MANIFEST.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps({'archive': str(TARGET), 'bytes': len(encoded), 'sha256': sha(encoded),
                  'manifest': str(MANIFEST), 'manifestSha256': sha(MANIFEST.read_bytes()),
                  'evidenceFiles': result['evidenceFiles'], 'members': result['members'], 'readback': True}))
