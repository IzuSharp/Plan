#!/usr/bin/env python3
"""Retain exact negative-control and corrected native correctness attempts."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
NATIVE = ROOT / 'artifacts/cmake/linux-x64-release'


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def identity():
    files = subprocess.check_output(['git', 'ls-files', '-z', 'native/cpp', 'CMakeLists.txt', 'CMakePresets.json'], cwd=ROOT).split(b'\0')
    return {
        'commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
        'tree': subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=ROOT, text=True).strip(),
        'status': subprocess.check_output(['git', 'status', '--short'], cwd=ROOT, text=True),
        'files': {name.decode(): digest(ROOT / name.decode()) for name in files if name},
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stage', choices=['repro', 'fixed'])
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    record = {'schema': 1, 'stage': args.stage, 'scope': 'Native correctness only; no benchmark or package production.',
              'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'workspace': str(ROOT), 'runner_sha256': digest(__file__), 'source_before': identity(), 'commands': []}
    receipt = output / 'result.json'

    def save():
        receipt.write_text(json.dumps(record, indent=2) + '\n')

    def run(label, command, timeout=300):
        log = output / (label + '.log')
        began = time.monotonic()
        with log.open('wb') as stream:
            child = subprocess.Popen(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
            try:
                status = child.wait(timeout)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait()
                status = 124
        item = {'label': label, 'command': command, 'cwd': str(ROOT), 'exit_code': status,
                'seconds': time.monotonic() - began, 'log': log.name, 'log_sha256': digest(log)}
        record['commands'].append(item)
        save()
        print(json.dumps(item), flush=True)
        return status

    save()
    configure = ['cmake', '--preset', 'linux-x64-release',
                 '-DFETCHCONTENT_SOURCE_DIR_NW_JSON=/workspace/scratch/4a65d70f0fe1/tools/native-dependencies/nlohmann-json/json',
                 '-DFETCHCONTENT_SOURCE_DIR_NW_SQLITE=/workspace/scratch/4a65d70f0fe1/tools/native-dependencies/sqlite/sqlite-amalgamation-3510300']
    if args.stage == 'repro' and run('configure', configure) != 0:
        raise SystemExit(1)
    targets = ['nw_host_review_tests'] if args.stage == 'repro' else ['nw_host_review_tests', 'nw_transaction_tests', 'nw_streaming_tests']
    if run('build', ['cmake', '--build', '--preset', 'linux-x64-release', '--target', *targets, '--parallel', '2'], 900) != 0:
        raise SystemExit(1)
    binary = NATIVE / 'tests/nw_host_review_tests'
    record['binary_before'] = {'path': str(binary), 'sha256': digest(binary), 'bytes': binary.stat().st_size}
    save()
    if args.stage == 'repro':
        # Preserve the original ELF locally before the later incremental build.
        shutil.copyfile(binary, output / 'nw_host_review_tests.original')
        outcomes = []
        for scenario in range(5):
            label = 'scenario-' + str(scenario)
            status = run(label, [str(binary), 'command-cleanup', str(scenario)], 30)
            log = (output / (label + '.log')).read_text()
            outcomes.append(status == 1 and 'command cleanup failure replaced the original error or its terminal identity' in log
                            and 'drained=1 owners_zero=1' in log)
        record['negative_control_failures_verified'] = outcomes
        passed = all(outcomes)
    else:
        passed = run('targeted', [str(binary), 'command-cleanup'], 45) == 0
        if passed:
            passed = run('regressions', ['ctest', '--preset', 'linux-x64-release', '-R',
                                        '^native\\.(host_review|transactions|streaming)$', '--output-on-failure'], 180) == 0
            details = NATIVE / 'Testing/Temporary/LastTest.log'
            if details.exists():
                shutil.copyfile(details, output / 'regressions-details.log')
        if passed:
            passed = run('format', ['clang-format', '--dry-run', '--Werror', 'native/cpp/src/host.cpp',
                                    'native/cpp/tests/host_review_tests.cpp']) == 0
        if passed:
            passed = run('diff-check', ['git', 'diff', '--check', '31693e3883f1192a34fcb9e9c49acdcca4ad321c', 'HEAD']) == 0
        if passed:
            passed = run('impact', ['python3', 'eng/ci/impact.py', 'origin/main', '--output', str(output / 'impact-plan.json')]) == 0
    record['source_after'] = identity()
    record['source_unchanged'] = record['source_before'] == record['source_after']
    record['binary_after_sha256'] = digest(binary)
    record['binary_unchanged'] = record['binary_before']['sha256'] == record['binary_after_sha256']
    record['completed_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    record['passed'] = passed and record['source_unchanged'] and record['binary_unchanged']
    record['files'] = {str(path.relative_to(output)): {'sha256': digest(path), 'bytes': path.stat().st_size}
                       for path in output.rglob('*') if path.is_file() and path != receipt}
    save()
    print(json.dumps({'result': str(receipt), 'sha256': digest(receipt), 'passed': record['passed']}), flush=True)
    raise SystemExit(0 if record['passed'] else 1)


if __name__ == '__main__':
    main()
