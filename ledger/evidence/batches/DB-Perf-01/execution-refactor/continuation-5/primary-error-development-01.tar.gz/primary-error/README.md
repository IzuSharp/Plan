# Session command error priority: isolated native correctness

Base is public `31693e3883f1192a34fcb9e9c49acdcca4ad321c`.
Test-only commit is `6bb6bb93471acb34fbd237b4e2d1f5f43249a223`.
The minimal product fix is `b072be249f57f9304fabfc82652d7a739cf9ed04`, tree
`169544b480aba0fcdff1cfcbd5668ed17dfddf19`.
`source-parity.json` confirms the original product is byte-identical to the base,
the corrected commit changes only `native/cpp/src/host.cpp`, and exactly the same
test source was used before and after the correction. Both attempts retain
complete tracked native source hashes before and after their actual commands.

## Change and boundary

The two `Session::execute` error handlers preserve the primary exception while
running the existing parent cleanup sequence. A cleanup launch/post failure
marks the Session for discard and poisons the Source, and attaches the previously
initialized cleanup marker only when the original Error has no cleanup detail.
The Error's status, code, message, provider code, correlation and bulk progress
survive. Non-Error classification keeps the existing DbOperation OOM/panic
categories and text. The nonquery handler protects the existing SessionMutating
request_close/join as well as CommandGate::finish.

No gate, detached worker fence, cursor-ready path, transaction transition,
provider operation, ABI, managed API or CI flow changed. No new production test
hook was added. Cleanup scheduling remains retryable after a launch failure;
command completion never declares the parent retired.

## Exact negative controls

`nw_host_review_tests command-cleanup <scenario>` uses real Session::execute and
DbOperation terminal/error storage. Existing synchronous cleanup hooks inspect
the active primary handler by bare rethrow. For index 1 they add earlier cleanup
and bulk progress solely to assert preservation; no exception-address assumption
is made. SQLite failures are actual provider errors from an absent table.

| Scenario | Primary error | Secondary failure |
| --- | --- | --- |
| 0 | count capacity, status/code 13/6 | closing transaction worker 0 launch |
| 1 | count capacity, status/code 13/6, earlier cleanup/bulk | worker 1 launch after worker 0 is prepared |
| 2 | real SQLite SQL failure, status/code 13/1 | closing transaction worker 0 launch |
| 3 | real SQLite SQL failure, status/code 13/1, earlier cleanup/bulk | worker 1 launch after worker 0 is prepared |
| 4 | real SQLite SessionMutating SQL failure, status/code 13/1 | Session cleanup post allocation failure |

All five original commands actually exit **1**, with the exact error-identity
assertion failing. Scenarios 0–3 expose panic 9/8 instead of the primary Error;
scenario 4 exposes OOM 5/8. Every negative control removes its fault, performs
the real rollback/Session/Source joins and records drained=1/owners_zero=1 before
reporting failure. They retain their independent stdout/stderr logs, original
ELF digest and local frozen ELF copy. The wrapper exits 0 because all five
expected negative controls were verified, not because the original code passed.

Original ELF SHA256:
`95f7c8c9d9af8a18068767f29a63ca0ba306fef26734abd170571088b003d295`.
Reproduction result SHA256:
`63ec49da4933ec13c834078c0e99de3b816bb474ae2e4b4fe3b92a763a96ee69`.

## Corrected result

The unchanged five scenarios all pass in the corrected executable. They check
one terminal delivery, original status/code/message/provider/correlation,
preserved existing cleanup and all bulk fields, newly attached secondary cleanup
when absent, cleared admission, incomplete parent retirement at failure,
compensated detached launches, retryability, discard/poison, real subsequent
rollback/close and zero Source/Session/Operation/Cursor/Buffer/Pull counts.

The existing CTest gates native.host_review, native.transactions and
native.streaming all actually exit 0 (3/3; 3.62 seconds). The saved immediate
CTest detail log includes the full Host review success, 120 transaction checks
and 369 streaming checks. It is an immutable copy, not a later LastTest.log.
The five new scenarios run in both their targeted command and the existing
host_review suite. Clang-format verification, git diff --check and the actual
impact planner also exit 0. No test assertions were relaxed after reproduction.

Corrected ELF SHA256:
`b249489a9973a2711030b3fa12d75190d3e3d5b4dc379a028a9c226d962f4a4c`.
Corrected result SHA256:
`5b797af4b8f6b2dce82581b1bd3a5adac88b05c2923f7ede8ff8ce823d1726d4`.
Both attempt receipts prove source and executable hashes stayed unchanged
throughout their respective commands.

The actual origin/main impact plan maps host.cpp to database-native and this
test to native-checks. The entire open PR selects the existing interop/linux
checks and separate PostgreSQL/SQLite package build/consume/API validations.
No benchmark action, performance workflow or CI job was added. This isolated
development run supplies the necessary native correctness evidence; it does not
claim to have rerun the entire PR's package or managed CI matrix.

## Separate count limitation and credit

MaxBatchRows=1 is a **valid public configuration**. Existing scalar_count asks
for two rows and currently fails with capacity before fetching. Scenarios 0/1
use that precise pre-existing failure to test cleanup priority; they neither fix
it nor label it invalid configuration. A future direct-scalar implementation
must independently preserve width, NULL, cardinality, first-row side effects,
transactions, late errors and safe reuse. Ordinary query-phase/mixed results
without Count/Any cannot establish that behavior.

No benchmark, profiler, allocation diagnostic, mixed load or PostgreSQL server
was run here. These are native fixture correctness results against actual
SQLite and the existing detached-worker regressions, not frozen external
provider-package validation or performance credit.

## Recovery

Apply test.patch and fix.patch in order to the base. To reproduce the original
failure, run the repro stage on the test-only commit before applying fix.patch.
Each stage requires a fresh output directory and the pinned task toolchain:

```sh
source /workspace/scratch/4a65d70f0fe1/tools/task-env.sh
python3 artifacts/primary-error/run.py repro --output artifacts/primary-error/repro-next
# Apply the retained fix.patch before this stage.
python3 artifacts/primary-error/run.py fixed --output artifacts/primary-error/fixed-next
```

The runner performs only native correctness and records argv, cwd, actual exit,
elapsed time, source identity, original logs and executable hashes. The archive
includes patches, runner, immediate logs, source records, compiler provenance,
generated fingerprint and the complete actual impact plan. It excludes native
ELFs, object/build trees, caches and PostgreSQL data. The original frozen ELF is
retained locally in repro-01 and remains listed in that original receipt.
