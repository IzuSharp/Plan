# Retired private bridge cleanup development evidence

All three original attempts remain intact. Attempt 01 passed native.interop and
compiled the AOT suite, then failed a new test which confused a WaitAsync proxy
with the original canceled Task. Attempt 02 corrected that observation, passed
the main AOT suite and three isolated fault processes, then failed sample
compilation because a shared test field was never assigned in the sample.
Attempt 03 used an auto property and preserved exact exception identity at five
existing generic setup/take boundaries. All commands in attempt 03 succeeded.

The final main suite passed 451 assertions (90 migrated ownership assertions),
with 73 native owners created and released, zero live/input/result owners, and
32 GC iterations. Three fault subprocesses, the Native AOT example, Host build,
Async/error API checks, impact plan and source immutability checks passed.
Fault subprocesses deliberately retain unknown obligations; they never report
successful retirement. Attempt 01's successful native fixture/CTest was reused
in 02/03 through immutable source comparison and binary hash checks.

The caller audit, assertion migration mapping and committed diff preserve why
the unused RetiredValueTask bridge, direct SafeHandle branch and private observer
were removed. Generic Task and independent Retirement, NativeResourceOwner,
DataSource.Complete diagnostics and the frozen native ABI remain.

Public source parity is separate archive-time analysis. It does not relabel
these local development executions as public package, CI or performance runs.
Only text evidence is archived; executable/shared-library hashes remain in the
original receipts. All raw logs, failures, exits and source identities are kept.

Tar entries are sorted, mode0644, uid/gid/mtime0; gzip uses empty name and mtime0.
MANIFEST.sha256 covers all other members. The external manifest records two
byte-identical encodings, complete readback/extraction/hash validation, and
unchanged original inputs. No build, test or benchmark runs during archiving.
