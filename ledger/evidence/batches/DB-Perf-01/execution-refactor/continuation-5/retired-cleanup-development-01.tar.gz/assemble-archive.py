#!/usr/bin/env python3
"""Preserve original text evidence; deterministic tar/gzip plus full readback."""
import datetime
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile
import tempfile

ROOT = Path('/workspace/scratch/4a65d70f0fe1')
ART = ROOT / 'artifacts'
REPO = ROOT / 'worktrees/DB-Exec-04-retired-cleanup'
NAME = 'retired-cleanup-development-01'
FINAL = '5238dc9d9223aec5219123447a1d772484d18acb'
PUBLIC = '805812872d9d8860bb3bf9e55db18772f3579d85'
SCOPE = 'Original local Interop.Async development attempts, failures, caller audit and later source identity; no public package, CI, performance or stress acceptance.'
sha = lambda data: hashlib.sha256(data).hexdigest()
encode = lambda value: (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode()
git = lambda *args: subprocess.check_output(['git', *args], cwd=REPO)
members = {}
sources = []


def add(path, name, expected=None, kind='original'):
    path = Path(path)
    before = path.stat()
    data = path.read_bytes()
    after = path.stat()
    assert before.st_size == after.st_size == len(data) and before.st_mtime_ns == after.st_mtime_ns, path
    data.decode('utf-8')
    assert name not in members and not name.startswith('/') and '..' not in Path(name).parts
    if expected is not None:
        assert sha(data) == expected, (path, sha(data), expected)
    members[name] = data
    sources.append({'path': name, 'origin': str(path), 'kind': kind, 'bytes': len(data), 'sha256': sha(data),
                    'observedOriginalMtimeNs': after.st_mtime_ns,
                    'observedOriginalMtimeUtc': datetime.datetime.fromtimestamp(after.st_mtime, datetime.timezone.utc).isoformat()})


def derived(name, data, note):
    assert name not in members
    members[name] = data
    sources.append({'path': name, 'origin': note, 'kind': 'derived-at-archive', 'bytes': len(data), 'sha256': sha(data)})


attempts = {}
expected = ['74cfa823942d80317f364296d18faae0f22d03ccdaef404db99a55024da7d48d',
            '596b103e91b2af86bdc31d0202125310d4bdee5c03d9d49bdd313c25e04726f5',
            '6814fe539aacee8460b2db5196a7a74f518b9c8b4c155e96436bdeaa25ac59e4']
for number, digest in zip(('01', '02', '03'), expected):
    directory = ROOT / ('validation-evidence/retired-cleanup-' + number)
    report = json.loads((directory / 'result.json').read_bytes())
    attempts[number] = report
    add(directory / 'result.json', 'attempt-' + number + '/result.json', digest)
    included = {'result.json'}
    for command in report['commands']:
        for suffix in ('stdout', 'stderr'):
            name = command['label'] + '.' + suffix
            add(directory / name, 'attempt-' + number + '/' + name, command[suffix + '_sha256'])
            included.add(name)
    for path in sorted(directory.glob('*.json')):
        if path.name not in included:
            add(path, 'attempt-' + number + '/' + path.name)
            included.add(path.name)
    assert all(path.is_dir() or path.name in included for path in directory.iterdir())
    for name, digest in report['sourceSha256'].items():
        assert sha(git('show', report['sourceCommit'] + ':' + name)) == digest, (number, name)
assert not attempts['01']['passed'] and not attempts['02']['passed'] and attempts['03']['passed']
assert attempts['03']['sourceCommit'] == FINAL and attempts['03']['sourceUnchanged'] and not attempts['03']['finalDirty']
for label in ('native-tests', 'native-build', 'native-format'):
    assert next(item for item in attempts['01']['commands'] if item['label'] == label)['exit'] == 0
assert next(item for item in attempts['01']['commands'] if item['label'] == 'tests-aot-run')['exit'] == -6
assert next(item for item in attempts['02']['commands'] if item['label'] == 'sample-aot-publish')['exit'] == 1
assert all(command['exit'] == 0 for command in attempts['03']['commands'])

for number, suffix in [('01', ''), ('02', '_02'), ('03', '_03')]:
    add(ART / ('run_retired_cleanup_gate' + suffix + '.py'), 'scripts/run-gate-' + number + '.py')
    add(ART / ('retired-cleanup-gate-' + number + '.log'), 'runner/gate-' + number + '.log')
for name in ('retired-cleanup-audit.json', 'retired-cleanup-callers-before.txt'):
    add(ART / name, 'audit/' + name)
for name in ('retired-cleanup-format-01.log', 'retired-cleanup-format-final.log'):
    add(ART / name, 'format/' + name)

scope = ['src', 'native', 'tests/Interop.Async', 'samples/api/interop-async']
assert not git('diff', '--name-only', FINAL, PUBLIC, '--', *scope)
parity = {'scope': 'Source identity only; previous local executions are not public-candidate executions.',
          'testedCommit': FINAL, 'testedTree': git('rev-parse', FINAL + '^{tree}').decode().strip(),
          'publicCommit': PUBLIC, 'publicTree': git('rev-parse', PUBLIC + '^{tree}').decode().strip(),
          'comparedPaths': scope, 'gitDiffEmpty': True,
          'trees': {name: {'tested': git('rev-parse', FINAL + ':' + name).decode().strip(),
                           'public': git('rev-parse', PUBLIC + ':' + name).decode().strip()} for name in scope}}
assert parity['publicTree'] == '9866611a2abbe104cf0790b4a04b229183384633'
derived('PUBLIC-SOURCE-PARITY.json', encode(parity), 'Archive-time immutable Git object comparison')
derived('audit/removal-and-migration.diff', git('diff', 'e92070cd95267d08d8f033cc7061d4c71e279d71', FINAL,
        '--', 'src/Interop.Async', 'src/Data.NativeHost/NativeHost.cs', 'tests/Interop.Async'), 'Exact committed removal and test migration')
derived('format/EXIT-OBSERVATION.json', encode({'kind': 'Retrospective original-owner tool-exit attribution',
        'sourceCommit': FINAL, 'observedToolExitCode': 0, 'originalOwner': 'ci_build_audit',
        'command': 'dotnet format whitespace --folder --include src/Interop.Async/AsyncOperation.cs src/Data.NativeHost/NativeHost.cs tests/Interop.Async/Fixture.cs tests/Interop.Async/Program.cs tests/Interop.Async/OperationOwnershipTests.cs --verify-no-changes --verbosity minimal',
        'limitation': 'The empty format log alone is not process-exit evidence.'}), 'Original tool owner observed exit0')
readme = '''# Retired private bridge cleanup development evidence

All three original attempts remain intact. Attempt 01 passed native.interop and
compiled the AOT suite, then failed a new test which confused a WaitAsync proxy
with the original canceled Task. Attempt 02 corrected that observation, passed
the main AOT suite and three isolated fault processes, then failed sample
compilation because a shared test field was never assigned in the sample.
Attempt 03 used an auto property and preserved exact exception identity at five
existing generic setup/take boundaries. All commands in attempt 03 succeeded.

The final main suite passed 451 assertions (90 migrated ownership assertions),
with 73 native owners created and released, zero live/input/result owners, and
32 GC iterations. Three fault subprocesses, the Native AOT example, Host build,
Async/error API checks, impact plan and source immutability checks passed.
Fault subprocesses deliberately retain unknown obligations; they never report
successful retirement. Attempt 01's successful native fixture/CTest was reused
in 02/03 through immutable source comparison and binary hash checks.

The caller audit, assertion migration mapping and committed diff preserve why
the unused RetiredValueTask bridge, direct SafeHandle branch and private observer
were removed. Generic Task and independent Retirement, NativeResourceOwner,
DataSource.Complete diagnostics and the frozen native ABI remain.

Public source parity is separate archive-time analysis. It does not relabel
these local development executions as public package, CI or performance runs.
Only text evidence is archived; executable/shared-library hashes remain in the
original receipts. All raw logs, failures, exits and source identities are kept.

Tar entries are sorted, mode0644, uid/gid/mtime0; gzip uses empty name and mtime0.
MANIFEST.sha256 covers all other members. The external manifest records two
byte-identical encodings, complete readback/extraction/hash validation, and
unchanged original inputs. No build, test or benchmark runs during archiving.
'''
derived('README.md', readme.encode(), 'Archive scope and recovery instructions')
add(__file__, 'assemble-archive.py', kind='archive-tool')
members['SOURCE-MANIFEST.json'] = encode({'schemaVersion': 1, 'scope': SCOPE, 'sources': sorted(sources, key=lambda item: item['path'])})
members['MANIFEST.sha256'] = ''.join(f'{sha(data)}  {name}\n' for name, data in sorted(members.items())).encode()


def packed():
    result = io.BytesIO()
    with gzip.GzipFile(filename='', fileobj=result, mode='wb', mtime=0, compresslevel=9) as zipped:
        with tarfile.open(fileobj=zipped, mode='w', format=tarfile.USTAR_FORMAT) as archive:
            for name, data in sorted(members.items()):
                info = tarfile.TarInfo(name)
                info.size = len(data)
                info.uid = info.gid = info.mtime = 0
                info.mode = 0o644
                info.uname = info.gname = ''
                archive.addfile(info, io.BytesIO(data))
    return result.getvalue()


first = packed()
assert first == packed()
archive_path = ART / (NAME + '.tar.gz')
assert not archive_path.exists()
archive_path.write_bytes(first)
assert archive_path.read_bytes() == first
with tempfile.TemporaryDirectory(prefix='retired-cleanup-readback-', dir=ART) as temporary:
    destination = Path(temporary)
    with tarfile.open(archive_path, 'r:gz') as archive:
        listed = archive.getmembers()
        assert len(listed) == len(members) and {item.name for item in listed} == set(members)
        for item in listed:
            assert item.isfile() and item.uid == item.gid == item.mtime == 0 and item.mode == 0o644
            assert not item.uname and not item.gname
            data = archive.extractfile(item).read()
            assert data == members[item.name]
            target = destination / item.name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
            assert target.read_bytes() == members[item.name]
        for line in (destination / 'MANIFEST.sha256').read_text().splitlines():
            digest, name = line.split('  ', 1)
            assert sha((destination / name).read_bytes()) == digest
for item in sources:
    if item['kind'] in ('original', 'archive-tool'):
        assert Path(item['origin']).read_bytes() == members[item['path']]
external = {'schemaVersion': 1, 'scope': SCOPE,
            'archive': {'path': str(archive_path), 'bytes': len(first), 'sha256': sha(first)},
            'members': [{'path': name, 'bytes': len(data), 'sha256': sha(data)} for name, data in sorted(members.items())],
            'sourceManifestSha256': sha(members['SOURCE-MANIFEST.json']),
            'publicSourceParitySha256': sha(members['PUBLIC-SOURCE-PARITY.json']),
            'verification': {'twoIndependentEncodingsByteIdentical': True, 'archiveFileReadBackByteIdentical': True,
                             'everyMemberReadBackByteCompared': True, 'everyExtractedFileByteCompared': True,
                             'everyManifestSha256Verified': True, 'allOriginalsUnchangedAfterReadback': True,
                             'temporaryExtractionRemoved': True, 'memberCount': len(members),
                             'uncompressedMemberBytes': sum(map(len, members.values()))}}
manifest = ART / (NAME + '.manifest.json')
assert not manifest.exists()
manifest.write_bytes(encode(external))
(ART / (NAME + '.README.md')).write_text(readme)
print(json.dumps({'archive': str(archive_path), 'sha256': sha(first), 'bytes': len(first), 'members': len(members),
                  'manifest': str(manifest), 'manifestSha256': sha(manifest.read_bytes())}))
