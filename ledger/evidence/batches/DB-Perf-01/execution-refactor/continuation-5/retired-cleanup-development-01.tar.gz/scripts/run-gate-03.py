#!/usr/bin/env python3
import concurrent.futures
import datetime
import hashlib
import json
import os
from pathlib import Path
import resource
import subprocess
import sys
import threading

ROOT = Path('/workspace/scratch/4a65d70f0fe1/worktrees/DB-Exec-04-retired-cleanup')
OUTPUT = Path('/workspace/scratch/4a65d70f0fe1/validation-evidence/retired-cleanup-03')
OUTPUT.mkdir(parents=True, exist_ok=False)
resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
os.environ['NW_CMAKE_PRESET'] = 'interop'
os.environ['NW_NATIVE_CMAKE_ARGS'] = '-DFETCHCONTENT_SOURCE_DIR_NW_JSON=/workspace/scratch/4a65d70f0fe1/tools/native-dependencies/nlohmann-json/json'
os.environ['DOTNET_PROCESSOR_COUNT'] = '1'
sys.path.insert(0, str(ROOT/'tests'))
import native_build
lock = threading.Lock()
report = {'scope':'Local correctness for removal of unused RetiredValueTask bridge; no performance or frozen provider package claim.', 'startedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(), 'commands':[], 'passed':False}

def digest(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(): (OUTPUT/'result.json').write_text(json.dumps(report, indent=2)+'\n')
def run(label, command, env=None):
    command = list(map(str,command))
    result = subprocess.run(command, cwd=ROOT, env=env, capture_output=True, timeout=300)
    for suffix, data in [('stdout',result.stdout),('stderr',result.stderr)]:
        (OUTPUT/(label+'.'+suffix)).write_bytes(data)
    with lock:
        report['commands'].append({'label':label,'argv':command,'exit':result.returncode,'stdout_sha256':hashlib.sha256(result.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(result.stderr).hexdigest()})
        save()
    print(label,result.returncode,flush=True)
    if result.returncode:
        raise RuntimeError(label+': '+result.stdout.decode(errors='replace')[-3500:]+result.stderr.decode(errors='replace')[-3500:])
    return result.stdout.decode(errors='replace'),result.stderr.decode(errors='replace')

common = ['-p:UseSharedCompilation=false','-nr:false','-m:1']
def publish(label,project,assembly):
    destination=OUTPUT/(label+'-aot')
    run(label+'-aot-publish',['dotnet','publish',project,'-c','Release','-r','linux-x64','-p:PublishAot=true','-p:RestoreLockedMode=true','-p:IlcTreatWarningsAsErrors=true','-o',destination,*common])
    executable=destination/assembly
    if (destination/(assembly+'.dll')).exists(): raise RuntimeError('Consumer is not standalone Native AOT')
    return executable

try:
    report['sourceCommit']=run('commit',['git','rev-parse','HEAD'])[0].strip()
    report['sourceTree']=run('tree',['git','rev-parse','HEAD^{tree}'])[0].strip()
    report['sourceDirty']=bool(run('status',['git','status','--porcelain'])[0].strip())
    paths=run('source-files',['git','ls-files','src/Interop.Async','src/Interop.Lifetime','src/Interop.Callbacks','src/Interop.Errors','src/Interop.Memory','src/Korda.Core','src/Interop.Abi','src/Interop.Negotiation','src/Data.NativeHost/NativeHost.cs','tests/Interop.Async','samples/api/interop-async','native/cpp','native/interop/async','Directory.Build.props','Directory.Build.targets','global.json','eng/ci/interop','tests/native_build.py'])[0].splitlines()
    report['sourceSha256']={p:digest(ROOT/p) for p in paths}
    run('dotnet-version',['dotnet','--version'])
    prior_path=Path('/workspace/scratch/4a65d70f0fe1/validation-evidence/retired-cleanup-01/result.json')
    prior=json.loads(prior_path.read_text())
    run('native-source-parity',['git','diff','--exit-code',prior['sourceCommit'],'HEAD','--','native/cpp','native/interop','eng/ci/interop'])
    report['nativeCompilerProvenance']=prior['nativeCompilerProvenance']
    report['reusedNativeGate']={'receipt':str(prior_path),'sha256':digest(prior_path),'reason':'Only C# fixtures changed; native inputs and the already-passed CTest are unchanged.'}
    for artifact in ('native','downstream'):
        item=prior['artifacts'][artifact]
        if digest(item['path']) != item['sha256']: raise RuntimeError('Native artifact changed: '+artifact)
    tests=publish('tests','tests/Interop.Async/Interop.Async.Tests.csproj','Korda.Interop.Async.Tests')
    native_path=native_build.FIXTURES/'libkorda_interop_async.so'
    downstream=native_build.FIXTURES/'libnw_async_downstream.so'
    exports=run('downstream-exports',['nm','-D','--defined-only',downstream])[0]
    names=sorted(line.split()[-1] for line in exports.splitlines() if line.strip())
    if names != ['nw_async_link_probe_v1']: raise RuntimeError('Unexpected downstream exports: '+repr(names))
    report['artifacts']={'native':{'path':str(native_path),'sha256':digest(native_path)},'downstream':{'path':str(downstream),'sha256':digest(downstream)},'tests':{'path':str(tests),'sha256':digest(tests)}}
    env=os.environ.copy(); env['LD_LIBRARY_PATH']=str(native_build.FIXTURES)+(':'+env['LD_LIBRARY_PATH'] if env.get('LD_LIBRARY_PATH') else '')
    report['testsOutput']=run('tests-aot-run',[tests,'--require-aot'],env)[0]
    for mode in ['--indeterminate-start','--callback-then-reject','--retire-fault']:
        run('tests-aot-'+mode[2:],[tests,'--require-aot',mode],env)
    sample=publish('sample','samples/api/interop-async/Interop.Async.Sample.csproj','Korda.Interop.Async.Sample')
    report['sampleOutput']=run('sample-aot-run',[sample],env)[0]
    report['artifacts']['sample']={'path':str(sample),'sha256':digest(sample)}
    run('host-build',['dotnet','build','src/Data.NativeHost/Korda.Database.csproj','-c','Release','-p:RestoreLockedMode=true',*common])
    sdk=Path(os.environ['DOTNET_ROOT'])
    for label,project,assembly in [('api','tests/Interop.Async/ApiCheck/ApiCheck.csproj','Korda.Interop.Async.ApiCheck'),('error-api','tests/Interop.Errors/ApiCheck/ApiCheck.csproj','Korda.Interop.Errors.ApiCheck')]:
        run(label+'-build',['dotnet','build',project,'-c','Release','-p:RestoreLockedMode=true',*common])
        run(label+'-check',['dotnet',ROOT/Path(project).parent/'bin/Release/net11.0'/(assembly+'.dll'),ROOT,sdk,ROOT/'src/Korda.Core/bin/Release/net11.0/Korda.Core.dll'])
    run('impact',['python3','eng/ci/impact.py','origin/main','--output',OUTPUT/'impact-plan.json'])
    run('diff-check',['git','diff','--check'])
    report['sourceUnchanged']=all(digest(ROOT/p)==value for p,value in report['sourceSha256'].items())
    if not report['sourceUnchanged']: raise RuntimeError('Source changed during verification')
    report['finalDirty']=bool(run('final-status',['git','status','--porcelain'])[0].strip())
    if report['finalDirty']: raise RuntimeError('Tracked source dirty after verification')
    report['passed']=True
except Exception as error:
    report['failure']=str(error)
    raise
finally:
    report['finishedUtc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    save()
    print('Evidence:',OUTPUT,flush=True)
