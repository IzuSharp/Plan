#!/usr/bin/env python3
"""Run the preserved bc6 AOT ELF after replacing only the two provider libraries."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

root = Path('/workspace/scratch/4a65d70f0fe1')
output = Path(__file__).resolve().parent
original = root / 'validation-evidence/cancel-bc6-01'
worktree = root / 'worktrees/DB-Exec-04-cancel-validation'
native = root / 'worktrees/DB-Exec-04-cancel-native'
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
stamp = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
expected_head = 'bc6ba1ae0ece02ecc2c0860776605f3c838f3ff8'
expected_fix = '7960d381f5c8c0c62c2fb12394e494d73df37c62'
expected_elf = '5fbf60d3b23ea1a0744282d7c7f25d5d1a1f32c43cf5aa087a8d4f9140f60d6f'
expected_hashes = {
    'sqlite': '2102973012af4905a049225c35069e2192c5a214c83b6b44fc2582fbfbb1da8d',
    'postgresql': 'aaa0e3c10914034d23aec0a6faeed9b4de853637dc57e37a822d78cf0b44c66c',
}
git = lambda cwd, *args: subprocess.check_output(['git', *args], cwd=cwd, text=True).strip()
assert git(worktree, 'rev-parse', 'HEAD') == expected_head
assert not git(worktree, 'status', '--porcelain')
assert git(native, 'rev-parse', 'HEAD') == expected_fix
assert not (output / 'aot').exists(), 'Refusing to overwrite an earlier attempt'
assert sha(original / 'aot/Korda.Orm.Relations.Tests') == expected_elf
baseline = json.loads((original / 'result.json').read_text())
assert baseline['runnerExitCode'] == 250
assert baseline['executableSha256After'] == expected_elf
original_hashes = {str(p.relative_to(original / 'aot')): sha(p)
                   for p in sorted((original / 'aot').rglob('*')) if p.is_file()}
shutil.copytree(original / 'aot', output / 'aot', copy_function=shutil.copy2)
assets = {}
for provider, expected in expected_hashes.items():
    library = native / 'artifacts/cmake/linux-x64-release' / ('libnw_database_' + provider + '.so')
    assert sha(library) == expected
    destination = output / 'aot/runtimes/linux-x64/native' / library.name
    assets[provider] = {'sourcePath': str(library), 'sourceCommit': expected_fix,
                        'sha256': expected, 'destinationPath': str(destination),
                        'originalSha256': sha(destination), 'bytes': library.stat().st_size}
    shutil.copy2(library, destination)
fixed_hashes = {str(p.relative_to(output / 'aot')): sha(p)
                for p in sorted((output / 'aot').rglob('*')) if p.is_file()}
changes = [name for name in original_hashes if original_hashes[name] != fixed_hashes[name]]
assert sorted(changes) == sorted('runtimes/linux-x64/native/libnw_database_' + p + '.so' for p in expected_hashes)
assert original_hashes.keys() == fixed_hashes.keys()
native_receipt = native / 'artifacts/cancel-queued/development-receipt.json'
assert sha(native_receipt) == 'b59670cc7aa27d625aea78e2867f37700465ede3ac6e424d5bfcaf66e15ca954'
shutil.copy2(native_receipt, output / 'native-development-receipt.json')
shutil.copy2(original / 'result.json', output / 'original-failed-result.json')
executable = output / 'aot/Korda.Orm.Relations.Tests'
run = ['python3', 'tests/Data.NativeHost/run.py', '--postgres-bin', os.environ['NW_POSTGRES_BIN'],
       '--output', str(output / 'providers'), '--', str(executable), '--require-aot']
receipt = {
    'scope': 'Mixed-stage native-only compatibility attempt: unchanged original public bc6 Orm.Relations AOT ELF, only two provider .so files replaced by native fix 7960d381. Not a rebuilt package or new public candidate gate.',
    'managedSourceCommit': expected_head, 'nativeSourceCommit': expected_fix,
    'managedSourceTree': git(worktree, 'rev-parse', 'HEAD^{tree}'),
    'managedRebuilt': False, 'testAssertionsModified': False,
    'startedUtc': stamp(), 'scriptSha256': sha(__file__),
    'originalAttempt': str(original), 'originalFailureExitCode': baseline['runnerExitCode'],
    'originalResultSha256': sha(original / 'result.json'),
    'originalFailureLogSha256': sha(original / 'providers/consumer.log'),
    'nativeDevelopmentReceiptSha256': sha(native_receipt),
    'executableSha256Before': sha(executable),
    'originalPublishFiles': original_hashes, 'attemptPublishFilesBefore': fixed_hashes,
    'onlyChangedFiles': changes, 'nativeAssets': assets,
    'runCommand': run, 'runWorkingDirectory': str(worktree),
    'runnerSha256': sha(worktree / 'tests/Data.NativeHost/run.py'),
    'environmentScriptSha256': sha(root / 'tools/task-env.sh'),
    'knownCompatibilityBoundary': 'Provider GeneratedEngineProfile embeds the original native SHA; native asset integrity verification remains enabled. This attempt must record admission rejection rather than bypass it.',
}
(output / 'input-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
with (output / 'run.log').open('w') as stream:
    result = subprocess.run(run, cwd=worktree, stdout=stream, stderr=subprocess.STDOUT)
receipt['runnerExitCode'] = result.returncode
receipt['finishedUtc'] = stamp()
receipt['executableSha256After'] = sha(executable)
receipt['attemptPublishFilesAfter'] = {str(p.relative_to(output / 'aot')): sha(p)
                                     for p in sorted((output / 'aot').rglob('*')) if p.is_file()}
assert receipt['attemptPublishFilesAfter'] == fixed_hashes
assert {str(p.relative_to(original / 'aot')): sha(p)
        for p in sorted((original / 'aot').rglob('*')) if p.is_file()} == original_hashes
receipt['originalAndAttemptFilesUnchangedDuringRun'] = True
receipt['logs'] = {str(p.relative_to(output)): sha(p) for p in sorted(output.rglob('*.log'))}
(output / 'result.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'runnerExitCode': result.returncode, 'result': str(output / 'result.json')}))
raise SystemExit(result.returncode)
