#!/usr/bin/env python3
"""Archive the three original cancellation regression attempts without binaries."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile
import tempfile

root = Path('/workspace/scratch/4a65d70f0fe1')
target = root / 'artifacts/cancel-managed-regression-01.tar.gz'
manifest_path = root / 'artifacts/cancel-managed-regression-01.manifest.json'
assert not target.exists(), 'Refusing to overwrite an existing archive'
sha = lambda data: hashlib.sha256(data).hexdigest()
payloads = {}
entries = []
for attempt in ['cancel-bc6-01', 'cancel-native-fix-01', 'cancel-native-fix-02']:
    folder = root / 'validation-evidence' / attempt
    for file in sorted(folder.rglob('*')):
        relative = file.relative_to(folder)
        if not file.is_file() or 'aot' in relative.parts:
            continue
        assert not file.is_symlink()
        name = attempt + '/' + str(relative)
        data = file.read_bytes()
        payloads[name] = data
        entries.append({'path': name, 'sourcePath': str(file), 'bytes': len(data),
                        'sha256': sha(data), 'sourceMtimeNs': file.stat().st_mtime_ns})
script_data = Path(__file__).read_bytes()
payloads['assemble-cancel-managed-regression-01.py'] = script_data
entries.append({'path': 'assemble-cancel-managed-regression-01.py', 'sourcePath': str(Path(__file__).resolve()),
                'bytes': len(script_data), 'sha256': sha(script_data), 'sourceMtimeNs': Path(__file__).stat().st_mtime_ns})
entries.sort(key=lambda entry: entry['path'])
internal = {'scope': 'Original bc6 failure, native-only identity rejection, and unchanged-source paired-native successful regression. No binary, build output, restore cache or PostgreSQL data included.',
            'managedSourceCommit': 'bc6ba1ae0ece02ecc2c0860776605f3c838f3ff8',
            'nativeFixCommit': '7960d381f5c8c0c62c2fb12394e494d73df37c62',
            'files': entries}
payloads['manifest.json'] = (json.dumps(internal, indent=2, sort_keys=True) + '\n').encode()
payloads['SHA256SUMS'] = ''.join(entry['sha256'] + '  ' + entry['path'] + '\n' for entry in entries).encode()

def encode():
    raw = io.BytesIO()
    with tarfile.open(fileobj=raw, mode='w', format=tarfile.USTAR_FORMAT) as archive:
        for name, data in sorted(payloads.items()):
            info = tarfile.TarInfo(name)
            info.size = len(data)
            info.mode = 0o644
            info.mtime = info.uid = info.gid = 0
            info.uname = info.gname = ''
            archive.addfile(info, io.BytesIO(data))
    return gzip.compress(raw.getvalue(), compresslevel=9, mtime=0)

encoded = encode()
assert encoded == encode(), 'Archive is not byte reproducible'
target.write_bytes(encoded)
with tempfile.TemporaryDirectory(prefix='cancel-evidence-readback-') as temporary:
    extracted = Path(temporary)
    with tarfile.open(target, 'r:gz') as archive:
        assert set(archive.getnames()) == set(payloads)
        for member in archive.getmembers():
            assert member.isfile()
            readback = archive.extractfile(member).read()
            assert readback == payloads[member.name]
            out = extracted / member.name
            out.parent.mkdir(parents=True, exist_ok=True)
            out.write_bytes(readback)
    for name, data in payloads.items():
        assert (extracted / name).read_bytes() == data
    for entry in entries:
        assert sha((extracted / entry['path']).read_bytes()) == entry['sha256']
        assert Path(entry['sourcePath']).read_bytes() == payloads[entry['path']]
result = dict(internal)
result.update({'archivePath': str(target), 'archiveBytes': len(encoded), 'archiveSha256': sha(encoded),
               'originalFileCount': len(entries) - 1, 'memberCount': len(payloads),
               'deterministicSecondEncodingByteEqual': True, 'everyMemberAndExtractedByteCompared': True,
               'allOriginalFilesStillUnchanged': True})
manifest_path.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps({'archive': str(target), 'bytes': len(encoded), 'sha256': sha(encoded),
                  'manifest': str(manifest_path), 'manifestSha256': sha(manifest_path.read_bytes()),
                  'originalFileCount': result['originalFileCount'], 'memberCount': len(payloads), 'readback': True}))
