# Original Orm.Relations suite after the queued-cancellation native fix

This is a mixed-stage development regression. It is not a newly frozen public-package execution gate.

## Source and execution identity

- Managed and test source: public `bc6ba1ae0ece02ecc2c0860776605f3c838f3ff8`, tree `78e6c419a7e1ee2134a5c4aac86e5d5e21483eba`.
- Native source: `7960d381f5c8c0c62c2fb12394e494d73df37c62` after the deterministic reproduction test commit `6c09ecd253c70a93e670bddb59b24652c7f3cd77`.
- `source-parity.json` records all 605 tracked regular files under `src/` and `tests/`. Each was compared byte for byte with `git archive` of public bc6 before publishing, and rehashed after execution. None changed.
- Both provider-generated C# identity files and both SDK asset records were captured before and after publishing. Only the native SHA field changed; all safety checks and original test assertions remained enabled.
- Native SQLite SHA-256: `2102973012af4905a049225c35069e2192c5a214c83b6b44fc2582fbfbb1da8d`.
- Native PostgreSQL SHA-256: `aaa0e3c10914034d23aec0a6faeed9b4de853637dc57e37a822d78cf0b44c66c`.
- Rebuilt AOT executable SHA-256 before and after execution: `be94f8b039f57fb60b0a834e56724499a01f00121aaa059a24d6f237e6da3932`.

## Three separate attempts

| Attempt | Actual result | Meaning |
| --- | --- | --- |
| `cancel-bc6-01` | Publish exit 0; original suite exit 250 | Unchanged public bc6 reproduced the CI cancellation failure on SQLite: expected `OperationCanceledException`, observed `InvalidOperationException`. It did not reach PostgreSQL or final suite assertions. |
| `cancel-native-fix-01` | Unchanged original AOT ELF plus only the two new `.so` files; runner exit 250 | The loader correctly refused the content mismatch against the original embedded provider SHA before database admission. No hash verification was bypassed. This is a package consistency rejection, not a native-fix correctness failure. |
| `cancel-native-fix-02` | Same managed/test sources republished with normal generated provider identities; publish exit 0 and original two-provider suite exit 0 | 1,417 original assertions, 382 managed retirements, and the suite's original six native owner counters all reached zero. |

The original AOT executable remains unchanged at SHA-256 `5fbf60d3b23ea1a0744282d7c7f25d5d1a1f32c43cf5aa087a8d4f9140f60d6f`. The source parity proof concerns source bytes; it does not claim that the two ELF files differ only at the hash strings.

`FluentExperience.CallbackCancellation` executes for both providers in the successful suite. Its original assertions require the exact cancellation token, rolled-back transaction, no commit attempt, released local cleanup resources, and absence of the inserted row. The successful process also reached the other original relational, CRUD, bulk, transaction and real PostgreSQL failure checks. The owner claim here is exactly the six counters read by the original suite, not an additional counter added by this experiment.

## Reproduction

`run-paired.py` contains the executed publish command, original test runner command, source comparison, profile comparison, native hashes, and before/after executable checks. Source the task toolchain environment, preserve the original attempt and native development receipts, and run the script in a fresh attempt directory. It refuses to overwrite its prior publish log. `result.json` contains the actual subprocess exit codes and timestamps; the runner created and removed an isolated real PostgreSQL cluster.

No benchmark was run. No CI, test assertion, managed product source, or loader policy was changed for this regression.
