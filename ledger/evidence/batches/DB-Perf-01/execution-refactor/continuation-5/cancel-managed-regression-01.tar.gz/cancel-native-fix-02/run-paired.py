#!/usr/bin/env python3
"""Republish unchanged bc6 managed/test source with the fixed native asset identities."""
import datetime
import hashlib
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import tarfile

root = Path('/workspace/scratch/4a65d70f0fe1')
output = Path(__file__).resolve().parent
original = root / 'validation-evidence/cancel-bc6-01'
rejected = root / 'validation-evidence/cancel-native-fix-01'
worktree = root / 'worktrees/DB-Exec-04-cancel-validation'
native = root / 'worktrees/DB-Exec-04-cancel-native'
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
sha_bytes = lambda data: hashlib.sha256(data).hexdigest()
stamp = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
git = lambda cwd, *args: subprocess.check_output(['git', *args], cwd=cwd, text=True).strip()
expected_head = 'bc6ba1ae0ece02ecc2c0860776605f3c838f3ff8'
expected_fix = '7960d381f5c8c0c62c2fb12394e494d73df37c62'
expected_elf = '5fbf60d3b23ea1a0744282d7c7f25d5d1a1f32c43cf5aa087a8d4f9140f60d6f'
expected_hashes = {
    'sqlite': '2102973012af4905a049225c35069e2192c5a214c83b6b44fc2582fbfbb1da8d',
    'postgresql': 'aaa0e3c10914034d23aec0a6faeed9b4de853637dc57e37a822d78cf0b44c66c',
}
assert not (output / 'publish.log').exists(), 'Refusing to overwrite an earlier attempt'
assert git(worktree, 'rev-parse', 'HEAD') == expected_head
assert not git(worktree, 'status', '--porcelain')
assert git(native, 'rev-parse', 'HEAD') == expected_fix
assert sha(original / 'aot/Korda.Orm.Relations.Tests') == expected_elf

archive = subprocess.check_output(['git', 'archive', expected_head, 'src', 'tests'], cwd=worktree)
source_files = {}
with tarfile.open(fileobj=io.BytesIO(archive)) as source_archive:
    for member in source_archive.getmembers():
        if member.isfile():
            recorded = source_archive.extractfile(member).read()
            current = (worktree / member.name).read_bytes()
            assert current == recorded, member.name
            source_files[member.name] = {'bytes': len(current), 'sha256': sha_bytes(current), 'equalsPublicBc6': True}
source_manifest = {'sourceCommit': expected_head, 'files': source_files, 'fileCount': len(source_files),
                   'allFilesByteEqualPublicCommit': True, 'scope': 'Every tracked regular file under src/ and tests/'}
(output / 'source-parity.json').write_text(json.dumps(source_manifest, indent=2, sort_keys=True) + '\n')
profiles = {
    'sqlite': ('src/Data.Sqlite/obj/Release/net11.0/EngineProfile.g.cs', 'src/Data.Sqlite/obj/Release/net11.0/Korda.database.sqlite.assets.json'),
    'postgresql': ('src/Data.Postgres/obj/Release/net11.0/PostgreSqlAssetIdentity.g.cs', 'src/Data.Postgres/obj/Release/net11.0/Korda.database.postgresql.assets.json'),
}
assets = {}
old_identities = {}
for provider, expected in expected_hashes.items():
    library = native / 'artifacts/cmake/linux-x64-release' / ('libnw_database_' + provider + '.so')
    assert sha(library) == expected
    assets[provider] = {'sourcePath': str(library), 'sourceCommit': expected_fix,
                        'sha256': expected, 'bytes': library.stat().st_size}
    folder = output / 'profiles-before' / provider
    folder.mkdir(parents=True)
    for relative in profiles[provider]:
        shutil.copy2(worktree / relative, folder / Path(relative).name)
    old_identities[provider] = json.loads((folder / Path(profiles[provider][1]).name).read_text())['sha256']
native_receipt = native / 'artifacts/cancel-queued/development-receipt.json'
assert sha(native_receipt) == 'b59670cc7aa27d625aea78e2867f37700465ede3ac6e424d5bfcaf66e15ca954'
shutil.copy2(native_receipt, output / 'native-development-receipt.json')
publish = ['dotnet', 'publish', 'tests/Orm.Relations/Korda.Orm.Relations.Tests.csproj',
           '-c', 'Release', '-r', 'linux-x64', '-p:PublishAot=true', '-p:RestoreLockedMode=true',
           '-p:IlcTreatWarningsAsErrors=true', '-p:UseSharedCompilation=false', '-m:1', '-nr:false',
           '-p:KordaSqliteAssetPath=' + assets['sqlite']['sourcePath'],
           '-p:KordaPostgresAssetPath=' + assets['postgresql']['sourcePath'], '-o', str(output / 'aot')]
receipt = {
    'scope': 'Mixed-stage development regression: untouched public bc6 managed/test sources republished with native fix 7960d381 identities using normal provider build targets; no safety bypass, no assertion changes. Not a new frozen public package gate.',
    'managedSourceCommit': expected_head, 'nativeSourceCommit': expected_fix,
    'managedSourceTree': git(worktree, 'rev-parse', 'HEAD^{tree}'), 'sourceDirty': False,
    'sourceParityManifestSha256': sha(output / 'source-parity.json'), 'sourceFileCount': len(source_files),
    'testAssertionsModified': False, 'assetIntegrityVerificationEnabled': True,
    'startedUtc': stamp(), 'scriptSha256': sha(__file__),
    'originalExecutableSha256': expected_elf,
    'originalAttempt': str(original), 'originalResultSha256': sha(original / 'result.json'),
    'originalFailureExitCode': 250, 'originalFailureLogSha256': sha(original / 'providers/consumer.log'),
    'nativeOnlyRejectedAttempt': str(rejected), 'nativeOnlyRejectedResultSha256': sha(rejected / 'result.json'),
    'nativeDevelopmentReceiptSha256': sha(native_receipt), 'nativeAssets': assets,
    'publishCommand': publish, 'publishOnlyEnvironment': {'DOTNET_PROCESSOR_COUNT': '1'},
    'workingDirectory': str(worktree), 'runnerSha256': sha(worktree / 'tests/Data.NativeHost/run.py'),
    'environmentScriptSha256': sha(root / 'tools/task-env.sh'),
}
(output / 'input-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
environment = os.environ.copy()
environment['DOTNET_PROCESSOR_COUNT'] = '1'
with (output / 'publish.log').open('w') as stream:
    built = subprocess.run(publish, cwd=worktree, env=environment, stdout=stream, stderr=subprocess.STDOUT)
receipt['publishExitCode'] = built.returncode
receipt['publishFinishedUtc'] = stamp()
receipt['publishLogSha256'] = sha(output / 'publish.log')
if built.returncode:
    (output / 'result.json').write_text(json.dumps(receipt, indent=2) + '\n')
    raise SystemExit(built.returncode)
profile_results = {}
for provider, expected in expected_hashes.items():
    before = output / 'profiles-before' / provider
    after = output / 'profiles-after' / provider
    after.mkdir(parents=True)
    for relative in profiles[provider]:
        shutil.copy2(worktree / relative, after / Path(relative).name)
    code_name, manifest_name = map(lambda p: Path(p).name, profiles[provider])
    previous_code = (before / code_name).read_text()
    current_code = (after / code_name).read_text()
    old_value = old_identities[provider].upper() if provider == 'sqlite' else old_identities[provider]
    new_value = expected.upper() if provider == 'sqlite' else expected
    assert current_code == previous_code.replace(old_value, new_value)
    previous_manifest = json.loads((before / manifest_name).read_text())
    current_manifest = json.loads((after / manifest_name).read_text())
    previous_manifest['sha256'] = expected
    assert current_manifest == previous_manifest
    assert sha(output / 'aot/runtimes/linux-x64/native' / ('libnw_database_' + provider + '.so')) == expected
    profile_results[provider] = {'onlyGeneratedProfileDifference': 'Sha256',
                                 'oldNativeSha256': old_identities[provider], 'newNativeSha256': expected,
                                 'beforeCodeSha256': sha(before / code_name), 'afterCodeSha256': sha(after / code_name),
                                 'beforeManifestSha256': sha(before / manifest_name), 'afterManifestSha256': sha(after / manifest_name)}
receipt['profileDifferences'] = profile_results
executable = output / 'aot/Korda.Orm.Relations.Tests'
receipt['executableSha256Before'] = sha(executable)
assert executable.read_bytes()[:4] == b'\x7fELF'
receipt['allTrackedSourcesStillByteEqualPublicBc6'] = all(sha(worktree / path) == entry['sha256'] for path, entry in source_files.items())
assert receipt['allTrackedSourcesStillByteEqualPublicBc6']
run = ['python3', 'tests/Data.NativeHost/run.py', '--postgres-bin', os.environ['NW_POSTGRES_BIN'],
       '--output', str(output / 'providers'), '--', str(executable), '--require-aot']
receipt['runCommand'] = run
receipt['runStartedUtc'] = stamp()
(output / 'published-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'publishExitCode': built.returncode, 'executableSha256': receipt['executableSha256Before'], 'running': run}), flush=True)
with (output / 'run.log').open('w') as stream:
    result = subprocess.run(run, cwd=worktree, stdout=stream, stderr=subprocess.STDOUT)
receipt['runnerExitCode'] = result.returncode
receipt['finishedUtc'] = stamp()
receipt['executableSha256After'] = sha(executable)
receipt['originalExecutableStillUnchanged'] = sha(original / 'aot/Korda.Orm.Relations.Tests') == expected_elf
receipt['allTrackedSourcesStillByteEqualPublicBc6'] = all(sha(worktree / path) == entry['sha256'] for path, entry in source_files.items())
receipt['nativeAssetsUnchangedDuringRun'] = all(sha(output / 'aot/runtimes/linux-x64/native' / ('libnw_database_' + p + '.so')) == h for p, h in expected_hashes.items())
assert receipt['originalExecutableStillUnchanged'] and receipt['allTrackedSourcesStillByteEqualPublicBc6'] and receipt['nativeAssetsUnchangedDuringRun']
receipt['logs'] = {str(p.relative_to(output)): sha(p) for p in sorted(output.rglob('*.log')) if 'aot' not in p.relative_to(output).parts}
(output / 'result.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'publishExitCode': built.returncode, 'runnerExitCode': result.returncode, 'result': str(output / 'result.json')}))
raise SystemExit(result.returncode)
