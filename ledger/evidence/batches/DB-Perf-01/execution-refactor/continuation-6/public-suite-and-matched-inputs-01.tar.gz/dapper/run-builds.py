from pathlib import Path
import concurrent.futures
import datetime
import hashlib
import json
import os
import subprocess
import sys

ROOT = Path('/workspace/scratch/4a65d70f0fe1')
SOURCE = ROOT / 'worktrees/DB-Exec-02-continuation'
EXPECTED = '4532354b4a316285b21b463f6ca6eda670dd7a49'
OUTPUT = ROOT / 'artifacts/dapper-matched-builds-01.json'

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def build(provider):
    app = ROOT / ('consumers/dapper-matched-' + provider + '-01')
    log = ROOT / ('artifacts/dapper-matched-' + provider + '-01-build.log')
    if app.exists() or log.exists():
        raise RuntimeError('A fresh output is required')
    argv = [sys.executable, 'benchmarks/db-perf/managed/build_orm.py', '--provider', provider,
            '--kind', 'benchmark', '--lifecycle-sql-mode', 'matched', '--output', str(app)]
    environment = os.environ | {'DOTNET_PROCESSOR_COUNT': '1', 'UseSharedCompilation': 'false',
                               'MSBUILDDISABLENODEREUSE': '1'}
    row = {'provider': provider, 'argv': argv, 'cwd': str(SOURCE), 'startedUtc': now()}
    with log.open('xb') as output:
        result = subprocess.run(argv, cwd=SOURCE, env=environment, stdout=output, stderr=subprocess.STDOUT)
    row.update(exitCode=result.returncode, finishedUtc=now(), log=str(log), logSha256=sha(log))
    receipt = app / 'build-receipt.json'
    if receipt.exists():
        row.update(receipt=str(receipt), receiptSha256=sha(receipt))
    print(json.dumps({'provider': provider, 'exitCode': result.returncode, 'receipt': str(receipt)}), flush=True)
    return row

head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=SOURCE, text=True).strip()
tree = subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=SOURCE, text=True).strip()
if head != EXPECTED or subprocess.check_output(['git', 'status', '--porcelain'], cwd=SOURCE, text=True) or OUTPUT.exists():
    raise RuntimeError('The source must be the expected clean checkout and the receipt must be new')
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    results = list(pool.map(build, ('sqlite', 'postgresql')))
record = {'task': 'DB-Exec-07', 'sourceCommit': head, 'sourceTree': tree, 'sourceDirty': False,
          'scope': 'Actual Dapper.AOT generated factories for matched lifecycle SQL; build validation only',
          'performanceCredit': False, 'scriptSha256': sha(__file__), 'results': results,
          'buildOnlyEnvironment': {'DOTNET_PROCESSOR_COUNT': '1', 'UseSharedCompilation': 'false',
                                   'MSBUILDDISABLENODEREUSE': '1'}}
OUTPUT.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'receipt': str(OUTPUT), 'sha256': sha(OUTPUT)}), flush=True)
raise SystemExit(any(row['exitCode'] for row in results))
