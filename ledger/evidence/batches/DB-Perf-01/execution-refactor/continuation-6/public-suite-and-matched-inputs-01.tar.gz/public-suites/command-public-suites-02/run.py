#!/usr/bin/env python3
"""Run retained AOT suites using normal repository drivers and matching dev assets."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from datetime import datetime, timezone

BASE = Path('/workspace/scratch/4a65d70f0fe1')
ROOT = BASE / 'worktrees/DB-Exec-07-fluent-relations'
OUT = BASE / 'validation-evidence/command-public-suites-02'
SOURCE = sys.argv[1]
if len(SOURCE) != 40 or any(c not in '0123456789abcdef' for c in SOURCE):
    raise RuntimeError('Pass the exact clean source commit')
NATIVE_SOURCE = SOURCE
PG = BASE / 'tools/postgres/install/bin'

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()

def now():
    return datetime.now(timezone.utc).isoformat()

OUT.mkdir(parents=True, exist_ok=False)
assert git('rev-parse', 'HEAD') == SOURCE
assert not git('status', '--porcelain')
product_diff = git('diff', '--name-only', NATIVE_SOURCE, SOURCE, '--',
                   'src', 'native/cpp/src', 'native/cpp/include', 'native/database')
assert not product_diff, product_diff
env = os.environ.copy()
env.update(DOTNET_CLI_USE_MSBUILD_SERVER='0', MSBUILDDISABLENODEREUSE='1')
manifests = []
for provider, prop, filename in [
    ('sqlite', 'KordaSqliteAssetPath', 'libnw_database_sqlite.so'),
    ('postgresql', 'KordaPostgresAssetPath', 'libnw_database_postgresql.so')]:
    directory = BASE / ('artifacts/command-dev-native-' + provider + '-02')
    manifest_path = directory / 'manifest.json'
    manifest = json.loads(manifest_path.read_text())
    asset = directory / filename
    assert manifest['sourceCommit'] == NATIVE_SOURCE and not manifest['sourceDirty']
    matched = [item for item in manifest['assets'] if Path(item['path']) == asset]
    assert len(matched) == 1 and sha(asset) == matched[0]['sha256']
    env[prop] = str(asset)
    manifests.append({'provider': provider, 'manifest': str(manifest_path),
        'manifestSha256': sha(manifest_path), 'asset': str(asset), 'assetSha256': sha(asset),
        'sourceCommit': manifest['sourceCommit'], 'sourceTree': manifest['sourceTree'], 'msbuildProperty': prop})

files = git('ls-files', 'src', 'tests', 'native', 'eng', 'Directory.Build.props',
            'global.json', 'NuGet.config').splitlines()
identity = [{'path': p, 'sha256': sha(ROOT / p)} for p in files]
(OUT / 'source-files.json').write_text(json.dumps(identity, indent=2) + '\n')
receipt = {'task': 'DB-Exec-07', 'scope': 'Retained Query.Fluent and Orm.Relations development Native AOT correctness',
    'publicPackageCredit': False, 'performanceCredit': False, 'sourceCommit': SOURCE,
    'sourceTree': git('rev-parse', 'HEAD^{tree}'), 'sourceDirty': False,
    'nativeSourceCommit': NATIVE_SOURCE, 'productSourceDiff': product_diff,
    'sourceFiles': str(OUT / 'source-files.json'), 'sourceFilesSha256': sha(OUT / 'source-files.json'),
    'script': str(Path(__file__).resolve()), 'scriptSha256': sha(__file__),
    'runners': [{'path': p, 'sha256': sha(ROOT / p)} for p in
        ['eng/database_regressions.py', 'eng/build.py', 'tests/Data.NativeHost/run.py',
         'tests/Orm.Relations/compile_negative.py']], 'nativeInputs': manifests,
    'note': 'The outer normal PostgreSQL runner supplies the existing regression-driver prerequisite; each suite itself uses its own inner fresh database through the unmodified normal runner.',
    'startedUtc': now(), 'suites': []}

def save():
    (OUT / 'result.json').write_text(json.dumps(receipt, indent=2) + '\n')

save()
for name, assembly in [('Query.Fluent', 'Korda.Query.Fluent.Tests'),
                       ('Orm.Relations', 'Korda.Orm.Relations.Tests')]:
    directory = OUT / name
    directory.mkdir()
    output = directory / 'regressions'
    command = [sys.executable, 'tests/Data.NativeHost/run.py', '--postgres-bin', str(PG),
        '--output', str(directory / 'bootstrap'), '--', sys.executable, 'eng/database_regressions.py',
        '--design', str(BASE / 'worktrees/DB-Exec-02-design'),
        '--plan', str(BASE / 'worktrees/DB-Exec-02-plan'), '--postgres-bin', str(PG),
        '--native-build', str(BASE / 'worktrees/DB-Exec-07-dev-native/artifacts/cmake/linux-x64-sqlite'),
        '--output', str(output), '--suite', name]
    entry = {'suite': name, 'argv': command, 'cwd': str(ROOT), 'startedUtc': now()}
    receipt['suites'].append(entry)
    save()
    log = directory / 'driver.log'
    with log.open('wb') as handle:
        process = subprocess.run(command, cwd=ROOT, env=env, stdout=handle, stderr=subprocess.STDOUT)
    entry.update(exitCode=process.returncode, finishedUtc=now(), log=str(log), logSha256=sha(log))
    executable = output / name / 'aot' / assembly
    if executable.is_file():
        entry['executable'] = {'path': str(executable), 'sha256': sha(executable), 'bytes': executable.stat().st_size,
                               'elf': executable.read_bytes()[:4] == b'\x7fELF',
                               'dllSibling': executable.with_suffix('.dll').exists()}
    artifacts = []
    for path in sorted(directory.rglob('*')):
        if path.is_file() and path.suffix in ('.log', '.json'):
            artifacts.append({'path': str(path.relative_to(OUT)), 'sha256': sha(path), 'bytes': path.stat().st_size})
    entry['records'] = artifacts
    entry['sourceUnchanged'] = git('rev-parse', 'HEAD') == SOURCE and not git('status', '--porcelain')
    entry['nativeAssetsUnchanged'] = all(sha(p['asset']) == p['assetSha256'] for p in manifests)
    save()
    print(json.dumps({k: entry[k] for k in ('suite', 'exitCode', 'log', 'sourceUnchanged', 'nativeAssetsUnchanged')}), flush=True)

negative = ROOT / 'artifacts/B14/compile-negative'
if negative.is_dir():
    import shutil
    shutil.copytree(negative, OUT / 'Orm.Relations/compile-negative')
receipt['finishedUtc'] = now()
receipt['passed'] = all(x['exitCode'] == 0 and x['sourceUnchanged'] and x['nativeAssetsUnchanged'] for x in receipt['suites'])
save()
print(json.dumps({'result': str(OUT / 'result.json'), 'sha256': sha(OUT / 'result.json'), 'passed': receipt['passed']}), flush=True)
sys.exit(0 if receipt['passed'] else 1)
