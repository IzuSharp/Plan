import hashlib,json,pathlib,shlex,subprocess,time
root=pathlib.Path(__file__).resolve().parents[2]
out=pathlib.Path(__file__).resolve().parent
workspace=root.parents[1]
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
paths=subprocess.check_output(['git','ls-files','src','native','tests/Data.NativeHost','tests/ProviderProfileChecks.cs'],cwd=root,text=True).splitlines()
files={p:sha(root/p) for p in paths if (root/p).is_file()}
assets=[]
for provider in ('sqlite','postgresql'):
    path=workspace/'artifacts'/('command-dev-native-'+provider+'-02')/'manifest.json'
    record=json.loads(path.read_text()); asset=record['assets'][0]
    assert sha(pathlib.Path(asset['path']))==asset['sha256']
    assets.append(asset)
    (out/(provider+'-producer-manifest.json')).write_bytes(path.read_bytes())
parity=subprocess.check_output(['git','diff','--name-only','374a253',source,'--','src','native/cpp/src','native/cpp/include','native/database/binding'],cwd=root,text=True)
assert not parity,parity
input_record={'source':source,'producerSource':'374a253f09f47d0b42f9d18491677158287ba18b','productFilesIdentical':True,'sourceFiles':files,'assets':assets,'scope':'Development Native AOT correctness against two independent no-hook provider assets; no public-package or performance credit.'}
(out/'input.json').write_text(json.dumps(input_record,indent=2)+'\n')
project='tests/Data.NativeHost/Korda.Data.NativeHost.Tests.csproj'
props=['-p:KordaSqliteAssetPath='+assets[0]['path'],'-p:KordaPostgresAssetPath='+assets[1]['path']]
flags=['-m:1','-nr:false','-p:UseSharedCompilation=false']
publish=out/'aot'
commands=[('restore',['dotnet','restore',project,'--locked-mode','-r','linux-x64','-p:PublishAot=true',*flags,*props]),('publish',['dotnet','publish',project,'-c','Release','-r','linux-x64','-p:PublishAot=true','--no-restore','-p:IlcTreatWarningsAsErrors=true',*flags,*props,'-o',str(publish)])]
records=[]
for name,command in commands:
    argv=['bash','-c','source /workspace/scratch/4a65d70f0fe1/tools/task-env.sh\nexec '+shlex.join(command)]
    start=time.time()
    with (out/(name+'.log')).open('wb') as log: result=subprocess.run(argv,cwd=root,stdout=log,stderr=subprocess.STDOUT)
    records.append({'name':name,'argv':argv,'startedUtc':start,'endedUtc':time.time(),'exitCode':result.returncode,'log':name+'.log'})
    (out/'result.json').write_text(json.dumps(records,indent=2)+'\n'); print(name,result.returncode,flush=True)
    if result.returncode: raise SystemExit(result.returncode)
exe=publish/'Korda.Data.NativeHost.Tests'
assert exe.read_bytes()[:4]==b'\x7fELF' and not exe.with_suffix('.dll').exists()
for p,digest in files.items(): assert sha(root/p)==digest,p
for asset in assets: assert sha(pathlib.Path(asset['path']))==asset['sha256']
receipt={'source':source,'executable':str(exe),'sha256':sha(exe),'sourceUnchanged':True,'assetsUnchanged':True,'inputSha256':sha(out/'input.json')}
(out/'build-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('ELF',receipt['sha256'],flush=True)
