import json,pathlib,subprocess,time
root=pathlib.Path(__file__).resolve().parents[2]
out=pathlib.Path(__file__).resolve().parent
base="source /workspace/scratch/4a65d70f0fe1/tools/task-env.sh\nexec "
commands=[('configure','cmake --preset linux-x64-release -DFETCHCONTENT_SOURCE_DIR_NW_JSON=/workspace/scratch/4a65d70f0fe1/tools/native-dependencies/nlohmann-json/json -DFETCHCONTENT_SOURCE_DIR_NW_SQLITE=/workspace/scratch/4a65d70f0fe1/tools/native-dependencies/sqlite/sqlite-amalgamation-3510300'),('build','cmake --build --preset linux-x64-release --target nw_command_completion_tests --parallel 2'),('test','ctest --test-dir artifacts/cmake/linux-x64-release -R "^native.command_completion$" --output-on-failure')]
records=[]
for name,command in commands:
    argv=['bash','-c',base+command]
    started=time.time()
    with (out/(name+'.log')).open('wb') as log: result=subprocess.run(argv,cwd=root,stdout=log,stderr=subprocess.STDOUT)
    records.append(dict(name=name,argv=argv,startedUtc=started,endedUtc=time.time(),exitCode=result.returncode,log=name+'.log'))
    (out/'result.json').write_text(json.dumps(records,indent=2)+'\n')
    print(name,result.returncode,flush=True)
    if name=='test':
        detail=root/'artifacts/cmake/linux-x64-release/Testing/Temporary/LastTest.log'
        if detail.exists(): (out/'test-details.log').write_bytes(detail.read_bytes())
    if result.returncode: raise SystemExit(result.returncode)
