import hashlib,json,pathlib,shlex,subprocess,time
root=pathlib.Path(__file__).resolve().parents[2]
out=pathlib.Path(__file__).resolve().parent
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
receipt=json.loads((out/'build-receipt.json').read_text()); source=json.loads((out/'input.json').read_text())
exe=pathlib.Path(receipt['executable']); assert sha(exe)==receipt['sha256']
records=[]
for label,arguments in [('command-only',['--command-completion-only']),('full',[])]:
    pg=out/(label+'-providers')
    command=['python3','tests/Data.NativeHost/run.py','--postgres-bin','/workspace/scratch/4a65d70f0fe1/tools/postgres/install/bin','--output',str(pg),'--',str(exe),*arguments]
    argv=['bash','-c','source /workspace/scratch/4a65d70f0fe1/tools/task-env.sh\nexec '+shlex.join(command)]
    started=time.time()
    with (out/(label+'.log')).open('wb') as log: result=subprocess.run(argv,cwd=root,stdout=log,stderr=subprocess.STDOUT)
    records.append({'name':label,'argv':argv,'startedUtc':started,'endedUtc':time.time(),'exitCode':result.returncode,'log':label+'.log','executableSha256':sha(exe)})
    (out/'gate-result.json').write_text(json.dumps(records,indent=2)+'\n'); print(label,result.returncode,flush=True)
    if result.returncode: raise SystemExit(result.returncode)
for p,digest in source['sourceFiles'].items(): assert sha(root/p)==digest,p
for asset in source['assets']: assert sha(pathlib.Path(asset['path']))==asset['sha256']
(out/'after-gates.json').write_text(json.dumps({'sourceUnchanged':True,'assetsUnchanged':True,'executableUnchanged':sha(exe)==receipt['sha256'],'gates':records},indent=2)+'\n')
