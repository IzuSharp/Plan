#!/usr/bin/env python3
"""Extract numbered evidence from the already locked local source archives only."""
import hashlib
import json
from pathlib import Path
import re
import tarfile

ROOT = Path('/workspace/scratch/4a65d70f0fe1')
OUT = Path(__file__).resolve().parent / 'upstream'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def excerpt(data, name, pattern, before, after):
    lines = data.decode('utf-8').splitlines()
    matches = [i for i, line in enumerate(lines) if re.search(pattern, line)]
    if len(matches) != 1:
        raise ValueError(f'Expected one source anchor for {name}: {matches}')
    first = max(0, matches[0] - before)
    last = min(len(lines), matches[0] + after + 1)
    target = OUT / name
    text = ''.join(f'{i + 1:6}: {lines[i]}\n' for i in range(first, last))
    if target.exists():
        if target.read_bytes() != text.encode('utf-8'):
            raise ValueError(f'Existing source excerpt differs: {target}')
    else:
        with target.open('x') as stream:
            stream.write(text)
    return {'path': name, 'sourceSha256': sha(data), 'sourceLineStart': first + 1,
            'sourceLineEnd': last, 'sha256': sha(target.read_bytes())}


archive = ROOT / 'tools/postgres/postgresql-18.0.tar.bz2'
required = {
    'postgresql-18.0/src/interfaces/libpq/fe-connect.c':
        ('postgres18-PQtransactionStatus.txt', r'^PQtransactionStatus\(const PGconn \*conn\)', 2, 12),
    'postgresql-18.0/src/interfaces/libpq/fe-protocol3.c':
        ('postgres18-ReadyForQuery.txt', r'^getReadyForQuery\(PGconn \*conn\)', 2, 32),
    'postgresql-18.0/src/backend/tcop/utility.c':
        ('postgres18-commit-command-tag.txt', r'if \(!EndTransactionBlock\(stmt->chain\)\)', 2, 7),
}
result = {'postgresArchive': {'path': str(archive), 'sha256': sha(archive.read_bytes()),
          'upstreamCommit': '3d6a828938a5fa0444275d3d2f67b64ec3199eb7'}, 'excerpts': []}
with tarfile.open(archive, 'r|bz2') as package:
    for member in package:
        if member.name not in required:
            continue
        args = required.pop(member.name)
        entry = excerpt(package.extractfile(member).read(), *args)
        entry['archiveMember'] = member.name
        result['excerpts'].append(entry)
        if not required:
            break
if required:
    raise ValueError('Required locked PostgreSQL source missing')
sqlite = ROOT / 'tools/native-dependencies/sqlite/sqlite-amalgamation-3510300/sqlite3.c'
data = sqlite.read_bytes()
result['sqliteSource'] = {'path': str(sqlite), 'version': '3.51.3', 'sha256': sha(data)}
for args in [
    ('sqlite-query-only-flag.txt', r'^#define SQLITE_QueryOnly\s', 2, 3),
    ('sqlite-query-only-pragma.txt', r'^\s*\{.*"query_only",', 1, 5),
    ('sqlite-pragma-flag-state.txt', r'^  case PragTyp_FLAG: \{', 2, 40),
]:
    entry = excerpt(data, *args)
    entry['source'] = str(sqlite)
    result['excerpts'].append(entry)
with (OUT / 'local-source-excerpts.json').open('x') as stream:
    json.dump(result, stream, indent=2); stream.write('\n')
print(json.dumps({'sourceExtraction': 'passed', 'excerpts': len(result['excerpts']),
                  'receipt': str(OUT / 'local-source-excerpts.json')}))
