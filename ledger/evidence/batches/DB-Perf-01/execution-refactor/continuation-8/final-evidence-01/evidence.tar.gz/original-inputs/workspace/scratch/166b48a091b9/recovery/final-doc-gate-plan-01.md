# Final documentation and gate plan — DB-Exec-11

## Scope and timing

Prepared during the frozen final campaign on 2026-11-26. Only small source/document reads pinned to CPU 8 and remote PR metadata reads were performed. No test, build, benchmark, hash inventory, compression, repository modification or frozen-input modification was performed. This file is a recovery draft for the root agent.

Do not grant final credit from elapsed time or resource samples. Apply the completion edits below only after all four command receipts, business/count/identity/owner checks, post-run frozen-input verification and evidence retention succeed. Record failures as failures; preserve prior snapshots.

## Observed current identities and metadata

- Korda #37 remains open/draft at `17da07e391ba867bbf195baa2e9fdc0bdc0cc0aa`.
- Design #20 remains open/draft at `ca1933e93678039b492f10a8b47045b11827f1a4`.
- Plan #34 now remains open/draft at recovery commit `1cefa51a891a0795f976fc16c430692ab6bd9993`.
- The three PR descriptions still describe older status, despite the latest Plan recovery publication.
- Product tree remains the frozen `bc9087d843d8d741d83d44f53d0b2c5af26dcffc`; documentation completion alone must not change or relabel the measured product.

## Exact current paragraphs to update

Line numbers below identify the files as read for this plan; use the quoted text/section anchors if later insertions move them.

| File | Current paragraph/anchor | Final edit after validated results |
| --- | --- | --- |
| Plan `ledger/evidence/batches/DB-Perf-01/execution-refactor/continuation-8/README.md` | Lines 25–30: first SQLite Korda interval is still running, accepted credit 0/4. Lines 83–88: analysis/archive/review/merges/publication pending. | Prepend a dated final-measurement section with exact four-cell receipt/result links, start/finish times, pass/fail, archive/readback and post-run freeze result. Retain the launch paragraph under an explicitly historical launch checkpoint. Track measurement acceptance separately from still-pending merge/release; update delivery state only when observed. |
| Plan `.../execution-refactor/current-checkpoint.md` | Top lines 1–10: “first SQLite Korda cell is running” and 0/4. | Replace the current top block with the verified latest status and a fixed link to continuation-8 final evidence. Keep everything under “Previous checkpoint retained” unchanged. |
| Plan `ledger/evidence/batches/DB-Perf-01/plan.md` | Top lines 1–10: same running/0/4 recovery block. | Update only the active top block to completed phases, remaining delivery gates and actual stopping rationale. Preserve the old offered-load-running and prior-candidate text under its existing history heading. |
| Plan `ledger/evidence/batches/DB-Perf-01/handoff-linux.md` | Top lines 1–10: same recovery block. | Record completed outputs, exact current refs and next authorized action. Once merged/released, record observed results and stop condition; avoid leaving a restart-long-tests instruction. |
| Design `docs/database/execution-path-17da.md` | Lines 16–20: final continuous credit 0/4; baseline/offered/final evidence “remaining”. Lines 206–208: same-host/four cells/merge/release unrun. | Update the current acceptance boundary with a new fixed Plan evidence link and validated 4/4 only if earned. Separate successful local final observations from pending or observed delivery. Keep product/source links and the rejected 92b experiment intact. Add a short final-measurement/stopping subsection rather than rewriting the original measurements. |
| Design `docs/database/query-semantics.md` | Current intro lines 8–11: successful independent packages but 0/4. | Update the current intro and link to the maintained execution-path record/final Plan evidence. Do not globally replace historical 0/4 or old source statuses below the history boundary. |
| Design `docs/generators/query-generation.md` | Lines 20–24: “Final integrated package gates and controlled performance acceptance remain pending.” | State that exact-17da independent package/AOT gates already passed; link to their source-bound receipt and the actual final local evidence. Preserve separation from method-body capture and avoid announcing a new fixed-query generator API. |
| Design `CURRENT-PHASE.md` | Current lines 10–18 lead with `bc6ba1a` and new public-package acceptance pending; lines 36–41 describe all final evidence as still required. | Prepend or replace the active overview with the actual 17da path and current verified evidence/delivery status. Mark the bc6/DB-Exec-03 paragraph as historical implementation context. Keep the retained queued final-close distinction: rejected 92b is not the formal path. |

Do not edit continuation-7 frozen plans/scripts/receipts, old eight-cell acceptance files, historical final data or verifier thresholds. Keep current evidence arithmetic, failure records and historical records in their existing identities. Existing fixed links to earlier evidence may remain for provenance; add a distinct final-evidence link instead of redirecting every historical link.

## PR descriptions

Use the existing PRs. Re-read their HEADs before any mutation and preserve normal expected-head checks for commits.

- **Korda #37:** preserve its accurate current implementation and correctness summary. Replace “当前候选会重新执行…” and final 0/4 in “性能与交付状态” with the actual short-baseline/final results, evidence URL, honest remaining gaps and delivery state. Link continuation-8, not only continuation-7.
- **Design #20:** replace current links to Plan `b748d89` and Design `4a6bb899` with published final current records. The paragraph naming 8058128/31693e3/933d16b describes historical short runs; retain that history in Plan rather than presenting it as the current candidate. Replace the old successful-CI links and “prospective one-shot” implications with current source-specific status. Do not describe a draft as ready/merged before that transition occurs.
- **Plan #34:** replace continuation-5 as the current checkpoint with continuation-8. Its paragraph “new one-shot implementation is under local correctness validation” is obsolete for 17da. Lead with exact final evidence and source/package identities, keep historical failures linked, and state separately whether merge, main CI and each provider publication are observed or pending.

Publish the final Plan evidence first, then bind Design and PR links to its actual returned commit SHA. Do not guess a future commit SHA. Avoid a circular requirement that a commit prove its own future CI; capture that CI in a later observed delivery receipt or PR metadata.

## Existing local Design gates (after final edits, never during timing)

Run once from the edited Design worktree with full Git history, preserving actual command, cwd, source/tree, stdout, exit status and time:

```sh
python3 tools/verify_db_rename.py
python3 tools/verify_db_scope_history.py
git diff --check
```

These are the unchanged commands in `public-api-design.yml` and `english-translation.yml`. The first includes `docs/generators/query-generation.md` in its current-name check and runs the unchanged Fluent/C++/scope chain from frozen Design `fcc2b3599066a467ce3d8bf52e4753bdeea6cd86`. The second creates its historical worktree at Design `c62cdb8aee833b6ab1a03e29a3f59f81a1b483f9` and runs `verify_public_api.py --history --require-acceptance` plus `contract_acceptance_checks.py`. Let the wrappers select those immutable scopes; do not run old acceptance directly against changed current Design content.

Document gates validate documentation/history only. They do not replace public-package correctness, the four-cell analyzer or final owner/identity evidence.

## Existing Plan gate scope

**Do not run current-tree `tools/verify_db_perf.py --korda-source ...` as a current-campaign gate.** That already failed its historical `validate_history` allowlist because later repository-rename workflow maintenance is outside the old scope. The failure is preserved in continuation-7 `current-measurements/document-gates-01/`; no rule should be changed to accept the current tree.

The existing Plan workflow `.github/workflows/native-slices-final-check.yml` deliberately uses the following fixed worktrees and commands:

| Scope / fixed commit | Exact existing command |
| --- | --- |
| DB-Perf Plan `38f8ce8a01f88e6e4c4459926f197c5438c2f6fc` | `python3 tools/verify_db_perf.py` |
| DB-Rename Plan `bc1956936ee77a997a016856c97def6aabc0bbc6` | `python3 tools/verify_db_rename.py` |
| DB-CPP Plan `5be447a868be78713ada52f46cee16409f0edc13` | `python3 tools/verify_db_cpp.py --require-complete` |
| DB-Scope Plan `1fe52a8bd792ccdbb4bbea17ba59b0ad0c24349d` | `python3 tools/verify_db_scope.py` |
| Historical Plan `8afa0311f45ab8a8157fc45c51e95a0b17dd09f2`, paired with Design `c62cdb8aee833b6ab1a03e29a3f59f81a1b483f9` in sibling `NativeWeave-Design` | Exact unchanged provenance/graph command block at workflow lines 111–135. |

The historical block runs `verify_public_api_history.py`, `verify_public_api_plan.py`, `prepare_acceptance.py verify-contracts`, `prepare_acceptance.py verify-tasks`, `binding_attestation_checks.py`, `verify_completion.py --require-complete`, `verify_research_assets.py`, `verify_logical_admission_history.py`, `verify_source_lifecycle.py`, `source_lifecycle_binding_checks.py`, `validate_graphs.py --output verification/graph-validation.json`, `mutation_checks.py`, `host_selection_checks.py`, `rust1100_checks.py`, and the existing Draft202012 graph schema validation. It also validates the historical DB-Perf acceptance schema in the frozen DB-Perf worktree, not the current campaign.

The existing frozen DB-Perf local receipt already records exit 0 at `/tmp/DB-Exec-10-plan-perf-history-01` (exact 38f8ce8; 13 record controls and four source-reference controls). That untouched historical success remains valid evidence. Reuse it unless a required gate or concrete changed input calls for a repeat. If a final local replay is required, run the same command in a task-marked detached worktree at exactly 38f8ce8; do not apply current source arguments or change historical files. No need to duplicate every unchanged historical suite locally merely because new result prose was added; the unchanged normal PR/main workflow will execute its fixed scopes.

Run `git diff --check` for the current Plan edit. There is no newly discovered existing current-tree document verifier that accepts the DB-Exec-11 campaign. Its acceptance is the already frozen arithmetic analyzer, identity/owner supplement, raw evidence and post-run freeze checks. Record their real invocations independently rather than inventing a new acceptance status or broad new CI gate.

## Delivery and stopping statements

Before normal merge, use the already saved exact product impact receipt and verify product/measurement identity remains unchanged; documentation edits do not justify rerunning local benchmarks or changing product CI. After merge, observe the existing CI at actual merged SHAs. Korda main independently reconciles package inputs against NuGet, chooses each next preview, verifies candidate bytes, publishes only under the existing enabled conditions, reads back the registry package, and executes its public Native AOT consumer. Report both provider outcomes separately.

Keep these limits in the final text: framework-only managed 0 B is unproven; mapper/List scopes cannot be subtracted to manufacture framework allocation; measured-window GC and full-process-lifetime GC are distinct; per-component cost and every possible optimization are not exhausted; arbitrary Fluent method generation and physical statement caches are not implemented; the rejected quiet-close experiment retains its prospective rule and failure. Use the final evidence to explain completed work, measured before/after gains, Dapper gaps and why this round stops. Successful long runs alone do not prove zero allocation or optimality.
