# Final Design status and PR #20 draft — DB-Exec-11

## Independent result-scope review

Reviewed the completed `final-analysis-01.json`, `final-identity-audit-01.json`, `final-metrics-01.json`, all four underlying ordinary raw result JSON files, and the retained SQL/GC scope reviews. No benchmark, build, new test, hash inventory or repository modification was performed for this review.

The reports agree on four complete 1,800-second raw intervals, all 35 business cases, no missing seconds or seconds without business/row progress, zero failed admitted operations/oracle failures, and serial execution including recorded idle. The identity/owner supplement passes with 394 unchanged observed inputs, including the previously frozen input set; both Korda runs return all eight recorded owner categories to zero. Dapper records zero application-owned logical connections after disposal; that is not an internal-driver owner inventory.

The arithmetic report deliberately says `taskAcceptance = "Not decided by this arithmetic report."` Its four-cell decision establishes measurement completeness, not performance parity, a zero-allocation target, merge or publication. Normal reviewed delivery remains pending at this cut.

### Reporting constraints verified against the results

- Each provider comparison has 35 recorded diagnostic SQL text differences, `rawSqlByteEqual=false`, matching business contracts, no setting differences, and `comparableBusinessWorkload=true`. The retained static/source and actual generated-factory audit accounts for provider parameter markers and matched lifecycle bindings; `runtimeSqlTraceVerified=false` remains explicit. Do not claim byte-identical SQL for all 35 cases or an observed server wire trace.
- Successful throughput includes the admitted drain tail. Final throughput ratios are about 90.40%/94.66% of Dapper at the selected offered rates; this is not a maximum-throughput ratio because the arrivals cap the reference workload.
- Offered latency includes producer scheduling, queueing and service for successful admitted operations. Rejected arrivals are counted separately and are not silently added to the latency histogram. Histogram percentiles are upper-bin bounds.
- CPU is application CPU over the steady/drain endpoints, not complete PostgreSQL server CPU. Peak RSS is a process-lifetime high-water; idle RSS is observed after disposal without forced GC. The nominal 15-second idle is an observed duration (the last Dapper idle is 14.999423321 seconds), not a fabricated exact interval.
- Managed B/success includes business objects/strings/JSON, harness, framework and driver. Framework-only attribution remains null. Process-wide GC deltas span steady work through drain; absolute GC counters at offered-end are separately present. Neither is the unrecorded cumulative count at final process exit.
- FFI and required protocol-reply counts were not instrumented in the ordinary final runs. Use the separate source-bound diagnostics; never derive RTT from libpq send/protocol-submission counts.
- Same recorded host and nonoverlap are proven by these receipts, but exclusive physical hardware and hidden cgroup quotas remain unproven.

## Publication instruction for the following exact text

`FINAL_PLAN_COMMIT` is a draft-only token. Substitute the actual public final-evidence Plan commit returned by publication before applying any snippet to Design or a PR. All new Plan links deliberately target the existing continuation-8 README, which must navigate to the final arithmetic, identity, raw-archive/readback and review records. Keep existing fixed product/package/upstream source links unchanged.

## Design: execution-path-17da.md — current acceptance paragraph

Replace the paragraph beginning “The independent package receipt” through “does not inherit historical long runs” with:

```markdown
The [independent package receipt][packages] records successful builds and external
Native AOT consumption of both independent provider packages. The
[final local evidence][final-evidence] now records **4/4 complete continuous
1,800-second cells** for the exact 17da candidate and matched Dapper.AOT, with
serial execution including recorded post-disposal idle. The campaign finished
on 2026-11-26 at 18:39:24 Asia/Shanghai. All four runs covered 35/35 business
cases with zero failed admitted operations and zero business-oracle failures;
rejected arrivals remain explicit. The identity/owner supplement passed with
394 unchanged observed inputs, including the original 373 frozen inputs, and
all eight recorded Korda owner categories returned to zero for both providers.

This completes the requested local four-cell measurement evidence. It does not
establish performance parity, framework-only 0 B, or byte-identical diagnostic
SQL across every mixed-workload case. Normal reviewed merges, main CI and
rule-selected publication/public NuGet consumption remain pending at this
checkpoint. The original [campaign selection][campaign] and all historical
long-run records retain their own identities.
```

Add the link definition:

```markdown
[final-evidence]: https://github.com/IzuSharp/Plan/blob/FINAL_PLAN_COMMIT/ledger/evidence/batches/DB-Perf-01/execution-refactor/continuation-8/README.md
```

## Design: execution-path-17da.md — new subsection before remaining limits

Insert after the implemented independent-provider discussion and before “The following limits remain explicit”:

```markdown
## Final local observations and comparison scope

The final offered load was 3,000 arrivals/s with concurrency 4 for SQLite and
3,600 arrivals/s with concurrency 8 for PostgreSQL. Each cohort ran alone for
1,800 seconds; the next cohort started only after the preceding process and its
recorded post-disposal idle completed. The full raw ledger and ordinary
same-SQL phase observations remain in [Plan][final-evidence].

| Provider / cohort | Successful operations/s through drain | Rejected arrivals | Offered p50 / p95 / p99 (ms, histogram upper bounds) | Total managed B/success |
| --- | ---: | ---: | --- | ---: |
| SQLite / Korda 17da | 2,706.936 | 527,440 / 5,400,000 | 20.185 / 33.423 / 49.545 | 24,790.092 |
| SQLite / Dapper.AOT | 2,994.376 | 10,114 / 5,400,000 | 0.208 / 3.031 / 8.585 | 7,431.767 |
| PostgreSQL / Korda 17da | 3,400.012 | 359,927 / 6,480,000 | 14.877 / 27.132 / 38.273 | 25,490.045 |
| PostgreSQL / Dapper.AOT | 3,591.997 | 14,376 / 6,480,000 | 0.371 / 3.326 / 8.520 | 7,316.433 |

All four have zero failed admitted operations. Rejections are separate outcomes;
offered percentiles describe successful admitted operations and include
scheduling/queueing, rather than rejected arrivals. Korda's successful throughput
was 90.40% and 94.66% of Dapper at these offered rates. These are rate-limited
completion comparisons, not independently measured maximum-throughput ratios.
Its offered p99 was 5.77 times and 4.49 times Dapper, and total managed
B/success was 3.34 times and 3.48 times Dapper respectively.

The preceding same-condition **120-second** before/current supplement is separate:
SQLite improved from 542.872 to 2,668.577 successful operations/s and PostgreSQL
from 1,241.453 to 3,458.224. Those paired short observations, their failures and
rejections, and their exact source identities are retained; the old baseline is
not relabelled as a new 30-minute baseline.

Each final provider comparison retains 35 diagnostic SQL text differences.
Ordinary statements largely differ in provider parameter markers, while some
lifecycle records compare historical descriptions with explicit SQL. The pinned
source and actual generated-command-factory audit establish the matched
lifecycle parameter types/value bindings and allowed normalization. They do not
erase the raw differences or establish an observed server wire trace;
`runtimeSqlTraceVerified=false` remains explicit. Equal business assertions and
digests do not by themselves prove byte-identical SQL.

The final CPU, RSS, allocation and GC records keep their actual scopes:
application steady/drain CPU; process-lifetime peak RSS and observed idle RSS;
whole-process managed allocations and GC deltas for the measurement window;
and separately recorded cumulative GC at offered-end. Final process-exit GC
and a complete PostgreSQL server CPU total were not recorded. Business output,
harness, framework and driver allocations are not separated by subtraction.
```

Replace only the last pending-work bullet (currently “Same-host before evidence, offered-load validation…”):

```markdown
- Same-host before/current evidence, offered-load validation and four serial
  1,800-second cells are now recorded in the final Plan evidence. Normal reviewed
  merges, main CI and public publication/consumption remain separate delivery
  observations and are pending at this checkpoint.
```

Keep the existing 0 B, per-component-cost, generator/cache, scope and rejected-experiment limitations. Add this stopping paragraph after the existing stopping rationale:

```markdown
This round has completed the selected path replacement, its public-package
correctness checks and the requested final local observations. The narrower
quiet-close experiment remains rejected under its original prospective rule;
its results do not justify replacing the tested 17da path. The final evidence
supports the recorded gains over the before candidate and exposes the remaining
Dapper latency, refusal, CPU and allocation gaps. No further product change is
selected by this checkpoint. Stopping after normal delivery does not claim that
all possible optimizations have been exhausted or that framework-only 0 B has
been achieved.
```

## Design: query-semantics.md — current intro only

Replace the opening current-status paragraph (after the title; before “Current integrated candidate”) with:

```markdown
The [implemented 17da execution path](execution-path-17da.md) is the current
driver-to-Fluent review: it identifies actual public entries, reuse/rewrite/delete
decisions, retained costs, fixed upstream/generated sources and contract tests.
CursorPull, typed command completion and fixed-key Find are implemented in that
source. Both independent provider packages completed their recorded
correctness/AOT gates, and the [final local evidence](https://github.com/IzuSharp/Plan/blob/FINAL_PLAN_COMMIT/ledger/evidence/batches/DB-Perf-01/execution-refactor/continuation-8/README.md)
now records four complete serial 1,800-second cells with source/owner checks.
Normal merges, main CI and public publication/consumption remain pending.
The 35 diagnostic SQL text differences per provider, framework-only 0 B and
remaining cost limits are explicit in that evidence; final measurement completion
is not parity or optimality. The rejected 92b close-dispatch experiment does not
replace the formal 17da path. Earlier implementation-pending tables below retain
their historical checkpoint meaning.
```

## Design: query-generation.md — section 2 evidence paragraph

Replace “Actual pinned reference factories/readers…” through “This refactor does not announce…” with:

```markdown
Actual pinned reference factories/readers and external Native AOT consumers
are bound in the [implemented 17da record](../database/execution-path-17da.md).
Both independent provider package gates passed, and the
[final local evidence](https://github.com/IzuSharp/Plan/blob/FINAL_PLAN_COMMIT/ledger/evidence/batches/DB-Perf-01/execution-refactor/continuation-8/README.md)
records four complete serial 1,800-second cells. Normal merges, main CI and
public publication/consumption remain pending. Total measured managed allocation
includes business output, harness, framework and driver; framework-only 0 B is
not established. Stable parameter ordinals and value writing remain separate
from arbitrary Fluent-method capture. This refactor does not announce a new
public fixed-query generator API.
```

## Design: CURRENT-PHASE.md — new current section

Prepend the following and place the existing first section below “Previous implementation checkpoint retained” without changing its historical source claims:

```markdown
# Current phase — DB-Exec-11 final local evidence complete

The formal candidate is Korda
[`17da07e391ba867bbf195baa2e9fdc0bdc0cc0aa`](https://github.com/IzuSharp/Korda/commit/17da07e391ba867bbf195baa2e9fdc0bdc0cc0aa),
tree `bc9087d843d8d741d83d44f53d0b2c5af26dcffc`. The
[implemented driver-to-Fluent record](docs/database/execution-path-17da.md)
identifies the selected command, value, batch, generated-reader, completion and
Find paths while preserving public Fluent behavior, Native AOT, C++ execution
and independently installable PostgreSQL/SQLite packages.

Both package correctness/AOT gates passed. The
[final local campaign](https://github.com/IzuSharp/Plan/blob/FINAL_PLAN_COMMIT/ledger/evidence/batches/DB-Perf-01/execution-refactor/continuation-8/README.md)
completed four serial 1,800-second cells, including recorded post-disposal idle,
on 2026-11-26 at 18:39:24 Asia/Shanghai. All 35 business cases were covered in
each cell, all admitted operations completed without business errors, and
rejections remain explicit. The unchanged source/identity/owner supplement
passed; both Korda runs returned all eight recorded owner categories to zero.

This is completed local measurement evidence, with the recorded SQL text,
resource-scope and allocation limitations. The raw comparisons retain 35
SQL-description differences per provider and no observed wire-SQL trace.
Framework-only 0 B, Dapper parity and exhaustion of every potential optimization
are not established. The rejected quiet-close experiment remains unselected.
Normal reviewed merges, existing main CI and rule-selected public publication
and Native AOT consumption are the remaining delivery actions. Performance work
remains local; existing diff/module CI selection is unchanged.

## Previous implementation checkpoint retained
```

## Exact replacement PR #20 body

The following body replaces the stale continuation-5 description after actual final Plan publication. Keep the PR draft flag until the separate ready-for-review operation is appropriate; the body does not claim that transition already happened.

```markdown
## Implemented database execution path and completed local measurements

This PR documents the implemented C# Fluent → C++ Host → libpq/sqlite3 refactor
at Korda [`17da07e391ba867bbf195baa2e9fdc0bdc0cc0aa`](https://github.com/IzuSharp/Korda/commit/17da07e391ba867bbf195baa2e9fdc0bdc0cc0aa),
tree `bc9087d843d8d741d83d44f53d0b2c5af26dcffc`. It preserves public Fluent
behavior, Native AOT, C++ execution and two independently installable providers.

- [Implementation #37](https://github.com/IzuSharp/Korda/pull/37)
- [Current final evidence and review](https://github.com/IzuSharp/Plan/blob/FINAL_PLAN_COMMIT/ledger/evidence/batches/DB-Perf-01/execution-refactor/continuation-8/README.md)
- [Implemented driver-to-Fluent record](https://github.com/IzuSharp/Korda-Design/blob/task/DB-Perf-01-query-optimization/docs/database/execution-path-17da.md)

### What the Design now binds

The record identifies actual public entries, fixed upstream and real generated
consumer sources, historical guarantees mapped to maintained C++ tests, and each
selected reuse, rewrite or deletion. It covers direct typed argument ownership
without the second native NWDB round trip, direct bounded batch construction,
generation-scoped typed reading, private cursor pull, independent command
completion, Source-owned fixed-key Find and the narrow PostgreSQL pre-COMMIT
state proof. Native semantic traversal, snapshots, safety checks and independent
retirement fences that still have a contract remain explicit.

PostgreSQL retains fresh metadata before Execute and SQLite retains no-step-at-open
behavior. Arbitrary fixed Fluent method-body generation and physical statement
caches are not announced. The failed already-released final-close experiment is
preserved and unselected; formal 17da keeps its tested queued final-close path.

### Actual final local evidence

All four sequential Linux x64 Release Native AOT cells completed their full
1,800-second offered intervals, with no overlap including recorded post-disposal
idle. Each covered 35/35 business cases with zero failed admitted operations and
zero oracle failures. The identity/owner audit passed with 394 unchanged observed
inputs, including the original 373 frozen files; both Korda runs returned all
eight recorded owner categories to zero. Dapper returned its recorded
application-owned connections to zero. No historical long run is credited here.

| Provider | Korda successful op/s | Dapper.AOT successful op/s | Korda / Dapper rejected arrivals | Korda / Dapper offered p99 ms |
| --- | ---: | ---: | --- | --- |
| SQLite, C4 / 3,000 arrivals/s | 2,706.936 | 2,994.376 | 527,440 / 10,114 of 5,400,000 | 49.545 / 8.585 |
| PostgreSQL, C8 / 3,600 arrivals/s | 3,400.012 | 3,591.997 | 359,927 / 14,376 of 6,480,000 | 38.273 / 8.520 |

Throughput includes the admitted drain tail. Offered percentiles are histogram
upper bounds for successful admitted work and include scheduling/queueing;
rejected arrivals remain separate. These fixed-rate completion comparisons are
not maximum-throughput measurements. The separate same-condition 120-second
before/current supplement improved SQLite from 542.872 to 2,668.577 op/s and
PostgreSQL from 1,241.453 to 3,458.224 op/s, with its exact sources and refusal
counts preserved.

### Limits and delivery state

Each final provider comparison preserves 35 diagnostic SQL text differences.
Pinned source and emitted command-factory checks cover allowed placeholder
normalization and matched lifecycle parameter bindings; they do not establish
byte-identical diagnostic SQL or an observed server wire trace.
`runtimeSqlTraceVerified=false` remains explicit.

Korda total managed allocation is 24,790.092 B/success on SQLite and
25,490.045 B/success on PostgreSQL, compared with 7,431.767 and 7,316.433 for
Dapper.AOT. These totals include business output, harness, framework and driver;
framework-only 0 B is unproven. CPU/RSS and both GC scopes remain in the linked
report with their actual boundaries; final process-exit GC, full server CPU and
every retained component's isolated cost are not inferred. The remaining
latency, refusal, CPU and allocation gaps are explicit, and rejecting one
experiment does not prove that all optimization opportunities are exhausted.

The requested local measurements are complete. Final review, normal merges,
existing main CI, rule-selected NuGet publication/readback and actual public
Native AOT consumption remain separate pending delivery observations at this
checkpoint. All benchmarks, calibration, profiling and pressure work ran locally;
no performance workflow, job, button, schedule or hidden CI load was added.
Historical source records, failures, acceptance inputs and verifier thresholds
remain unchanged.
```
