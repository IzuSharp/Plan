# Prospective final evidence archive procedure

Prepared on 2026-11-26 by `plan_freeze_audit` from lightweight source and prior
receipt reading on CPU 8. **This is a proposal, not an executed archive or a new
acceptance gate.** Do not execute its code while the final campaign is running.

## Existing tool and schema

The tool is
`/workspace/scratch/fd78534029f7/worktrees/DB-Exec-10-plan/ledger/evidence/batches/DB-Perf-01/execution-refactor/continuation-7/current-measurements/tools/archive_measurement_evidence.py`.
Reviewed SHA-256:
`0e3d18c4c67072c119cba0477fc2ead22f60ab6c0c722a40dbee1960f195be3b`.

Required arguments: `--measurements PATH`, at least one
`--inventory JSON POINTER EXPECTED_JSON_SHA256`, and `--output-dir PATH`.
Repeatable optional arguments: `--retain-file PATH`, `--retain-root PATH`,
`--exclude-file REASON PATH`, `--exclude-root REASON PATH`; `--scope` is text.
Allowed reasons: `database`, `package`, `binary`, `package-cache`,
`binary-build-output`.

The inventory pointer must resolve to a nonempty **object mapping absolute paths
to lowercase 64-character SHA-256 strings**. The freeze and successful final
identity audit have this shape. The arithmetic report's `inputFiles` is an
**array of identity objects**, so convert its `path`/`storedSha256` entries and
require `storedSha256 == contentSha256`. Reject conflicting hashes for a shared
path. The helper retains each inventory document and its own source automatically.

The prior pre-final operation used the full measurement tree, a 1,225-entry
merged inventory and nine explicit stopped-database archive exclusions. Its
receipt records 1,391 archived originals, 66 exclusions and successful readback
and original rehash. Existing archive SHA-256:
`544bcb1e77fd48fd04c74f1f6edf800431ca4ffac55c59b78d4b491ecc2eea5d`;
manifest SHA-256:
`26f6b469978c66d838f55b7b22216a8a41bacd372301af6d396112d6beb29f81`.
These are historical facts, not claims about the proposed final operation.

## Exact roots, output and exclusions

| Role | Path |
| --- | --- |
| Main measurement root | `/workspace/scratch/fd78534029f7/measurements/sqlite-final-01` |
| Additional final root | `/workspace/scratch/fd78534029f7/measurements/postgresql-final-01` |
| Recovery/report root | `/workspace/scratch/166b48a091b9/recovery` |
| New merged inventory | `/workspace/scratch/166b48a091b9/recovery/final-evidence-inputs-01.json` |
| Fresh archive output | `/workspace/scratch/166b48a091b9/final-evidence-01` |
| Invocation logs outside retained roots | `/workspace/scratch/166b48a091b9/archive-control-01` |

The two final roots retain all raw results, command receipts, resource JSONL,
stdout, fixture/runner/server metadata and failure sidecars. The recovery root
retains host, supervisor, rehash, reviews, final analysis/index/audit, CI/impact
and extracted earlier results. Stop all writers to those roots first.

The merged inventory supplies exact copied/generated source, project files,
restore/publish logs, package/native validation text, frozen scripts and binary
identities without walking whole build, tool or consumer directories. The
pre-final archive plus its manifest, receipt, command and README are explicitly
pinned as an archival dependency, preserving earlier phase/allocation/calibration/
baseline/rejected-experiment context without rescanning every original fixture.

Exclusion rules:

- Explicitly classify only
  `/workspace/scratch/fd78534029f7/measurements/postgresql-final-01/pgdata` as a
  database root, after PostgreSQL has stopped. Surrounding owner/stdout/startup
  records stay included.
- SQLite files and recognized `-wal`/`-shm`/`-journal` sidecars are automatically
  excluded by header/name.
- Package files and compiled ELF/PE/native/object/static-library/symbol files
  are automatically excluded as bytes but retain original paths, sizes and
  actual hashes. ELF core dumps remain failure evidence.
- The three explicit package-cache roots in the command below classify only
  inventoried package files. The preparation code rejects an inventoried
  non-package text file under those roots rather than accidentally excluding
  provenance text.
- Do not blanket-exclude `obj`, `out`, `builds`, `consumers` or `tools`; generated
  code, JSON metadata and validation logs can live beside binaries. Automatic
  binary classification suffices for the frozen binary inputs.
- `--exclude-root` does **not** prune traversal or skip hashes. Every registered
  excluded file is still read and hashed twice. Therefore do not retain a giant
  cache root only to exclude it again. Explicit exclusion roots classify already
  registered files; they do not walk an otherwise unretained external tree.
- Old `retained-databases` lies outside the selected final roots and is not
  rescanned. Its prior exclusion records remain inside the pre-final dependency;
  no new hard-coded count of nine is assumed.

Output must be outside every retained root, its parent must already exist and
its own directory must be absent. The helper rejects `.git` or a directory
symlink in a retained tree. Do not write archive logs inside `recovery` while
archiving: changing that root would correctly fail its final consistency check.
Publish the outside invocation logs beside the finished archive afterward.

## Inventory shape

The generated document will contain `schemaVersion`, a retention-only `scope`,
`sourceInventories` (each document path/hash/field/shape/count), `explicitFiles`
(path/hash), and `inputFiles` (absolute-path-to-hash dictionary). Actual counts
and hashes are generated only after the required final documents exist. It does
not contain its own hash; the archive invocation supplies that hash separately.

## Step 1 — generate the union after campaign, audits and reviews complete

This code expects `final-analysis-01.json`, `final-analysis-01.md`,
`final-index-01.json` and `final-identity-audit-01.json` in `recovery`.
If a producer uses another filename, inspect and record the actual name before
adapting the proposed command. Do not alter frozen tools to satisfy a guessed
filename. No raw resource JSONL is read by this inventory preparation.

```bash
taskset -c 8 python3 - <<'PY'
from pathlib import Path
import hashlib
import json
import re

recovery = Path('/workspace/scratch/166b48a091b9/recovery')
measurements = Path('/workspace/scratch/fd78534029f7/measurements')
prior = Path('/workspace/scratch/fd78534029f7/worktrees/DB-Exec-10-plan/ledger/evidence/batches/DB-Perf-01/execution-refactor/continuation-7/current-measurements/pre-final-evidence-01')
target = recovery / 'final-evidence-inputs-01.json'
assert not target.exists(), 'Use a fresh inventory; never overwrite evidence'
sha_pattern = re.compile(r'[0-9a-f]{64}\Z')
inputs, origins, explicit = {}, [], []

def add(path, digest):
    path = str(path)
    assert Path(path).is_absolute() and '..' not in Path(path).parts, path
    assert isinstance(digest, str) and sha_pattern.fullmatch(digest), path
    assert path not in inputs or inputs[path] == digest, 'Conflicting identity: ' + path
    inputs[path] = digest

def pin(path, expected=None):
    path = Path(path)
    data = path.read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    assert expected is None or digest == expected, 'Document changed: ' + str(path)
    add(path, digest)
    return data, digest

def inventory_document(path, shape, expected=None):
    raw, digest = pin(path, expected)
    document = json.loads(raw)
    source = document['inputFiles']
    if shape == 'object':
        assert isinstance(source, dict) and source
        entries = source.items()
    else:
        assert shape == 'identity-array' and isinstance(source, list) and source
        assert len({x['path'] for x in source}) == len(source)
        assert all(x['storedSha256'] == x['contentSha256'] for x in source)
        entries = [(x['path'], x['storedSha256']) for x in source]
    for original, digest_value in entries:
        add(original, digest_value)
    origins.append({'path': str(path), 'sha256': digest, 'field': '/inputFiles',
                    'shape': shape, 'entries': len(source)})
    return document

freeze_sha = 'fc1dae9be0a76b0de38c4f94c3836e47b398e10b5ff23f3c8f82313a3cb4bc1a'
freeze = inventory_document(measurements / 'final-freeze-01.json', 'object', freeze_sha)
assert freeze['status'] == 'frozen' and len(freeze['inputFiles']) == 373

audit = inventory_document(recovery / 'final-identity-audit-01.json', 'object')
assert audit['status'] == 'passed' and audit['inputsUnchanged'] is True
assert len(audit['segments']) == 4 and audit['freeze']['sha256'] == freeze_sha
analysis_path = recovery / 'final-analysis-01.json'
assert audit['arithmeticReport']['path'] == str(analysis_path)
analysis = inventory_document(analysis_path, 'identity-array', audit['arithmeticReport']['sha256'])
assert analysis['inputsChangedDuringAnalysis'] == []
assert analysis['finalFour']['fourCompleteRawReceipts'] is True
assert analysis['finalFour']['sameHostAndSerialIncludingRecordedIdle'] is True
assert analysis['index']['path'] == str(recovery / 'final-index-01.json')
pin(recovery / 'final-index-01.json', analysis['index']['storedSha256'])

supervisor = json.loads((recovery / 'campaign-supervisor-01.json').read_text())
assert [x['provider'] for x in supervisor['runs']] == ['sqlite', 'postgresql']
assert all(x['status'] == 'completed' and x['exitCode'] == 0 and x['finishedUtc']
           for x in supervisor['runs']), 'Wait for both complete provider runners'
required_recovery = [
    'final-index-01.json', 'final-analysis-01.json', 'final-analysis-01.md',
    'final-identity-audit-01.json', 'campaign-supervisor-01.json',
    'host-before-final-recovery-01.json', 'frozen-input-rehash-before-01.json',
    'observe_campaign.py', 'review-freeze-01.md', 'review-design-ci-01.md',
    'review-implementation-01.md', 'preexisting-measurement-summary-01.json',
    'preexisting-measurement-summary-01.md', 'final-archive-plan-01.md',
    'impact-current-01.json', 'impact-current-01.receipt.json',
    'remote-checkpoint-and-ci-01.json', 'recovery-publication-01.json',
]
for name in required_recovery:
    path = recovery / name
    _, digest = pin(path)
    explicit.append({'path': str(path), 'sha256': digest})
prior_expected = {
    'evidence.tar.gz': '544bcb1e77fd48fd04c74f1f6edf800431ca4ffac55c59b78d4b491ecc2eea5d',
    'manifest.json': '26f6b469978c66d838f55b7b22216a8a41bacd372301af6d396112d6beb29f81',
    'receipt.json': None, 'command.json': None, 'README.md': None,
}
for name, expected in prior_expected.items():
    path = prior / name
    _, digest = pin(path, expected)
    explicit.append({'path': str(path), 'sha256': digest})
package_roots = [
    Path('/workspace/scratch/4a65d70f0fe1/tools/nuget-packages'),
    Path('/workspace/scratch/fd78534029f7/builds/candidate-sqlite-02/consumer-workload/packages'),
    Path('/workspace/scratch/fd78534029f7/builds/candidate-postgresql-02/consumer-workload/packages'),
]
for name in inputs:
    path = Path(name)
    if any(path == root or root in path.parents for root in package_roots):
        assert path.suffix.lower() in ('.nupkg', '.snupkg'), \
            'Review cache exclusion before omitting inventoried text: ' + name
result = {
    'schemaVersion': 1,
    'scope': 'Final completed evidence union; retention only, no new acceptance credit. Historical pre-final archive is retained as an identified dependency.',
    'sourceInventories': origins, 'explicitFiles': explicit,
    'inputFiles': dict(sorted(inputs.items())),
}
with target.open('x') as stream:
    json.dump(result, stream, indent=2, ensure_ascii=False, allow_nan=False)
    stream.write('\n')
print(json.dumps({'inventory': str(target), 'sha256': hashlib.sha256(target.read_bytes()).hexdigest(),
                  'entries': len(inputs), 'archiveCreated': False}))
PY
```

This successful-final procedure must not be used by bypassing a failed audit.
Preserve such a report in a separately labeled failed-attempt archive using its
`checkedInputFiles`, with no final acceptance claim.

## Step 2 — invoke the unchanged helper with actual command/exit records

This code runs only after Step 1 and creates fresh output/control directories.
The five prior archive files are registered through the inventory, so no
additional retain arguments are necessary for them. CPU affinity is inherited
from `taskset -c 8`. No command output is written under a retained root.

```bash
taskset -c 8 python3 - <<'PY'
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess
import sys

root = Path('/workspace/scratch/166b48a091b9')
recovery = root / 'recovery'
measurements = Path('/workspace/scratch/fd78534029f7/measurements')
tool = Path('/workspace/scratch/fd78534029f7/worktrees/DB-Exec-10-plan/ledger/evidence/batches/DB-Perf-01/execution-refactor/continuation-7/current-measurements/tools/archive_measurement_evidence.py')
expected_tool = '0e3d18c4c67072c119cba0477fc2ead22f60ab6c0c722a40dbee1960f195be3b'
assert hashlib.sha256(tool.read_bytes()).hexdigest() == expected_tool
inventory = recovery / 'final-evidence-inputs-01.json'
inventory_sha = hashlib.sha256(inventory.read_bytes()).hexdigest()
output = root / 'final-evidence-01'
control = root / 'archive-control-01'
assert not output.exists() and not control.exists(), 'Fresh destinations required'
control.mkdir(mode=0o700)
argv = [
    sys.executable, str(tool),
    '--measurements', str(measurements / 'sqlite-final-01'),
    '--retain-root', str(measurements / 'postgresql-final-01'),
    '--retain-root', str(recovery),
    '--inventory', str(inventory), '/inputFiles', inventory_sha,
    '--exclude-root', 'database', str(measurements / 'postgresql-final-01/pgdata'),
    '--exclude-root', 'package-cache', '/workspace/scratch/4a65d70f0fe1/tools/nuget-packages',
    '--exclude-root', 'package-cache', '/workspace/scratch/fd78534029f7/builds/candidate-sqlite-02/consumer-workload/packages',
    '--exclude-root', 'package-cache', '/workspace/scratch/fd78534029f7/builds/candidate-postgresql-02/consumer-workload/packages',
    '--scope', 'Original final 17da four-cell local evidence and completed analysis/identity/recovery reviews; historical pre-final archive retained separately by identity; retention does not grant performance or binary-recovery credit',
    '--output-dir', str(output),
]
record = {'argv': argv, 'toolSha256': expected_tool, 'inventorySha256': inventory_sha,
          'startedUtc': datetime.now(timezone.utc).isoformat(),
          'wrapperAffinity': [8], 'productExecutions': 0,
          'stdoutPath': str(control / 'stdout.log'), 'stderrPath': str(control / 'stderr.log')}
with (control / 'command-start.json').open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
with (control / 'stdout.log').open('xb') as stdout, (control / 'stderr.log').open('xb') as stderr:
    completed = subprocess.run(argv, stdout=stdout, stderr=stderr, check=False)
record.update(exitCode=completed.returncode, finishedUtc=datetime.now(timezone.utc).isoformat())
with (control / 'command.json').open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps({'exitCode': completed.returncode, 'commandReceipt': str(control / 'command.json'),
                  'outputDirectory': str(output)}))
raise SystemExit(completed.returncode)
PY
```

## Verification and publication boundaries

Only the actual receipt can establish `status=retained-and-verified`,
`originalInputsUnchanged=true`, `completeArchiveReadback=true`, archive/manifest
hashes and included/excluded counts. Preserve external invocation logs and any
`failure.json`/partial outputs. Retries use fresh numbered paths.

The helper verifies every top-level member and gzip EOF, rehashes/fingerprints
every registered original, and checks retained-root inventories. The nested
pre-final archive is verified as one identified byte file; its earlier inner
member readback remains supported by its separate historical receipt. Do not
claim the final helper recursively unpacked that nested archive.

Excluded package/binary/database bytes are represented by identity, not stored
contents. The helper always records `binaryRecoveryClaim=false` and
`finalAcceptanceCredit=false`. Archive success does not replace arithmetic,
identity or engineering review. After observing success, publish the actual
archive, manifest, receipt and external invocation records through the existing
Plan workflow. This proposal changes no repository or frozen input.

## Preserved preparation failure

The first attempt to write this Markdown used an outer here-document delimiter
that also appeared in an inner command example. The outer Python failed parsing
before writing this document. Shell parsing then reached the example archive
wrapper, which failed on the absent `final-evidence-inputs-01.json` before
creating a control/output directory or invoking the archive helper. It read only
the small helper source. No workload, inventory scan, evidence archive or
measurement mutation occurred. This corrected document uses a distinct outer
delimiter; its example code was stored as text, not executed.
