using System.Runtime;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Cryptography;

internal sealed record MappedRuntimeImage(string Path, string Sha256);
internal sealed record RuntimeIdentity(
    string FrameworkDescription, string EnvironmentVersion, bool DynamicCodeSupported,
    bool DynamicCodeCompiled, bool IsServerGc, bool SatoriGc,
    Dictionary<string, string> GcConfiguration, MappedRuntimeImage[] RuntimeImages,
    string ManagedAssemblySha256, string? CgroupMembership,
    string ClientMemoryBudgetStatus, long RequestedClientBudgetBytes)
{
    internal static RuntimeIdentity ReadAndValidate()
    {
        if (!RuntimeFeature.IsDynamicCodeSupported || !RuntimeFeature.IsDynamicCodeCompiled)
            throw new InvalidOperationException("This EF Core lane requires the JIT runtime.");
        var values = GC.GetConfigurationVariables();
        var isSatori = values.TryGetValue("SatoriGC", out var value) && value is true;
#if EXPECT_SATORI
        if (!isSatori) throw new InvalidOperationException("The published Satori build did not load Satori GC.");
#else
        if (isSatori || GCSettings.IsServerGC)
            throw new InvalidOperationException("The stock comparison must load Workstation GC.");
#endif
        var images = File.ReadLines("/proc/self/maps")
            .Select(line => line.Split(' ', 6, StringSplitOptions.RemoveEmptyEntries))
            .Where(parts => parts.Length == 6)
            .Select(parts => parts[5])
            .Where(path => Path.GetFileName(path) is "libcoreclr.so" or "libclrjit.so" or "libclrgc.so" or "libclrgcexp.so")
            .Distinct(StringComparer.Ordinal)
            .Order(StringComparer.Ordinal)
            .Select(path => new MappedRuntimeImage(path, HashFile(path)))
            .ToArray();
        if (!images.Any(image => Path.GetFileName(image.Path) == "libcoreclr.so")
            || !images.Any(image => Path.GetFileName(image.Path) == "libclrjit.so"))
            throw new InvalidOperationException("Could not prove the actual CoreCLR/JIT image identities.");
        return new(
            RuntimeInformation.FrameworkDescription, Environment.Version.ToString(),
            RuntimeFeature.IsDynamicCodeSupported, RuntimeFeature.IsDynamicCodeCompiled,
            GCSettings.IsServerGC, isSatori,
            values.ToDictionary(pair => pair.Key, pair => Convert.ToString(pair.Value,
                System.Globalization.CultureInfo.InvariantCulture) ?? "null", StringComparer.Ordinal),
            images, HashFile(typeof(RuntimeIdentity).Assembly.Location),
            File.Exists("/proc/self/cgroup") ? File.ReadAllText("/proc/self/cgroup") : null,
            "Not enforced or attested by this executable. External admission must prove a 128 MiB client-only limit; GCHeapHardLimit is not a process/RSS limit and is not proven effective for Satori.",
            134_217_728);
    }

    private static string HashFile(string path)
    {
        using var stream = File.OpenRead(path);
        return Convert.ToHexStringLower(SHA256.HashData(stream));
    }
}
